// Toolbar popup: shows the current site and adds it to the desktop and "My websites".
// The popup only leaves the site in storage (pendingAdd); the new-tab page adds it, so its own list is never overwritten.
const $ = (id) => document.getElementById(id);
const TXT = {
  fa: { title: "افزودن به سایت‌های من", name: "نام", url: "آدرس", full: "آدرس کامل همین صفحه", add: "افزودن به سایت‌های من", have: "از قبل در سایت‌های من و دسکتاپ هست", done: "افزوده شد؛ در تب جدید دیده می‌شود", bad: "این صفحه را نمی‌شود اضافه کرد." },
  en: { title: "Add to My websites", name: "Name", url: "Address", full: "Full address of this page", add: "Add to My websites", have: "Already in My websites and on the desktop", done: "Added. You will see it in a new tab.", bad: "This page cannot be added." },
};
const norm = (u) => String(u || "").trim().toLowerCase().replace(/^(https?:\/\/)www\./, "$1").replace(/[\/#?]+$/, "");
const lum = (hex) => { const m = /^#?([0-9a-f]{6})$/i.exec(hex || ""); if (!m) return 0; const n = parseInt(m[1], 16); return (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255; };

(async () => {
  const r = await chrome.storage.local.get(["settings", "sites", "mysites"]);
  const S = r.settings || {}, T = TXT[S.lang === "en" ? "en" : "fa"];
  document.documentElement.lang = S.lang === "en" ? "en" : "fa"; document.documentElement.dir = S.lang === "en" ? "ltr" : "rtl";
  const auto = S.autoTheme !== false && S.autoColors ? S.autoColors : null;
  document.documentElement.setAttribute("data-theme", auto ? (auto.lum > 0.38 ? "light" : "dark") : (S.theme || "dark"));
  const accent = (auto && auto.accent && auto.accent.hex) || S.accent || "#4cc2ff";
  document.documentElement.style.setProperty("--accent", accent);
  document.documentElement.style.setProperty("--accent-text", lum(accent) > 0.6 ? "#0b0f18" : "#ffffff");
  $("title").textContent = T.title; $("nameLbl").textContent = T.name; $("urlLbl").textContent = T.url; $("fullLbl").textContent = T.full; $("addBtn").textContent = T.add;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let u = null; try { u = new URL(tab && tab.url); } catch (e) {}
  if (!u || !/^https?:$/.test(u.protocol)) { document.body.classList.add("bad"); $("msg").textContent = T.bad; return; }

  const origin = u.origin, full = tab.url.split("#")[0], host = u.hostname.replace(/^www\./, "");
  const title = String(tab.title || "").trim(), short = title.split(/\s[-–—|·•]\s/)[0].trim();
  $("nameIn").value = (short.length > 2 ? short : title || host).slice(0, 40);
  $("fullRow").hidden = norm(full) === norm(origin);
  const current = () => ($("fullChk").checked && !$("fullRow").hidden ? full : origin);

  const img = $("icoImg"), fav = [];
  try { fav.push(chrome.runtime.getURL("/_favicon/") + "?pageUrl=" + encodeURIComponent(origin) + "&size=64"); } catch (e) {}
  fav.push("https://www.google.com/s2/favicons?sz=64&domain_url=" + encodeURIComponent(origin));
  let fi = 0;
  img.onerror = () => { if (fi < fav.length) img.src = fav[fi++]; else { img.hidden = true; $("icoLetter").textContent = (host[0] || "?").toUpperCase(); } };
  img.onerror();

  const have = () => {
    const k = norm(current()), has = (a) => Array.isArray(a) && a.some((s) => s && s.url && !s.isFolder && !s.sys && norm(s.url) === k);
    return has(r.sites) && has(r.mysites);
  };
  const refresh = () => { $("urlTxt").textContent = current(); const h = have(); $("addBtn").disabled = h; $("msg").textContent = h ? T.have : ""; $("msg").className = "msg"; };
  $("fullChk").addEventListener("change", refresh); refresh();

  const add = async () => {
    if ($("addBtn").disabled) return;
    $("addBtn").disabled = true;
    const rec = { name: $("nameIn").value.trim().slice(0, 60) || host, url: current() };
    const f = await chrome.storage.local.get("pendingAdd");
    await chrome.storage.local.set({ pendingAdd: [...(Array.isArray(f.pendingAdd) ? f.pendingAdd : []), rec] });
    $("msg").textContent = T.done; $("msg").className = "msg ok";
    setTimeout(() => window.close(), 1300);
  };
  $("addBtn").addEventListener("click", add);
  $("nameIn").addEventListener("keydown", (e) => { if (e.key === "Enter") add(); });
})();
