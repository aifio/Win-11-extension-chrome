const DEFAULT_SITES = [
  { name: "Google", url: "https://www.google.com" },
  { name: "YouTube", url: "https://www.youtube.com" },
  { name: "Gmail", url: "https://mail.google.com" },
  { name: "GitHub", url: "https://github.com" },
  { name: "Wikipedia", url: "https://wikipedia.org" },
  { name: "Instagram", url: "https://www.instagram.com" },
  { name: "Telegram", url: "https://web.telegram.org" },
  { name: "X", url: "https://x.com" },
  { name: "LinkedIn", url: "https://www.linkedin.com" },
  { name: "Spotify", url: "https://open.spotify.com" },
  { name: "Maps", url: "https://www.google.com/maps" },
  { name: "Translate", url: "https://translate.google.com" },
];

const ACCENT_COLORS = [
  { name: "Blue", hex: "#4cc2ff", dim: "#2b9dff", dark: "#1f7ae0", text: "#001e36" },
  { name: "Purple", hex: "#b180ff", dim: "#9555f2", dark: "#7427d1", text: "#1a0033" },
  { name: "Emerald", hex: "#44d98a", dim: "#22be6a", dark: "#107c41", text: "#002a11" },
  { name: "Rose", hex: "#ff6ea7", dim: "#e3008c", dark: "#b5006e", text: "#33001a" },
  { name: "Amber", hex: "#ffaa44", dim: "#f7821b", dark: "#ca5010", text: "#2e1200" },
  { name: "Teal", hex: "#00e5ff", dim: "#00b4d8", dark: "#0077b6", text: "#00222a" },
];

const I18N = {
  fa: {
    title: "تب جدید", search: "جستجو در وب...", startSearch: "جستجو...", pinned: "سایت‌های منتخب",
    settings: "تنظیمات", language: "زبان", engine: "موتور جستجو", calendar: "تقویم",
    persian: "شمسی", gregorian: "میلادی", hour24: "ساعت ۲۴ ساعته", seconds: "نمایش ثانیه",
    showShortcuts: "نمایش آیکون‌های دسکتاپ", blur: "تاری پس‌‌زمینه", reset: "بازگردانی پیش‌فرض",
    start: "استارت", searchBtn: "جستجو", user: "کاربر", widgets: "ویجت‌ها",
    widgetsSubtitle: "داشبورد و ابزارهای سریع", manageWidgets: "مدیریت و فعال‌سازی ویجت‌ها",
    heroWidgetToggle: "ساعت و سرچ وسط صفحه", showHeroWidget: "نمایش ساعت و جستجوی وسط صفحه",
    themeMode: "حالت پوسته (تم)", themeDark: "تیره (Dark)", themeLight: "روشن (Light)",
    accentColor: "رنگ شاخص ویندوز (Accent)",
    city: "شهر (آبوهوا)", wallpaper: "تصویر زمینه", choose: "انتخاب", default: "پیش‌فرض",
    addSite: "افزودن سایت", editSite: "ویرایش سایت", removeSite: "حذف سایت", openNew: "باز کردن در تب جدید",
    pinTaskbar: "سنجاق به تسک‌‌بار", unpinTaskbar: "برداشتن از تسکبار",
    fontStyle: "قلم و فونت متن", fontPuffy: "پفکی و گرد (Baloo Bhaijaan)", fontRubik: "روبیک نرم (Rubik)",
    fontSegoe: "سگوئه ویندوز (Segoe UI)", fontCustom: "فونت دلخواه شخصی...",
    customFontName: "نام فونت نصب‌شده روی ویندوز:",
    changeWallpaper: "تغییر تصویر زمینه", resetWallpaper: "تصویر زمینه پیش‌فرض", refresh: "تازه‌سازی",
    iconPick: "یکی از آیکون‌های پیدا‌شده را انتخاب کنید", iconAuto: "خودکار", wTranslate: "مترجم", trSame: "زبان متن با زبان مقصد یکی است", trAuto: "تشخیص خودکار", trSwap: "جابه‌جایی زبان‌ها", trPh: "متن را بنویسید یا بچسبانید…", trGo: "ترجمه", trCopy: "کپی", trCopied: "کپی شد", trClear: "پاک کردن", trSpeak: "خواندن متن", trWorking: "در حال ترجمه…", trErr: "ترجمه انجام نشد؛ اینترنت را بررسی کنید.",
    scHub: "مرکز وب‌سایت‌ها", scMine: "وب‌سایت‌های من", scSearch: "جستجو در سایت‌ها…", scAll: "همه", scNone: "نتیجه‌ای پیدا نشد.", scAddDesk: "افزودن به دسکتاپ", scOnDesk: "روی دسکتاپ است", scAddedDesk: "به دسکتاپ اضافه شد", scSave: "ذخیره در وب‌سایت‌های من", scSaved: "در وب‌سایت‌های من هست", scLibSaved: "در وب‌سایت‌های من ذخیره شد",
    scAddLib: "افزودن وب‌سایت", scRemoveLib: "حذف از وب‌سایت‌های من", scRemoveLibConfirm: "این سایت از لیست «وب‌سایت‌های من» حذف شود؟ (اگر روی دسکتاپ باشد، آنجا می‌ماند.)", scMineEmpty: "هنوز سایتی ذخیره نشده. سایت‌هایی که به دسکتاپ اضافه می‌کنید خودکار اینجا ذخیره می‌شوند و با حذف از دسکتاپ پاک نمی‌شوند.", scMineNote: "با حذف آیکون از دسکتاپ، سایت اینجا می‌ماند",
    scBuiltin: "کاتالوگ داخلی", scOnline: "کاتالوگ آنلاین", scUpdSet: "تنظیمات به‌روزرسانی کاتالوگ", scAuto: "به‌روزرسانی خودکار (هر ۱۲ ساعت)", scUpdNow: "ذخیره و به‌روزرسانی", scUpdHint: "آدرس یک فایل JSON با قالب hub.json (فقط https). خالی بگذارید تا از کاتالوگ داخلی استفاده شود.", scNoUrl: "آدرس کاتالوگ وارد نشده", scUpdated: "کاتالوگ به‌روز شد", scFail: "به‌روزرسانی انجام نشد",
    iconSearching: "در حال پیدا کردن آیکون‌ها…", iconNone: "آیکونی پیدا نشد؛ می‌توانید لینک یا ایموجی وارد کنید.", siteName: "نام", siteUrl: "آدرس (URL)", siteIcon: "آیکون (اختیاری)", siteIconPh: "ایموجی مثل 📧 یا لینک تصویر (https://...)", siteIconHint: "اگر خالی بماند، آیکون خودکار ساخته می‌شود؛ سرویس‌های گوگل (Gmail، Maps، Drive و…) هرکدام آیکون جداگانه دارند.", save: "ذخیره", cancel: "انصراف", confirm: "تأیید",
    wNotes: "یادداشت", wTodo: "کارها", wCalendar: "تقویم", wWeather: "آب‌وهوا", wClock: "ساعت جهانی",
    wProgress: "پیشرفت زمان", wTimer: "تایمر", wStopwatch: "کرنومتر", wCalc: "ماشین‌حساب",
    notesPh: "اینجا بنویسید...", todoPh: "کار جدید + Enter", loading: "در حال بارگذاری...", weatherErr: "آب‌وهوا بارگذاری نشد",
    pDay: "امروز", pWeek: "هفته", pMonth: "ماه", pYear: "سال", bStart: "شروع", bPause: "توقف", bReset: "بازنشانی", bLap: "دور",
    feels: "احساس‌شده", humidity: "رطوبت", wind: "باد", battery: "باتری", charging: "در حال شارژ", netOnline: "آنلاین", netOffline: "آفلاین",
    cores: "هسته پردازنده", ram: "حافظه", screen: "صفحه‌نمایش", network: "شبکه", collapse: "جمع کردن", timerDone: "زمان تمام شد!",
    wpOnline: "آنلاین",
    lblAutoTheme: "تم خودکار با تصویر زمینه", dAutoTheme: "رنگ تأکید، تیره یا روشن بودن و رنگ شیشه از روی تصویر زمینه تنظیم می‌شود.", lblGlass: "شدت حالت شیشه‌ای", dGlass: "هرچه بیشتر باشد، پنل‌ها شفاف‌تر و محوتر می‌شوند.",
    mNew: "جدید", mView: "نمایش", mTools: "ابزارها و ویجت‌ها", mPersonalize: "شخصی‌سازی",
    greetMorning: "صبح بخیر", greetNoon: "ظهر بخیر", greetEvening: "عصر بخیر", greetNight: "شب بخیر", addToDesktop: "افزودن به دسکتاپ", removeFromDesktop: "حذف از دسکتاپ",
    lblHeroStyle: "ظاهر ساعت و جستجوی وسط", styleCard: "کارت شیشه‌ای", styleMinimal: "ساده", lblHeroInfo: "نمایش آب‌وهوا و اطلاعات", dHeroInfo: "آب‌وهوا، تاریخ دوم و درصد گذشته از روز.", lblHeroQuick: "نمایش میانبر سایت‌ها زیر جستجو",
    recentSearches: "جستجوهای اخیر", clearHistory: "پاک کردن", searchWith: "جستجو با",
    wpNext: "تصویر زمینه بعدی (آنلاین)", wpFromFile: "انتخاب عکس از دستگاه", wpNextDone: "تصویر زمینه عوض شد", wpNextBtnDesc: "از همان منبع آنلاینی که انتخاب کرده‌اید، یک تصویر تازه می‌آورد.",
    accTitle: "حساب کاربری", accProfile: "نمایه", accNamePh: "نام شما", accAvatarChange: "تغییر عکس", accAvatarRemove: "حذف عکس",
    accGoogle: "حساب گوگل (Google Drive)", accGoogleDesc: "با اتصال به گوگل، پشتیبان شما در یک فضای خصوصی مخصوص همین افزونه در Google Drive ذخیره می‌شود. به فایل‌های دیگر Drive شما دسترسی ندارد.",
    accConnect: "اتصال با گوگل", accDisconnect: "قطع اتصال", accAuto: "ذخیره خودکار بعد از هر تغییر", accSaveNow: "ذخیره همین حالا", accRestoreCloud: "بازیابی", accLast: "آخرین ذخیره:", accNever: "هنوز ذخیره نشده",
    accChrome: "همگام‌سازی کروم (Chrome Sync)", accChromeDesc: "داده‌های کوچک (سایت‌ها، تنظیمات، یادداشت‌ها) با حساب گوگلِ مرورگر شما همگام می‌شوند. تصویر زمینه محلی و ویدیو ذخیره نمی‌شوند.", accChromeAs: "حساب مرورگر:", accNoChromeAcc: "در کروم وارد حساب گوگل نشده‌اید.",
    accLocal: "پشتیبان‌گیری دستی", accLocalDesc: "همه چیز در یک فایل: سایت‌ها، پوشه‌ها، تنظیمات، ویجت‌ها، یادداشت‌ها، کارها و تصویرهای زمینه.", accDownload: "دانلود فایل پشتیبان", accRestoreFile: "بازیابی از فایل",
    accMedia: "شامل تصویر زمینه و ویدیوی زنده", accKeys: "شامل کلیدهای API", accKeysNote: "فایل پشتیبان با کلیدها را با کسی به اشتراک نگذارید.", accRestoreConfirm: "داده‌های فعلی شما با پشتیبان جایگزین می‌شود. ادامه می‌دهید؟",
    accRestoreDone: "بازیابی انجام شد", accSaved: "ذخیره شد", accBadFile: "این فایل، پشتیبان این افزونه نیست.", accNeedClient: "برای ورود با گوگل، توسعه‌دهنده باید یک OAuth Client ID در فایل manifest.json بگذارد.", accCancelled: "ورود لغو شد.",
    accTooBig: "حجم داده برای Chrome Sync زیاد است. از Google Drive یا فایل استفاده کنید.", accNoCloud: "پشتیبانی در حساب گوگل پیدا نشد.", accFound: "در گوگل یک پشتیبان وجود دارد. «بازیابی» را بزنید، یا «ذخیره همین حالا» تا با داده‌های فعلی جایگزین شود.", accSignedIn: "وارد شده با", accBusy: "لطفاً صبر کنید...", accNoSupport: "این مرورگر از این قابلیت پشتیبانی نمی‌کند.",
    accNeedWebClient: "در مرورگر Edge ورود با گوگل از مسیر «وب» انجام می‌شود. در Google Cloud یک OAuth Client از نوع Web application بسازید، آدرس زیر را در Authorized redirect URIs بگذارید و Client ID را در GOOGLE_WEB_CLIENT_ID (فایل newtab.js) قرار دهید:", accSessionExpired: "نشست گوگل تمام شده است. دوباره «اتصال با گوگل» را بزنید.",
    accEdge: "همگام‌سازی Edge (Edge Sync)", accEdgeDesc: "داده‌های کوچک (سایت‌ها، تنظیمات، یادداشت‌ها) با حساب مرورگر Edge شما همگام می‌شوند. تصویر زمینه محلی و ویدیو ذخیره نمی‌شوند.",
    lblDragFolder: "ساخت پوشه با کشیدن آیکون روی آیکون", dDragFolder: "اگر یک آیکون را روی آیکون دیگر رها کنید، هر دو در یک پوشه جدید قرار می‌گیرند.", lblTraySec: "نمایش ثانیه در ساعت تسکبار",
    resetStartSize: "بازنشانی اندازه منوی استارت", dResetStartSize: "اندازه را با کشیدن لبه بالا، کناره‌ها یا گوشه‌های منو تغییر دهید. دابل‌کلیک روی لبه هم اندازه پیش‌فرض را برمی‌گرداند.",
    secGeneral: "عمومی", secPersonal: "شخصی‌سازی", secWallpaper: "تصویر زمینه", secDesktop: "دسکتاپ", secStart: "استارت و تسکبار", secTime: "زمان و آب‌وهوا", secBrowse: "مرورگر و پنجره‌ها", secAbout: "درباره و بازنشانی",
    setSearchPh: "جستجو در تنظیمات...", setResults: "نتایج جستجو", dBlur: "محو کردن تصویر زمینه", dWpStatic: "یک عکس از دستگاه خود انتخاب کنید.", lblWpOnline: "تصویر زمینه آنلاین", dWpOnline: "Wallhaven، عکس تصادفی یا API دلخواه.", dWpLive: "ویدیوی زنده از فایل، لینک، Pexels یا Pixabay.",
    open: "باز کردن", run: "اجرا", lblIconSize: "اندازه آیکون‌ها", sizeS: "کوچک", sizeM: "معمولی", sizeL: "بزرگ", lblLabels: "نمایش نام زیر آیکون‌ها", dSnap: "آیکون‌ها در خانه‌های شبکه قرار می‌گیرند.", dArrange: "همه آیکون‌ها را مرتب می‌کند.",
    lblSettingsIcon: "آیکون تنظیمات روی دسکتاپ", dSettingsIcon: "یک آیکون چرخ‌دنده روی صفحه اصلی اضافه می‌کند.", settingsAdd: "افزودن آیکون تنظیمات", settingsRemove: "حذف آیکون از دسکتاپ",
    lblStartRecent: "نمایش «اخیراً باز شده» در استارت", lblStartPages: "نمایش صفحات کروم در استارت", btnClearRecent: "پاک کردن فهرست اخیراً باز شده", btnResetPinned: "بازنشانی آیکون‌های تسکبار", dResetPinned: "سه سایت اول دوباره سنجاق می‌شوند.", cleared: "پاک شد", pinReset: "تسکبار بازنشانی شد",
    dCity: "برای ویجت آب‌وهوا.", lblOpenMode: "باز کردن سایت‌ها", modeTab: "در تب جدید", modeSame: "در همین صفحه", modeApp: "در پنجره داخلی (مثل ویندوز)", dOpenMode: "پنجره داخلی، سایت را روی همین صفحه و مثل یک برنامه ویندوز باز می‌کند.",
    aboutName: "ویندوز ۱۱ تب جدید", dReset: "همه تنظیمات به حالت اولیه برمی‌گردد.", confirmResetAll: "همه تنظیمات به حالت اولیه برمی‌گردد. ادامه می‌دهید؟",
    openInApp: "باز کردن در پنجره داخلی", winLimit: "حداکثر ۸ پنجره باز می‌شود.", winReload: "بارگذاری دوباره", winOpenTab: "باز کردن در تب جدید", winMin: "کوچک کردن", winMax: "بزرگ کردن", winClose: "بستن", winHint: "اگر سایت باز نشد، با دکمه ↗ آن را در تب جدید باز کنید.", winRestore: "بازگرداندن",
    wpLive: "ویدیو زنده", liveFile: "فایل / لینک", liveNeedKey: "برای این منبع یک کلید API رایگان لازم است. آن را در کادر پایین بگذارید.", liveKeyPh: "کلید API", liveQueryPh: "جستجو (مثلاً ocean, city, forest)", liveMore: "ویدیوهای بیشتر", liveErr: "دریافت ویدیوها ممکن نشد. کلید API و اینترنت را بررسی کنید و https://{host}/* را به host_permissions اضافه کنید.", liveChoose: "انتخاب فایل ویدیو", liveRemove: "حذف ویدیو", liveUrlPh: "لینک مستقیم ویدیو (mp4 / webm)", liveNow: "ویدیوی فعلی:", liveNone: "ویدیویی انتخاب نشده است.", liveSaveErr: "ذخیره ویدیو ممکن نشد.", liveNote: "ویدیو بی‌صدا و تکرارشونده پخش می‌شود و وقتی تب دیده نمی‌شود متوقف می‌شود. ویدیوی کوچک‌تر (زیر ۳۰ مگابایت) روان‌تر است.",
    wpCustomApi: "API دلخواه", wpQuery: "جستجو (مثلاً nature, city)", wpCustomPh: "آدرس API (خروجی JSON یا تصویر)", wpSearch: "جستجو", sTop: "برترین‌ها", sRandom: "تصادفی", sNew: "جدیدترین", sViews: "پربازدیدترین", sFav: "محبوب‌ترین", wpEmpty: "تصویری پیدا نشد.", wpHint: "اگر خطا مربوط به CORS است، https://{host}/* را به host_permissions در manifest.json اضافه کنید.", wpCustomNote: "آدرس کامل API را بگذارید (کلید داخل آدرس باشد) و دامنه‌اش را به host_permissions اضافه کنید. مثال: https://api.unsplash.com/photos/random?client_id=کلید&orientation=landscape&count=12",
    newFolder: "پوشه جدید", folderName: "نام پوشه", renameFolder: "تغییر نام", removeFolder: "حذف پوشه", confirmRemoveFolder: "پوشه حذف می‌شود. سایت‌های داخل آن به دسکتاپ برمی‌گردند.", folderEmpty: "این پوشه خالی است. سایت را روی پوشه بکشید یا از کلیک راست «انتقال به پوشه» را بزنید.", moveToFolder: "انتقال به پوشه", moveOut: "خارج کردن از پوشه", movedToFolder: "به پوشه منتقل شد", openFolder: "باز کردن پوشه",
    openThis: "باز کردن در همین صفحه", openWindow: "باز کردن در پنجره جدید", copyLink: "کپی لینک", qrCode: "کد QR", duplicate: "تکثیر سایت", linkCopied: "لینک کپی شد", qrScan: "با دوربین موبایل اسکن کنید", downloadPng: "دانلود PNG", qrTooLong: "لینک برای کد QR خیلی طولانی است.", wpTitle: "تصویر زمینه آنلاین", wpPicsum: "عکس‌های تصادفی", wpRefresh: "تصاویر جدید", wpAuto: "هر روز تصویر جدید", wpUrlPh: "لینک مستقیم تصویر (https://...)", wpApply: "اعمال", wpErr: "دریافت تصاویر ممکن نشد. اینترنت را بررسی کنید.", wpLoading: "در حال دریافت...",
    allApps: "همه برنامه‌ها", back: "بازگشت", recommended: "اخیراً باز شده", noRecent: "هنوز سایتی باز نشده است.", searchWeb: "جستجو در وب برای", openUrl: "باز کردن",
    chromePages: "صفحات کروم", pgDownloads: "دانلودها", pgHistory: "تاریخچه", pgBookmarks: "نشانک‌ها", pgExtensions: "افزونه‌ها", pgSettings: "تنظیمات کروم",
    secSites: "سایت‌ها", secActions: "اقدام‌ها", secCalc: "محاسبه", copied: "کپی شد", actTheme: "تغییر تم تیره/روشن", clickCopy: "برای کپی کلیک کنید",
    tooBig: "این تصویر برای ذخیره خیلی بزرگ است.", confirmRemove: "این سایت حذف شود؟",
    snapGrid: "چیدمان روی شبکه", autoArrange: "مرتب‌سازی خودکار آیکون‌ها",
    openStickyNote: "یادداشت چسبان روی دسکتاپ", openWeatherGadget: "ویجت شناور آب‌وهوا",
    days: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
  },
  en: {
    title: "New Tab", search: "Search the web...", startSearch: "Search...", pinned: "Pinned sites",
    settings: "Settings", language: "Language", engine: "Search engine", calendar: "Calendar",
    persian: "Persian (Solar)", gregorian: "Gregorian", hour24: "24-hour clock", seconds: "Show seconds",
    showShortcuts: "Show desktop icons", blur: "Wallpaper blur", reset: "Reset to defaults",
    start: "Start", searchBtn: "Search", user: "User", widgets: "Widgets",
    widgetsSubtitle: "Dashboard & Quick tools", manageWidgets: "Manage active widgets",
    heroWidgetToggle: "Center Clock & Search", showHeroWidget: "Show center clock & search",
    themeMode: "Theme mode", themeDark: "Dark mode", themeLight: "Light mode",
    accentColor: "Accent color",
    city: "City (weather)", wallpaper: "Wallpaper", choose: "Choose", default: "Default",
    addSite: "Add site", editSite: "Edit site", removeSite: "Remove site", openNew: "Open in new tab",
    pinTaskbar: "Pin to taskbar", unpinTaskbar: "Unpin from taskbar",
    fontStyle: "Font Style", fontPuffy: "Puffy Rounded (Baloo Bhaijaan)", fontRubik: "Rubik Soft",
    fontSegoe: "Windows Segoe UI", fontCustom: "Custom System Font...",
    customFontName: "Installed font name:",
    changeWallpaper: "Change wallpaper", resetWallpaper: "Default wallpaper", refresh: "Refresh",
    iconPick: "Pick one of the icons found", iconAuto: "Auto", wTranslate: "Translator", trSame: "Text is already in the target language", trAuto: "Detect language", trSwap: "Swap languages", trPh: "Type or paste text…", trGo: "Translate", trCopy: "Copy", trCopied: "Copied", trClear: "Clear", trSpeak: "Read aloud", trWorking: "Translating…", trErr: "Could not translate. Check your connection.",
    scHub: "Site hub", scMine: "My websites", scSearch: "Search sites…", scAll: "All", scNone: "Nothing found.", scAddDesk: "Add to desktop", scOnDesk: "Already on desktop", scAddedDesk: "Added to desktop", scSave: "Save to My websites", scSaved: "In My websites", scLibSaved: "Saved to My websites",
    scAddLib: "Add website", scRemoveLib: "Remove from My websites", scRemoveLibConfirm: "Remove this site from My websites? (If it is on the desktop, it stays there.)", scMineEmpty: "Nothing saved yet. Sites you add to the desktop are saved here automatically and stay here when you remove them from the desktop.", scMineNote: "Removing an icon from the desktop keeps the site here",
    scBuiltin: "Built-in catalog", scOnline: "Online catalog", scUpdSet: "Catalog update settings", scAuto: "Update automatically (every 12 hours)", scUpdNow: "Save and update", scUpdHint: "Address of a JSON file in the hub.json format (https only). Leave empty to use the built-in catalog.", scNoUrl: "No catalog address", scUpdated: "Catalog updated", scFail: "Update failed",
    iconSearching: "Looking for icons…", iconNone: "No icons found. You can type a link or an emoji.", siteName: "Name", siteUrl: "URL", siteIcon: "Icon (optional)", siteIconPh: "An emoji like 📧 or an image link (https://...)", siteIconHint: "Leave empty for an automatic icon. Google services (Gmail, Maps, Drive...) each get their own icon.", save: "Save", cancel: "Cancel", confirm: "Confirm",
    wNotes: "Notes", wTodo: "To-do", wCalendar: "Calendar", wWeather: "Weather", wClock: "World clock",
    wProgress: "Time progress", wTimer: "Timer", wStopwatch: "Stopwatch", wCalc: "Calculator",
    notesPh: "Write here...", todoPh: "New task + Enter", loading: "Loading...", weatherErr: "Couldn't load weather",
    pDay: "Today", pWeek: "Week", pMonth: "Month", pYear: "Year", bStart: "Start", bPause: "Pause", bReset: "Reset", bLap: "Lap",
    feels: "Feels like", humidity: "Humidity", wind: "Wind", battery: "Battery", charging: "Charging", netOnline: "Online", netOffline: "Offline",
    cores: "CPU cores", ram: "Memory", screen: "Screen", network: "Network", collapse: "Collapse", timerDone: "Time is up!",
    wpOnline: "Online",
    lblAutoTheme: "Auto theme from wallpaper", dAutoTheme: "The accent colour, dark or light mode and the glass colour follow the wallpaper.", lblGlass: "Glass strength", dGlass: "A higher value makes panels clearer and more blurred.",
    mNew: "New", mView: "View", mTools: "Tools & widgets", mPersonalize: "Personalize",
    greetMorning: "Good morning", greetNoon: "Good afternoon", greetEvening: "Good evening", greetNight: "Good night", addToDesktop: "Add to desktop", removeFromDesktop: "Remove from desktop",
    lblHeroStyle: "Center clock & search style", styleCard: "Glass card", styleMinimal: "Minimal", lblHeroInfo: "Show weather and info", dHeroInfo: "Weather, the second calendar date and the day progress.", lblHeroQuick: "Show site shortcuts under the search",
    recentSearches: "Recent searches", clearHistory: "Clear", searchWith: "Search with",
    wpNext: "Next wallpaper (online)", wpFromFile: "Choose a picture from your device", wpNextDone: "Wallpaper changed", wpNextBtnDesc: "Loads a new picture from the online source you chose.",
    accTitle: "Account", accProfile: "Profile", accNamePh: "Your name", accAvatarChange: "Change picture", accAvatarRemove: "Remove picture",
    accGoogle: "Google account (Google Drive)", accGoogleDesc: "When you connect Google, your backup is saved in a private space of this extension in Google Drive. It cannot see your other Drive files.",
    accConnect: "Connect with Google", accDisconnect: "Disconnect", accAuto: "Save automatically after every change", accSaveNow: "Save now", accRestoreCloud: "Restore", accLast: "Last saved:", accNever: "Not saved yet",
    accChrome: "Chrome Sync", accChromeDesc: "Small data (sites, settings, notes) is synced with the Google account of your browser. The local wallpaper and video are not saved.", accChromeAs: "Browser account:", accNoChromeAcc: "You are not signed in to Google in Chrome.",
    accLocal: "Manual backup", accLocalDesc: "Everything in one file: sites, folders, settings, widgets, notes, to-dos and wallpapers.", accDownload: "Download backup file", accRestoreFile: "Restore from file",
    accMedia: "Include wallpaper and live video", accKeys: "Include API keys", accKeysNote: "Do not share a backup file that has keys.", accRestoreConfirm: "Your current data will be replaced by the backup. Continue?",
    accRestoreDone: "Restore finished", accSaved: "Saved", accBadFile: "This file is not a backup of this extension.", accNeedClient: "To sign in with Google, the developer must put an OAuth Client ID in manifest.json.", accCancelled: "Sign-in was cancelled.",
    accTooBig: "The data is too big for Chrome Sync. Use Google Drive or a file.", accNoCloud: "No backup found in the Google account.", accFound: "A backup exists in Google. Press “Restore”, or “Save now” to replace it with your current data.", accSignedIn: "Signed in as", accBusy: "Please wait...", accNoSupport: "This browser does not support this feature.",
    accNeedWebClient: "In Edge, Google sign-in uses the web flow. In Google Cloud make an OAuth client of type Web application, add the URL below to Authorized redirect URIs, and put the Client ID in GOOGLE_WEB_CLIENT_ID (newtab.js):", accSessionExpired: "The Google session has ended. Press “Connect with Google” again.",
    accEdge: "Edge Sync", accEdgeDesc: "Small data (sites, settings, notes) is synced with the account of your Edge browser. The local wallpaper and video are not saved.",
    lblDragFolder: "Make a folder by dragging an icon onto another", dDragFolder: "Drop an icon on another icon and both go into a new folder.", lblTraySec: "Show seconds in the taskbar clock",
    resetStartSize: "Reset the Start menu size", dResetStartSize: "Drag the top edge, the sides or the corners of the menu to change its size. Double-click an edge to reset.",
    secGeneral: "General", secPersonal: "Personalization", secWallpaper: "Wallpaper", secDesktop: "Desktop", secStart: "Start & taskbar", secTime: "Time & weather", secBrowse: "Browsing & windows", secAbout: "About & reset",
    setSearchPh: "Search settings...", setResults: "Search results", dBlur: "Blur the wallpaper", dWpStatic: "Choose a picture from your device.", lblWpOnline: "Online wallpaper", dWpOnline: "Wallhaven, random photos or a custom API.", dWpLive: "Live video from a file, a link, Pexels or Pixabay.",
    open: "Open", run: "Run", lblIconSize: "Icon size", sizeS: "Small", sizeM: "Normal", sizeL: "Large", lblLabels: "Show names under icons", dSnap: "Icons stay on grid cells.", dArrange: "Arranges all icons.",
    lblSettingsIcon: "Settings icon on the desktop", dSettingsIcon: "Adds a gear icon to the home page.", settingsAdd: "Add settings icon", settingsRemove: "Remove icon from desktop",
    lblStartRecent: "Show “Recent” in Start", lblStartPages: "Show Chrome pages in Start", btnClearRecent: "Clear the recent list", btnResetPinned: "Reset taskbar icons", dResetPinned: "The first three sites are pinned again.", cleared: "Cleared", pinReset: "Taskbar reset",
    dCity: "Used by the weather widget.", lblOpenMode: "Open sites", modeTab: "In a new tab", modeSame: "In this tab", modeApp: "In an inside window (like Windows)", dOpenMode: "An inside window opens the site on this page, like a Windows app.",
    aboutName: "Windows 11 New Tab", dReset: "All settings go back to the defaults.", confirmResetAll: "All settings go back to the defaults. Continue?",
    openInApp: "Open in inside window", winLimit: "You can open up to 8 windows.", winReload: "Reload", winOpenTab: "Open in new tab", winMin: "Minimize", winMax: "Maximize", winClose: "Close", winHint: "If the site does not open, use the ↗ button to open it in a new tab.", winRestore: "Restore",
    wpLive: "Live video", liveFile: "File / link", liveNeedKey: "This source needs a free API key. Paste it in the box below.", liveKeyPh: "API key", liveQueryPh: "Search (e.g. ocean, city, forest)", liveMore: "More videos", liveErr: "Could not load videos. Check the API key and your internet, and add https://{host}/* to host_permissions.", liveChoose: "Choose video file", liveRemove: "Remove video", liveUrlPh: "Direct video link (mp4 / webm)", liveNow: "Current video:", liveNone: "No video selected.", liveSaveErr: "Could not save the video.", liveNote: "The video plays muted and in a loop. It pauses when the tab is hidden. A smaller video (under 30 MB) runs smoother.",
    wpCustomApi: "Custom API", wpQuery: "Search (e.g. nature, city)", wpCustomPh: "API URL (returns JSON or an image)", wpSearch: "Search", sTop: "Top", sRandom: "Random", sNew: "Latest", sViews: "Most viewed", sFav: "Most favorited", wpEmpty: "No images found.", wpHint: "If the error is CORS, add https://{host}/* to host_permissions in manifest.json.", wpCustomNote: "Paste the full API URL (with the key inside it) and add its domain to host_permissions. Example: https://api.unsplash.com/photos/random?client_id=KEY&orientation=landscape&count=12",
    newFolder: "New folder", folderName: "Folder name", renameFolder: "Rename", removeFolder: "Remove folder", confirmRemoveFolder: "The folder will be removed. Its sites go back to the desktop.", folderEmpty: "This folder is empty. Drag a site onto the folder, or use right-click “Move to folder”.", moveToFolder: "Move to folder", moveOut: "Move out of folder", movedToFolder: "Moved to folder", openFolder: "Open folder",
    openThis: "Open in this tab", openWindow: "Open in new window", copyLink: "Copy link", qrCode: "QR code", duplicate: "Duplicate site", linkCopied: "Link copied", qrScan: "Scan with your phone camera", downloadPng: "Download PNG", qrTooLong: "The link is too long for a QR code.", wpTitle: "Online wallpapers", wpPicsum: "Random photos", wpRefresh: "New images", wpAuto: "New image every day", wpUrlPh: "Direct image link (https://...)", wpApply: "Apply", wpErr: "Could not load images. Check your internet.", wpLoading: "Loading...",
    allApps: "All apps", back: "Back", recommended: "Recent", noRecent: "No recent sites yet.", searchWeb: "Search the web for", openUrl: "Open",
    chromePages: "Chrome pages", pgDownloads: "Downloads", pgHistory: "History", pgBookmarks: "Bookmarks", pgExtensions: "Extensions", pgSettings: "Chrome settings",
    secSites: "Sites", secActions: "Actions", secCalc: "Calculator", copied: "Copied", actTheme: "Switch dark/light theme", clickCopy: "Click to copy",
    tooBig: "This image is too large to save.", confirmRemove: "Remove this site?",
    snapGrid: "Snap icons to grid", autoArrange: "Auto-arrange icons",
    openStickyNote: "Desktop Sticky Note", openWeatherGadget: "Floating Weather Gadget",
    days: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
  },
};

const ENGINES = {
  google: "https://www.google.com/search?q=",
  bing: "https://www.bing.com/search?q=",
  duck: "https://duckduckgo.com/?q=",
};

const WIDGETS = ["weather", "clock", "calendar", "progress", "timer", "stopwatch", "calc", "todo", "notes", "translate"];
const WIDGET_ICONS = { weather: "🌤️", clock: "🌍", calendar: "📅", progress: "📊", timer: "⏳", stopwatch: "⏱️", calc: "🧮", todo: "✅", notes: "📝", translate: "🌐" };

const DEFAULTS = {
  lang: "fa", engine: "google", cal: "persian", h24: true, sec: false, short: true, blur: 0,
  city: "Tehran", snapGrid: true, theme: "dark", accent: "#4cc2ff", font: "puffy", customFont: "",
  taskbarPinned: [0, 1, 2],
  autoTheme: true, glass: 55, autoColors: null,
  profile: { name: "", avatar: null }, backupMedia: true, backupKeys: false,
  sync: { driveAuto: false, chromeAuto: false, lastDrive: 0, lastChrome: 0, google: null },
  dragFolder: true, traySeconds: false, panelPos: {},
  startSize: null,
  desk: {}, heroStyle: "card", heroInfo: true, heroQuick: true, searches: [],
  iconSize: "normal", labels: true, settingsIcon: false, startRecent: true, startPages: true, openMode: "tab",
  hero: { show: true, x: null, y: null },
  widgets: { weather: true, clock: true, calendar: true, progress: true, timer: true, stopwatch: true, calc: true, todo: true, notes: true, translate: true },
  hub: { url: "", auto: true, last: 0 }, tr: { from: "auto", to: "fa" },
  collapsed: {},
  recent: [],
  wpUrl: null, wpAuto: false, wpSource: "wallhaven", wpDay: "", wh: { q: "", sort: "toplist", res: "1920x1080" }, wpLive: null, liveProv: "pexels", liveQuery: "nature", liveKeys: { pexels: "", pixabay: "" }, wpCustom: "",
  floating: { note: { open: false, x: 50, y: 120 }, weather: { open: false, x: 800, y: 80 } }
};

let S = structuredClone(DEFAULTS);
let SITES = DEFAULT_SITES.slice();
let NOTES = "";
let TODOS = [];
let WALLPAPER = null;

const hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
const store = {
  get(keys) {
    if (hasChrome) return new Promise((r) => chrome.storage.local.get(keys, r));
    const out = {};
    keys.forEach((k) => { const v = localStorage.getItem(k); if (v != null) out[k] = JSON.parse(v); });
    return Promise.resolve(out);
  },
  set(obj) {
    if (hasChrome) return new Promise((r) => chrome.storage.local.set(obj, r));
    try { Object.entries(obj).forEach(([k, v]) => localStorage.setItem(k, JSON.stringify(v))); return Promise.resolve(); }
    catch (err) { return Promise.reject(err); }
  },
  remove(k) {
    if (hasChrome) return new Promise((r) => chrome.storage.local.remove(k, r));
    localStorage.removeItem(k); return Promise.resolve();
  },
};

const saveSettings = () => { scheduleSync(); return store.set({ settings: S }); };
const saveSites = () => { scheduleSync(); return store.set({ sites: SITES }); };
const $ = (id) => document.getElementById(id);
const t = () => I18N[S.lang] || I18N.fa;
const locale = () => `${S.lang === "fa" ? "fa-IR" : "en-US"}-u-ca-${S.cal}-nu-latn`;

function normUrl(u) { u = (u || "").trim(); return /^https?:\/\//i.test(u) ? u : "https://" + u; }

// CRITICAL FIX: The (err) variable MUST be present to avoid SyntaxError in older browsers.
function hostOf(u) { try { return new URL(normUrl(u)).hostname; } catch (err) { return ""; } }

function faviconUrl(u) { return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(hostOf(u))}&sz=64`; }

// ================= ICON SYSTEM =================
// 1) UI line icons (24x24). Used in menus, settings and the Start menu.
const UI = {
  search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.8 3 2.8 15 0 18M12 3c-2.8 3-2.8 15 0 18"/>',
  palette: '<path d="M12 3a9 9 0 1 0 0 18c1.2 0 2-.8 2-1.8 0-.5-.2-.9-.5-1.3-.3-.4-.5-.8-.5-1.3 0-1 .8-1.8 1.8-1.8H17a4 4 0 0 0 4-4C21 6.6 17 3 12 3z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10.5" cy="7" r="1"/><circle cx="15.5" cy="7.5" r="1"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="9" cy="10" r="1.8"/><path d="M21 16l-5-5L5 20"/>',
  monitor: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
  windows: '<rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="8" rx="1.5"/><rect x="3" y="13" width="8" height="8" rx="1.5"/><rect x="13" y="13" width="8" height="8" rx="1.5"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
  sliders: '<path d="M3 6h9M18 6h3M3 12h3M12 12h9M3 18h11M20 18h1"/><circle cx="15" cy="6" r="2.2"/><circle cx="9" cy="12" r="2.2"/><circle cx="17" cy="18" r="2.2"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  moveFolder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 13h6M13 11l2 2-2 2"/>',
  moveOut: '<path d="M12 19V6M7 11l5-5 5 5M5 21h14"/>',
  note: '<path d="M5 4h14v10l-6 6H5z"/><path d="M13 20v-5a1 1 0 0 1 1-1h5"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.2"/>',
  grid: '<path d="M3 3h18v18H3zM3 9h18M3 15h18M9 3v18M15 3v18"/>',
  arrange: '<path d="M5 9l-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M2 12h20M12 2v20"/>',
  gear: '<circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  puzzle: '<path d="M10 4a2 2 0 1 1 4 0v1h4a1 1 0 0 1 1 1v4h-1a2 2 0 1 0 0 4h1v4a1 1 0 0 1-1 1h-4v-1a2 2 0 1 0-4 0v1H6a1 1 0 0 1-1-1v-4h1a2 2 0 1 0 0-4H5V6a1 1 0 0 1 1-1h4z"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',
  film: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/>',
  reset: '<path d="M3 7v6h6"/><path d="M3 13a9 9 0 1 0 3-7.7L3 8"/>',
  sparkles: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16v4M17 18h4"/>',
  external: '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
  tab: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 9h18M8 5v4"/>',
  appwin: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M6.5 6.5h.01M9.5 6.5h.01"/>',
  newwin: '<rect x="3" y="7" width="14" height="13" rx="2"/><path d="M8 7V5a1 1 0 0 1 1-1h11a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1h-3"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  qr: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3M21 14v.01M14 21h3M21 17v4"/>',
  pin: '<path d="M12 17v5M8 3h8l-1 6 3 4H6l3-4z"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h8"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  minimize: '<path d="M6 12h12"/>',
  maximize: '<rect x="5" y="5" width="14" height="14" rx="1.5"/>',
  sizeS: '<rect x="8" y="8" width="8" height="8" rx="1.5"/>',
  sizeM: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 12h6"/>',
  sizeL: '<rect x="3.5" y="3.5" width="17" height="17" rx="2.5"/><path d="M8 12h8M12 8v8"/>',
  calc: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01"/>',
  theme: '<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor"/>',
  cloud: '<path d="M7 18a4 4 0 0 1-.5-7.97A5.5 5.5 0 0 1 17 9a4.5 4.5 0 0 1 0 9z"/>',
  download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  history: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5M12 7v5l3 2"/>',
  star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
  mapPin: '<path d="M12 21s7-6.2 7-11a7 7 0 0 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
  translate: '<path d="M4 5h9M8.5 3v2M6 5c.5 4 3 7 6.5 8.5M12 5c-.5 4-3 7-7 9"/><path d="M12 20l4.5-10 4.5 10M13.8 16.5h5.4"/>',
  doc: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 12h6M9 16h6"/>',
  table: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 15h18M9 4v16"/>',
  slides: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  play: '<rect x="3" y="5" width="18" height="14" rx="4"/><path d="M10 9.5v5l4.5-2.5z" fill="currentColor"/>',
  drive: '<path d="M9 3h6l6 10.5-3 5.5H6l-3-5.5z"/><path d="M9 3l6 10.5h6M3 13.5h12l3 5.5"/>',
  code: '<path d="M8 8l-5 4 5 4M16 8l5 4-5 4M14 5l-4 14"/>',
  book: '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 21V5M8 7h7"/>',
  camera: '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><path d="M17.5 6.5h.01"/>',
  send: '<path d="M21 3L10 14M21 3l-7 18-4-8-8-4z"/>',
  x: '<path d="M4 4l16 16M20 4L4 20"/>',
  briefcase: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2M3 13h18"/>',
  music: '<path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
  bag: '<path d="M5 8h14l-1 12H6zM9 8a3 3 0 0 1 6 0"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  video: '<rect x="3" y="6" width="12" height="12" rx="2"/><path d="M15 10l6-3v10l-6-3z"/>',
  news: '<path d="M4 5h13v14H6a2 2 0 0 1-2-2zM17 9h3v8a2 2 0 0 1-2 2M8 9h5M8 13h5"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
  hourglass: '<path d="M6 3h12M6 21h12M7 3c0 5 5 6 5 9s-5 4-5 9M17 3c0 5-5 6-5 9s5 4 5 9"/>',
  stopwatch: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M9 2h6"/>',
  check: '<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M8 12l3 3 5-6"/>',
  layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  type: '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',
  drop: '<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/>',
  layout: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M9 10v10"/>'
};
const svgI = (name, size = 18) => `<svg class="ui-i" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${UI[name] || ""}</svg>`;
const uiIcon = (v, size) => (UI[v] ? svgI(v, size) : v || "");

// 2) Site icons. A site gets: its own picture (if the user set one) -> a drawn brand icon (Gmail, Maps, Drive...)
//    -> the site favicon -> a coloured letter. Domains that hold many services (google.com, microsoft.com...)
//    never use the favicon, because it is the same for every sub-site.
const AMBIG = /(^|\.)(google|microsoft|live|office|yahoo|apple|amazon|zoho|atlassian|adobe|bing|msn)\.[a-z.]+$/i;
const BRANDS = [
  { h: /^(mail\.google\.[a-z.]+|(www\.)?gmail\.com)$/, g: "mail", c: ["#f0524a", "#c5221f"] },
  { h: /^maps\.google\.[a-z.]+$/, g: "mapPin", c: ["#3cba5f", "#1e8e3e"] },
  { h: /^(www\.)?google\.[a-z.]+$/, p: /^\/maps/, g: "mapPin", c: ["#3cba5f", "#1e8e3e"] },
  { h: /^translate\.google\.[a-z.]+$/, g: "translate", c: ["#4d8ff6", "#1a5fd0"] },
  { h: /^drive\.google\.[a-z.]+$/, g: "drive", c: ["#f9bc15", "#0f9d58"] },
  { h: /^docs\.google\.[a-z.]+$/, p: /^\/spreadsheets/, g: "table", c: ["#2fb36d", "#0b8043"] },
  { h: /^docs\.google\.[a-z.]+$/, p: /^\/presentation/, g: "slides", c: ["#f8c134", "#e37400"] },
  { h: /^docs\.google\.[a-z.]+$/, p: /^\/forms/, g: "check", c: ["#9a6ae6", "#673ab7"] },
  { h: /^docs\.google\.[a-z.]+$/, g: "doc", c: ["#4d8ff6", "#1a5fd0"] },
  { h: /^calendar\.google\.[a-z.]+$/, g: "calendar", c: ["#4d8ff6", "#1a73e8"] },
  { h: /^photos\.google\.[a-z.]+$/, g: "image", c: ["#f4b400", "#ea4335"] },
  { h: /^meet\.google\.[a-z.]+$/, g: "video", c: ["#26a69a", "#00796b"] },
  { h: /^keep\.google\.[a-z.]+$/, g: "note", c: ["#fbc02d", "#f29900"] },
  { h: /^news\.google\.[a-z.]+$/, g: "news", c: ["#5b9cf6", "#2f6fd6"] },
  { h: /^scholar\.google\.[a-z.]+$/, g: "book", c: ["#5b8def", "#2a5bd7"] },
  { h: /^(gemini|bard)\.google\.[a-z.]+$/, g: "sparkles", c: ["#6f8cff", "#8b5cf6"] },
  { h: /^(www\.)?google\.[a-z.]+$/, g: "search", c: ["#4d8ff6", "#1a5fd0"] },
  { h: /^music\.youtube\.com$/, g: "music", c: ["#ff5a4f", "#c4001f"] },
  { h: /(^|\.)(youtube\.com|youtu\.be)$/, g: "play", c: ["#ff3b3b", "#c4001f"] },
  { h: /(^|\.)github\.(com|io)$/, g: "code", c: ["#3b4350", "#0d1117"] },
  { h: /(^|\.)wikipedia\.org$/, g: "book", c: ["#7b8494", "#394150"] },
  { h: /(^|\.)instagram\.com$/, g: "camera", c: ["#f09433", "#bc1888"] },
  { h: /^(web\.telegram\.org|t\.me|telegram\.org)$/, g: "send", c: ["#35b0ee", "#1f8fd0"] },
  { h: /(^|\.)(x\.com|twitter\.com)$/, g: "x", c: ["#2b2f36", "#000000"] },
  { h: /(^|\.)linkedin\.com$/, g: "briefcase", c: ["#2a7fd4", "#0a559e"] },
  { h: /(^|\.)spotify\.com$/, g: "music", c: ["#2bd45f", "#14903f"] },
  { h: /(^|\.)(facebook\.com|messenger\.com)$/, g: "chat", c: ["#3b8bff", "#0c5bd0"] },
  { h: /(^|\.)(whatsapp\.com|wa\.me)$/, g: "chat", c: ["#3ddc7c", "#1aa55a"] },
  { h: /(^|\.)(reddit\.com)$/, g: "chat", c: ["#ff6a33", "#d93a00"] },
  { h: /(^|\.)(discord\.com|discord\.gg)$/, g: "chat", c: ["#7983f5", "#4752c4"] },
  { h: /(^|\.)twitch\.tv$/, g: "play", c: ["#a970ff", "#6d34c9"] },
  { h: /(^|\.)netflix\.com$/, g: "play", c: ["#f0202d", "#a30008"] },
  { h: /(^|\.)aparat\.com$/, g: "play", c: ["#f0356f", "#c4073f"] },
  { h: /(^|\.)(amazon\.[a-z.]+)$/, g: "bag", c: ["#ffb02e", "#e47911"] },
  { h: /(^|\.)digikala\.com$/, g: "bag", c: ["#f2525f", "#c91d2b"] },
  { h: /(^|\.)stackoverflow\.com$/, g: "code", c: ["#f79a3e", "#d9650a"] },
  { h: /(^|\.)(chatgpt\.com|openai\.com)$/, g: "sparkles", c: ["#1fbf95", "#0c8a68"] },
  { h: /(^|\.)claude\.ai$/, g: "sparkles", c: ["#e48b6b", "#c3593a"] },
  { h: /^(outlook\.(live|office|office365)\.com|outlook\.com)$/, g: "mail", c: ["#3d9be9", "#0b5cb5"] },
  { h: /^onedrive\.(live|office)\.com$/, g: "cloud", c: ["#3d9be9", "#0b5cb5"] }
];
function siteParts(site) { try { const u = new URL(normUrl(site.url)); return { host: u.hostname.toLowerCase(), path: u.pathname }; } catch (err) { return { host: "", path: "" }; } }
const brandFor = (host, path) => BRANDS.find((b) => b.h.test(host) && (!b.p || b.p.test(path)));
const hashStr = (s) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); };
const sicoCls = (cls, extra) => cls + " sico" + (extra ? " " + extra : "") + (cls === "tile" ? " letter" : "");
function letterTile(site, cls) {
  const { host, path } = siteParts(site), hue = hashStr(host + (path.split("/")[1] || "")) % 360;
  const d = document.createElement("div"); d.className = sicoCls(cls);
  d.textContent = (Array.from((site.name || host || "?").trim())[0] || "?").toUpperCase();
  d.style.background = `linear-gradient(145deg, hsl(${hue} 72% 56%), hsl(${(hue + 28) % 360} 70% 40%))`;
  return d;
}
function glyphTile(txt, cls) {
  const d = document.createElement("div"); d.className = sicoCls(cls, "emo"); d.textContent = Array.from(txt).slice(0, 2).join("");
  d.style.background = "rgba(255,255,255,.92)"; return d;
}
function brandTile(b, cls) {
  const d = document.createElement("div"); d.className = sicoCls(cls, "brand"); d.innerHTML = svgI(b.g, 24);
  d.style.background = `linear-gradient(145deg, ${b.c[0]}, ${b.c[1]})`; d.style.color = "#fff"; return d;
}
function imgTile(src, site, cls, fb) {
  const img = document.createElement("img"); img.className = cls; img.alt = ""; img.draggable = false; img.referrerPolicy = "no-referrer"; img.src = src;
  img.onerror = () => img.replaceWith(fb ? fb() : letterTile(site, cls)); return img;
}
// Drawn glyph / letter: only a fallback while (or if) the real icon of the site is not available.
const fallbackTile = (site, cls) => { const { host, path } = siteParts(site), b = brandFor(host, path); return b ? brandTile(b, cls) : letterTile(site, cls); };

// Real icons of sub-sites (mail.google.com, maps.google.com...): the favicon service returns the same picture for a whole
// domain, so we first read the icon the page itself declares (<link rel="icon">), then a few known places.
// The result is kept only if it differs from the domain-level picture.
const ICON_CACHE = (() => { try { return JSON.parse(localStorage.getItem("w11icons2") || "{}"); } catch (err) { return {}; } })();
const iconPending = new Map();
const iconKey = (site) => { const { host, path } = siteParts(site); return host + "/" + (path.split("/")[1] || ""); };
const rdDataUrl = (b) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(b); });

// Blob -> small PNG data URL (null if it is not a usable picture).
async function iconBlobToData(blob, px = 64) {
  if (!blob || !blob.size || blob.size > 2e6) return null;
  if (blob.type && !/^image\//i.test(blob.type) && blob.type !== "application/octet-stream") return null; // e.g. an HTML error page
  const url = URL.createObjectURL(blob);
  try {
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
    const w = img.naturalWidth, h = img.naturalHeight;
    if (!w || !h) return await rdDataUrl(blob); // SVG without a size
    if (w < 16 || h < 16) return null;
    const k = Math.min(1, px / Math.max(w, h)), c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(w * k)); c.height = Math.max(1, Math.round(h * k));
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL("image/png");
  } catch (err) { return null; } finally { URL.revokeObjectURL(url); }
}
async function fetchIconData(src, px) {
  const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 8000);
  try { const r = await fetch(src, { credentials: "omit", signal: ctl.signal }); return r.ok ? await iconBlobToData(await r.blob(), px) : null; }
  catch (err) { return null; } finally { clearTimeout(to); }
}
// Icons written in the page head. Returns null on a network problem, [] when the page declares none.
async function pageIconLinks(url) {
  const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 8000);
  try {
    const r = await fetch(url, { credentials: "omit", signal: ctl.signal });
    if (!r.ok) return [];
    const doc = new DOMParser().parseFromString((await r.text()).slice(0, 400000), "text/html"), out = [];
    doc.querySelectorAll("link[rel]").forEach((l) => {
      const rel = (l.getAttribute("rel") || "").toLowerCase(), href = l.getAttribute("href");
      if (!href || !/(^|\s)(icon|shortcut|apple-touch-icon(-precomposed)?|mask-icon)(\s|$)/.test(rel)) return;
      try { out.push({ src: new URL(href, r.url).href, rel, size: parseInt((l.getAttribute("sizes") || "").split("x")[0], 10) || 0 }); } catch (err) {}
    });
    return out;
  } catch (err) { return null; } finally { clearTimeout(to); }
}
// Official product icons of Google services (a wrong guess is simply skipped, because every candidate is test-loaded).
function googleKnownIcons(host, path) {
  if (!/(^|\.)google\.[a-z.]+$/.test(host)) return [];
  const sub = host.split(".")[0], p = path.split("/")[1] || "";
  const prod = sub === "docs" ? ({ spreadsheets: "sheets", presentation: "slides", forms: "forms" }[p] || "docs") : sub === "mail" ? "gmail" : (sub === "www" && p === "maps") ? "maps" : sub;
  const out = [`https://www.gstatic.com/images/branding/product/2x/${prod}_48dp.png`, `https://www.gstatic.com/images/branding/product/2x/${prod}_2020q4_48dp.png`];
  if (prod === "translate") out.push("https://ssl.gstatic.com/translate/favicon.ico");
  if (prod === "maps") out.push("https://www.google.com/images/branding/product/ico/maps15_bnuw3a_32dp.ico");
  return out;
}
function realIcon(site) {
  const key = iconKey(site); if (iconPending.has(key)) return iconPending.get(key);
  const { host, path } = siteParts(site), full = new URL(normUrl(site.url)).href, enc = encodeURIComponent;
  const p = (async () => {
    try {
      const base = await fetchIconData(`https://www.google.com/s2/favicons?sz=64&domain=${enc(host)}`);
      const links = await pageIconLinks(full);
      const cands = (links || []).filter((l) => !/mask-icon/.test(l.rel)).sort((a, b) => b.size - a.size).map((l) => l.src);
      cands.push(...googleKnownIcons(host, path), `https://www.google.com/s2/favicons?sz=64&domain_url=${enc(full)}`);
      let good = 0;
      for (const src of cands) { const d = await fetchIconData(src); if (d && d !== base) { good = d; break; } }
      if (!good && links === null && base === null) return 0; // network problem: do not remember, try again next time
      ICON_CACHE[key] = good; try { localStorage.setItem("w11icons2", JSON.stringify(ICON_CACHE)); } catch (err) {}
      return good;
    } catch (err) { return 0; }
  })();
  iconPending.set(key, p); return p;
}

// ---- Icon picker (site dialog): collects several real icons of the site, the user chooses one ----
async function collectIconCandidates(url, onItem) {
  let u; try { u = new URL(normUrl(url)); } catch (err) { return; }
  const seen = new Set(), host = u.hostname.toLowerCase(), enc = encodeURIComponent, jobs = [];
  const push = async (label, src) => { const d = await fetchIconData(src); if (d && !seen.has(d)) { seen.add(d); onItem({ label, data: d }); } };
  jobs.push((async () => { const links = await pageIconLinks(u.href); if (links) await Promise.all(links.filter((l) => !/mask-icon/.test(l.rel)).map((l) => push(/apple/.test(l.rel) ? "apple-touch-icon" : "favicon", l.src))); })());
  try { const f = new URL(chrome.runtime.getURL("/_favicon/")); f.searchParams.set("pageUrl", u.href); f.searchParams.set("size", "64"); jobs.push(push("Chrome", f.href)); } catch (err) {}
  googleKnownIcons(host, u.pathname).forEach((src) => jobs.push(push("Google", src)));
  jobs.push(
    push("favicon.ico", u.origin + "/favicon.ico"),
    push("apple-touch-icon", u.origin + "/apple-touch-icon.png"),
    push("Google", `https://www.google.com/s2/favicons?sz=64&domain_url=${enc(u.href)}`),
    push("Google", `https://www.google.com/s2/favicons?sz=64&domain=${enc(host)}`),
    push("DuckDuckGo", `https://icons.duckduckgo.com/ip3/${host}.ico`)
  );
  await Promise.all(jobs);
}
let iconCandToken = 0;
function refreshIconCandidates() {
  const box = $("iconCands"); if (!box) return;
  const token = ++iconCandToken, url = $("siteUrl").value; box.innerHTML = "";
  if (!hostOf(url) || !hostOf(url).includes(".")) return;
  const note = document.createElement("span"); note.className = "icon-note"; note.textContent = t().iconSearching; box.appendChild(note);
  let count = 0;
  collectIconCandidates(url, (c) => {
    if (token !== iconCandToken) return;
    if (!count++) note.remove();
    const b = document.createElement("button"); b.type = "button"; b.className = "icon-cand"; b.title = c.label; b.dataset.data = c.data;
    if ($("siteIcon").value.trim() === c.data) b.classList.add("on");
    const im = document.createElement("img"); im.src = c.data; im.alt = ""; im.draggable = false; b.appendChild(im);
    b.onclick = () => { $("siteIcon").value = c.data; box.querySelectorAll(".icon-cand").forEach((x) => x.classList.toggle("on", x === b)); updatePreview(); };
    box.appendChild(b);
  }).then(() => { if (token === iconCandToken && !count) note.textContent = t().iconNone; });
}
function makeSiteIcon(site, cls = "tile") {
  const ic = (site.icon || "").trim();
  if (/^(https?:\/\/|data:image\/)/i.test(ic)) return imgTile(ic, site, cls);
  if (ic) return glyphTile(ic, cls);
  const { host } = siteParts(site), fb = () => fallbackTile(site, cls);
  if (!AMBIG.test(host)) return imgTile(faviconUrl(site.url), site, cls, fb); // the real favicon of the site (YouTube, Spotify, GitHub...)
  const key = iconKey(site);
  if (typeof ICON_CACHE[key] === "string") return imgTile(ICON_CACHE[key], site, cls, fb);
  const el = fb();
  if (ICON_CACHE[key] !== 0) realIcon(site).then((src) => { if (src && el.isConnected) el.replaceWith(imgTile(src, site, cls, fb)); });
  return el;
}

// 3) Settings: a small icon in front of every row.
const ROW_ICO = { setLang: "translate", setEngine: "search", setAutoTheme: "sparkles", setGlass: "layers", setTheme: "theme", accentPalette: "palette", setFont: "type", customFontGroup: "type", setBlur: "drop", pickWallpaper: "image", wpNextBtn: "refresh", wpOnlineBtn: "globe", wpLiveBtn: "film", setShowHero: "clock", setShort: "grid", setHeroStyle: "layout", setHeroInfo: "cloud", setHeroQuick: "star", setIconSize: "maximize", setLabels: "tag", setSnapGrid: "grid", setDragFolder: "folder", setSettingsIcon: "gear", autoArrangeBtn: "arrange", setStartRecent: "history", clearRecentBtn: "trash", resetStartSizeBtn: "maximize", resetPinnedBtn: "pin", setCal: "calendar", setH24: "clock", setSec: "clock", setTraySec: "clock", setCity: "mapPin", setOpenMode: "external", aboutVer: "info", openAccountBtn: "user", resetSettings: "reset" };
const WIDGET_UI = { weather: "cloud", clock: "globe", calendar: "calendar", progress: "chart", timer: "hourglass", stopwatch: "stopwatch", calc: "calc", todo: "check", notes: "note", translate: "translate" };
function decorateSettings() {
  const br = $("setBrandIco"); if (br) br.innerHTML = svgI("gear", 22);
  document.querySelectorAll("#setContent .row").forEach((row) => {
    if (row.querySelector(".row-ico")) return;
    const c = row.id ? row : row.querySelector("[id], [data-action]"), key = c ? c.id || c.dataset.action : "";
    if (!ROW_ICO[key]) return;
    const ico = document.createElement("span"); ico.className = "row-ico"; ico.innerHTML = svgI(ROW_ICO[key], 18);
    if (row.classList.contains("column-row")) row.querySelector(".row-text").prepend(ico); else row.prepend(ico);
  });
}

function showWinModal(title, msg, onConfirm) {
  const modal = $("winDialogModal");
  if (!modal) return;
  $("winDialogTitle").textContent = title;
  $("winDialogMsg").textContent = msg;
  $("winDialogCancel").style.display = onConfirm ? "inline-block" : "none";
  modal.classList.remove("hidden");
  const close = () => modal.classList.add("hidden");
  $("winDialogConfirm").onclick = () => { close(); if (onConfirm) onConfirm(); };
  $("winDialogCancel").onclick = close;
}

// ---- Auto theme: colours are taken from the wallpaper ----
let AUTO = null, autoRun = 0;
const rgb2hsl = (r, g, b) => {
  r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2; let h = 0, s = 0;
  if (mx !== mn) { const d = mx - mn; s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60; }
  return [h, s, l];
};
const hsl2hex = (h, s, l) => { const a = s * Math.min(l, 1 - l), f = (n) => { const k = (n + h / 30) % 12, c = l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); return Math.round(255 * c).toString(16).padStart(2, "0"); }; return "#" + f(0) + f(8) + f(4); };
const relLum = (r, g, b) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
function colorsFromPixels(data) {
  let R = 0, G = 0, B = 0, n = 0; const bins = Array.from({ length: 24 }, () => ({ w: 0, r: 0, g: 0, b: 0 }));
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2]; R += r; G += g; B += b; n++;
    const [h, s, l] = rgb2hsl(r, g, b); if (s < 0.2 || l < 0.12 || l > 0.92) continue; // skip grey, black and white pixels
    const w = s * (1 - Math.abs(l - 0.5) * 1.2), bn = bins[Math.floor(h / 15) % 24]; bn.w += w; bn.r += r * w; bn.g += g * w; bn.b += b * w;
  }
  const avg = [R / n, G / n, B / n].map(Math.round), best = bins.reduce((a, b) => (b.w > a.w ? b : a));
  let hue = 205, sat = 0.85; // a grey picture keeps the blue accent
  if (best.w > n * 0.01) { const [h, s] = rgb2hsl(best.r / best.w, best.g / best.w, best.b / best.w); hue = h; sat = Math.max(0.55, Math.min(0.95, s)); }
  const hex = hsl2hex(hue, sat, 0.62), dim = hsl2hex(hue, sat, 0.52), dark = hsl2hex(hue, sat, 0.4);
  const hl = relLum(parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16));
  return { accent: { hex, dim, dark, text: hl > 0.3 ? "#0b1220" : "#ffffff" }, tint: avg, lum: relLum(...avg) };
}
const loadImg = (src, cors) => new Promise((res, rej) => { const i = new Image(); if (cors) i.crossOrigin = "anonymous"; i.onload = () => res(i); i.onerror = rej; i.src = src; });
async function pixelsFromSrc(src) {
  let bmp;
  try {
    if (/^https?:/i.test(src)) bmp = await createImageBitmap(await (await fetch(src)).blob()); // the extension may read any site, so the canvas stays clean
    else bmp = await loadImg(src);
  } catch (e) { bmp = await loadImg(src, true); }
  const cv = document.createElement("canvas"); cv.width = 64; cv.height = 36;
  const c = cv.getContext("2d", { willReadFrequently: true }); c.drawImage(bmp, 0, 0, 64, 36); return c.getImageData(0, 0, 64, 36).data;
}
const wpKey = (s) => (s.startsWith("data:") ? "data:" + s.length + ":" + s.slice(-48) : s);
async function refreshAutoTheme(force) {
  if (S.autoTheme === false) return;
  const run = ++autoRun; let key, pix;
  try {
    if (S.wpLive) {
      key = "live:" + (S.wpLive.url || S.wpLive.name);
      if (!force && S.autoColors && S.autoColors.key === key) { AUTO = S.autoColors; applyThemeAndAccent(); return; }
      const v = $("wallpaperVideo");
      try { // frame of the video (blocked for some remote videos)
        if (!v || !v.videoWidth) throw 0;
        const cv = document.createElement("canvas"); cv.width = 64; cv.height = 36; const c = cv.getContext("2d", { willReadFrequently: true }); c.drawImage(v, 0, 0, 64, 36); pix = c.getImageData(0, 0, 64, 36).data;
      } catch (e) { if (!S.wpLive.thumb) return; pix = await pixelsFromSrc(S.wpLive.thumb); }
    } else {
      const src = WALLPAPER || S.wpUrl || WP_DEFAULT; key = wpKey(src);
      if (!force && S.autoColors && S.autoColors.key === key) { AUTO = S.autoColors; applyThemeAndAccent(); return; }
      pix = await pixelsFromSrc(src);
    }
  } catch (e) { return; }
  if (run !== autoRun) return;
  const c = colorsFromPixels(pix); c.key = key; AUTO = c; S.autoColors = c; saveSettings(); applyThemeAndAccent();
}

// ---- Glass: blur, see-through level and a tint from the wallpaper ----
const mixRgb = (a, b, t) => a.map((v, i) => Math.round(v * (1 - t) + b[i] * t));
function applyGlass(theme) {
  const g = Math.max(0, Math.min(100, Number(S.glass == null ? 55 : S.glass))) / 100, dark = theme === "dark", root = document.documentElement.style;
  const tint = S.autoTheme !== false && AUTO && AUTO.tint ? AUTO.tint : null, t = (rgb, k) => (tint ? mixRgb(rgb, tint, k) : rgb);
  const aP = dark ? 0.8 - g * 0.42 : 0.82 - g * 0.4;
  root.setProperty("--glass-blur", Math.round(6 + g * 34) + "px"); root.setProperty("--glass-sat", Math.round(130 + g * 110) + "%");
  root.setProperty("--bg-glass-panel", `rgba(${t(dark ? [26, 31, 44] : [255, 255, 255], dark ? 0.3 : 0.22).join(",")},${aP.toFixed(2)})`);
  root.setProperty("--bg-glass-taskbar", `rgba(${t(dark ? [14, 18, 28] : [255, 255, 255], dark ? 0.26 : 0.2).join(",")},${Math.min(0.95, aP + 0.1).toFixed(2)})`);
  root.setProperty("--bg-glass-input", `rgba(${t(dark ? [10, 13, 22] : [255, 255, 255], 0.18).join(",")},${dark ? 0.55 : 0.78})`);
  root.setProperty("--win-bg", `rgb(${t(dark ? [24, 29, 42] : [242, 245, 250], 0.14).join(",")})`);
}

function applyThemeAndAccent() {
  const auto = S.autoTheme !== false && AUTO ? AUTO : null;
  const theme = auto ? (auto.lum > 0.38 ? "light" : "dark") : (S.theme || "dark");
  document.documentElement.setAttribute("data-theme", theme);
  const manual = ACCENT_COLORS.find(c => c.hex.toLowerCase() === (S.accent || "").toLowerCase()) || ACCENT_COLORS[0];
  const colorObj = auto ? auto.accent : manual;
  document.documentElement.style.setProperty("--accent", colorObj.hex);
  document.documentElement.style.setProperty("--accent-dim", colorObj.dim);
  document.documentElement.style.setProperty("--accent-dark", colorObj.dark);
  document.documentElement.style.setProperty("--accent-text", colorObj.text);
  applyGlass(theme);

  let fontFam = '"Baloo Bhaijaan 2", "Rubik", -apple-system, sans-serif';
  if (S.font === "puffy") fontFam = '"Baloo Bhaijaan 2", "Rubik", "Vazirmatn", -apple-system, sans-serif';
  else if (S.font === "rubik") fontFam = '"Rubik", "Vazirmatn", -apple-system, sans-serif';
  else if (S.font === "segoe") fontFam = '"Segoe UI", Tahoma, Geneva, Verdana, sans-serif';
  else if (S.font === "custom" && S.customFont && S.customFont.trim()) fontFam = `"${S.customFont.trim()}", "Baloo Bhaijaan 2", "Rubik", sans-serif`;
  
  document.documentElement.style.setProperty("--system-font", fontFam);
  document.body.style.fontFamily = fontFam;

  const palette = $("accentPalette");
  if (palette) {
    palette.innerHTML = "";
    ACCENT_COLORS.forEach(c => {
      const b = document.createElement("button");
      b.className = "accent-swatch" + (!auto && c.hex.toLowerCase() === colorObj.hex.toLowerCase() ? " active" : "");
      b.style.backgroundColor = c.hex; b.title = c.name;
      b.onclick = () => { S.accent = c.hex; saveSettings(); applyThemeAndAccent(); };
      palette.appendChild(b);
    });
  }
}

function tick() {
  try {
    const now = new Date();
    const loc = locale();
    const opts = { hour: "2-digit", minute: "2-digit", hour12: !S.h24 };
    if (S.sec) opts.second = "2-digit";

    if ($("clock")) $("clock").textContent = now.toLocaleTimeString(loc, opts);
    if ($("date")) $("date").textContent = now.toLocaleDateString(loc, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
    if ($("trayTime")) $("trayTime").textContent = now.toLocaleTimeString(loc, { hour: "2-digit", minute: "2-digit", ...(S.traySeconds ? { second: "2-digit" } : {}), hour12: !S.h24 });
    if ($("trayDate")) $("trayDate").textContent = now.toLocaleDateString(loc);
    if ($("trayFlyoutClock")) $("trayFlyoutClock").textContent = now.toLocaleTimeString(loc, opts);
    if ($("trayFlyoutDate")) $("trayFlyoutDate").textContent = now.toLocaleDateString(loc, { weekday: "long", day: "numeric", month: "long", year: "numeric" });

    tickHero(now, loc);
    document.querySelectorAll("[data-tz]").forEach((el) => {
      el.textContent = now.toLocaleTimeString(loc, { hour: "2-digit", minute: "2-digit", hour12: !S.h24, timeZone: el.dataset.tz });
    });
  } catch (err) {}
}

function initCenterHero() {
  const hero = $("desktopHero");
  const handle = $("heroDragHandle");
  const closeBtn = $("closeHeroBtn");
  if (!hero || !handle || !closeBtn) return;

  if (!S.hero.show) { hero.classList.add("hidden"); } else {
    hero.classList.remove("hidden");
    if (S.hero.x != null && S.hero.y != null) {
      hero.style.top = S.hero.y + "px"; hero.style.left = S.hero.x + "px"; hero.classList.add("moved");
    } else {
      hero.style.top = "42%"; hero.style.left = "50%"; hero.classList.remove("moved");
    }
  }

  hero.classList.add("ready"); // until now it stays invisible, so it never jumps from the default place
  closeBtn.onclick = (e) => { e.stopPropagation(); S.hero.show = false; saveSettings(); renderHeroState(); };

  let isDragging = false;
  let startX = 0, startY = 0, initLeft = 0, initTop = 0;

  handle.onpointerdown = (e) => {
    if (e.target.closest("button")) return;
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    
    const rect = hero.getBoundingClientRect();
    initLeft = rect.left;
    initTop = rect.top;
    
    hero.classList.add("moved");
    hero.style.left = initLeft + "px";
    hero.style.top = initTop + "px";
    
    hero.classList.add("is-dragging");

    const onMove = (ev) => {
      if (!isDragging) return;
      const dx = ev.clientX - startX;
      const dy = ev.clientY - startY;
      const nx = Math.max(10, Math.min(window.innerWidth - hero.offsetWidth * WS - 10, initLeft + dx));
      const ny = Math.max(10, Math.min(window.innerHeight - hero.offsetHeight * WS - 60, initTop + dy));
      hero.style.left = nx + "px";
      hero.style.top = ny + "px";
    };

    const onUp = () => {
      if (!isDragging) return;
      isDragging = false;
      hero.classList.remove("is-dragging");
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      S.hero.x = hero.offsetLeft;
      S.hero.y = hero.offsetTop;
      saveSettings();
    };

    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  };
}

function renderHeroState() {
  const hero = $("desktopHero"), chk = $("setShowHero"), icon = $("heroWidgetStateIcon");
  if (hero) hero.classList.toggle("hidden", !S.hero.show);
  if (chk) chk.checked = !!S.hero.show;
  if (icon) icon.textContent = S.hero.show ? "➖" : "➕";
}

const CELL_W = 86, CELL_H = 100, PADDING_TOP = 16, PADDING_SIDE = 16, TASKBAR_H = 56;
// Icon scale. Saved icon places are in "base units" (size at scale 1).
// SCALE gets smaller when the window gets smaller. Icons get smaller with it.
let SCALE = 1;
let WS = 1; // widget scale
function updateScale() {
  const W = window.innerWidth, H = window.innerHeight - TASKBAR_H;
  SCALE = Math.max(0.55, Math.min(1, W / 1280, H / 664));
  SCALE = Math.min(1.3, SCALE * ({ small: 0.85, large: 1.2 }[(typeof S !== "undefined" && S && S.iconSize) || "normal"] || 1));
  // Icons must not overlap. If the grid has too few cells, make the icons smaller.
  const n = (typeof SITES !== "undefined" && SITES) ? SITES.filter(isDesk).length : 0;
  const cells = (s) => Math.max(1, Math.floor((W / s - PADDING_SIDE * 2) / CELL_W)) * Math.max(1, Math.floor((H / s - PADDING_TOP) / CELL_H));
  while (SCALE > 0.4 && cells(SCALE) < n) SCALE = Math.max(0.4, +(SCALE - 0.02).toFixed(3));
  document.documentElement.style.setProperty("--is", SCALE.toFixed(3));
  WS = Math.max(0.6, Math.min(1, W / 1100, H / 640));
  document.documentElement.style.setProperty("--ws", WS.toFixed(3));
}
const baseW = () => window.innerWidth / SCALE;
const baseH = () => (window.innerHeight - TASKBAR_H) / SCALE;
const cellKey = (c, r) => c + "," + r;
function getGridBounds() {
  const maxRows = Math.max(1, Math.floor((baseH() - PADDING_TOP) / CELL_H));
  const maxCols = Math.max(1, Math.floor((baseW() - PADDING_SIDE * 2) / CELL_W));
  return { maxRows, maxCols };
}
// x = distance from the START edge (right edge in Persian, left edge in English).
function gridToPixels(col, row) {
  return { x: PADDING_SIDE + col * CELL_W, y: PADDING_TOP + row * CELL_H };
}
function pixelsToGrid(x, y) {
  return { col: Math.max(0, Math.round((x - PADDING_SIDE) / CELL_W)), row: Math.max(0, Math.round((y - PADDING_TOP) / CELL_H)) };
}
const isDesk = (s) => !s.parent;

// ===== Small offline QR code generator (byte mode, level M, versions 1-10) =====
const QR = (() => {
  const ECC_LEN = [0, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26], BLOCKS = [0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5];
  const bit = (x, i) => ((x >>> i) & 1) !== 0;
  const rawModules = (v) => { let r = (16 * v + 128) * v + 64; if (v >= 2) { const n = Math.floor(v / 7) + 2; r -= (25 * n - 10) * n - 55; if (v >= 7) r -= 36; } return r; };
  const gfMul = (x, y) => { let z = 0; for (let i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11d); z ^= ((y >>> i) & 1) * x; } return z; };
  const rsDiv = (d) => { const r = new Array(d).fill(0); r[d - 1] = 1; let root = 1; for (let i = 0; i < d; i++) { for (let j = 0; j < r.length; j++) { r[j] = gfMul(r[j], root); if (j + 1 < r.length) r[j] ^= r[j + 1]; } root = gfMul(root, 2); } return r; };
  const rsRem = (data, div) => { const r = div.map(() => 0); data.forEach((b) => { const f = b ^ r.shift(); r.push(0); div.forEach((c, i) => { r[i] ^= gfMul(c, f); }); }); return r; };
  const utf8 = (s) => Array.from(unescape(encodeURIComponent(s)), (c) => c.charCodeAt(0));

  function encode(text) {
    const bytes = utf8(text); let ver = 0, dataCap = 0;
    for (let v = 1; v <= 10; v++) {
      dataCap = Math.floor(rawModules(v) / 8) - ECC_LEN[v] * BLOCKS[v];
      if (4 + (v < 10 ? 8 : 16) + bytes.length * 8 <= dataCap * 8) { ver = v; break; }
    }
    if (!ver) return null;
    const bits = []; const put = (val, n) => { for (let i = n - 1; i >= 0; i--) bits.push((val >>> i) & 1); };
    put(4, 4); put(bytes.length, ver < 10 ? 8 : 16); bytes.forEach((b) => put(b, 8));
    put(0, Math.min(4, dataCap * 8 - bits.length)); put(0, (8 - (bits.length % 8)) % 8);
    for (let p = 0xec; bits.length < dataCap * 8; p ^= 0xec ^ 0x11) put(p, 8);
    const data = []; for (let i = 0; i < bits.length; i += 8) data.push(parseInt(bits.slice(i, i + 8).join(""), 2));

    // blocks + error correction, interleaved
    const nb = BLOCKS[ver], eccLen = ECC_LEN[ver], raw = Math.floor(rawModules(ver) / 8), nShort = nb - (raw % nb), shortLen = Math.floor(raw / nb), div = rsDiv(eccLen);
    const blocks = []; for (let i = 0, k = 0; i < nb; i++) {
      const dl = shortLen - eccLen + (i < nShort ? 0 : 1), dat = data.slice(k, k + dl); k += dl;
      const ecc = rsRem(dat, div); if (i < nShort) dat.push(0); blocks.push(dat.concat(ecc));
    }
    const all = []; for (let i = 0; i < blocks[0].length; i++) blocks.forEach((b, j) => { if (i !== shortLen - eccLen || j >= nShort) all.push(b[i]); });

    const size = ver * 4 + 17, mod = Array.from({ length: size }, () => new Array(size).fill(false)), fn = Array.from({ length: size }, () => new Array(size).fill(false));
    const set = (x, y, v) => { mod[y][x] = v; fn[y][x] = true; };
    for (let i = 0; i < size; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
    const finder = (x, y) => { for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) { const d = Math.max(Math.abs(dx), Math.abs(dy)), xx = x + dx, yy = y + dy; if (xx >= 0 && xx < size && yy >= 0 && yy < size) set(xx, yy, d !== 2 && d !== 4); } };
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
    let pos = []; if (ver > 1) { const n = Math.floor(ver / 7) + 2, step = Math.ceil((ver * 4 + 4) / (n * 2 - 2)) * 2; pos = [6]; for (let p = size - 7; pos.length < n; p -= step) pos.splice(1, 0, p); }
    pos.forEach((a, i) => pos.forEach((b, j) => { if ((i === 0 && j === 0) || (i === 0 && j === pos.length - 1) || (i === pos.length - 1 && j === 0)) return; for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) set(a + dx, b + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1); }));
    const formatBits = (mask) => { const d = (0 << 3) | mask; let r = d; for (let i = 0; i < 10; i++) r = (r << 1) ^ ((r >>> 9) * 0x537); const b = ((d << 10) | r) ^ 0x5412;
      for (let i = 0; i <= 5; i++) set(8, i, bit(b, i)); set(8, 7, bit(b, 6)); set(8, 8, bit(b, 7)); set(7, 8, bit(b, 8)); for (let i = 9; i < 15; i++) set(14 - i, 8, bit(b, i));
      for (let i = 0; i < 8; i++) set(size - 1 - i, 8, bit(b, i)); for (let i = 8; i < 15; i++) set(8, size - 15 + i, bit(b, i)); set(8, size - 8, true); };
    formatBits(0);
    if (ver >= 7) { let r = ver; for (let i = 0; i < 12; i++) r = (r << 1) ^ ((r >>> 11) * 0x1f25); const b = (ver << 12) | r; for (let i = 0; i < 18; i++) { const a = size - 11 + (i % 3), c = Math.floor(i / 3); set(a, c, bit(b, i)); set(c, a, bit(b, i)); } }
    // place codewords
    let k = 0; for (let right = size - 1; right >= 1; right -= 2) { if (right === 6) right = 5; for (let v = 0; v < size; v++) for (let j = 0; j < 2; j++) { const x = right - j, up = ((right + 1) & 2) === 0, y = up ? size - 1 - v : v; if (!fn[y][x] && k < all.length * 8) { mod[y][x] = bit(all[k >>> 3], 7 - (k & 7)); k++; } } }
    const maskFn = [(x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, (x) => x % 3 === 0, (x, y) => (x + y) % 3 === 0, (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0, (x, y) => ((x * y) % 2) + ((x * y) % 3) === 0, (x, y) => (((x * y) % 2) + ((x * y) % 3)) % 2 === 0, (x, y) => (((x + y) % 2) + ((x * y) % 3)) % 2 === 0];
    const applyMask = (m) => { for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (!fn[y][x] && maskFn[m](x, y)) mod[y][x] = !mod[y][x]; };
    const penalty = () => { let p = 0;
      for (let y = 0; y < size; y++) { let run = 1; for (let x = 1; x < size; x++) { if (mod[y][x] === mod[y][x - 1]) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else run = 1; } }
      for (let x = 0; x < size; x++) { let run = 1; for (let y = 1; y < size; y++) { if (mod[y][x] === mod[y - 1][x]) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else run = 1; } }
      for (let y = 0; y < size - 1; y++) for (let x = 0; x < size - 1; x++) if (mod[y][x] === mod[y][x + 1] && mod[y][x] === mod[y + 1][x] && mod[y][x] === mod[y + 1][x + 1]) p += 3;
      return p; };
    let best = 0, bestP = Infinity;
    for (let m = 0; m < 8; m++) { applyMask(m); formatBits(m); const p = penalty(); if (p < bestP) { bestP = p; best = m; } applyMask(m); }
    applyMask(best); formatBits(best);
    return mod;
  }
  function draw(canvas, text, px = 6, quiet = 3) {
    const m = encode(text); if (!m) return false;
    const n = m.length, s = (n + quiet * 2) * px; canvas.width = canvas.height = s;
    const c = canvas.getContext("2d"); c.fillStyle = "#fff"; c.fillRect(0, 0, s, s); c.fillStyle = "#000";
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if (m[y][x]) c.fillRect((x + quiet) * px, (y + quiet) * px, px, px);
    return true;
  }
  return { encode, draw };
})();


const clampNum = (v, lo, hi) => Math.max(lo, Math.min(Math.max(lo, hi), v));

// Put every icon at a valid place for the current window size.
// "hx/hy" is the place the user chose. It comes back when the window gets bigger.
function reflowSites() {
  const { maxRows, maxCols } = getGridBounds();
  const taken = new Set(); const pending = []; let changed = false;
  const setPos = (site, x, y) => { if (site.x !== x || site.y !== y) { site.x = x; site.y = y; changed = true; } };

  SITES.filter(isDesk).forEach((site) => {
    if (site.hx == null && site.x != null) { site.hx = site.x; site.hy = site.y; }
    if (site.hx == null || site.hy == null) { pending.push(site); return; }
    if (S.snapGrid) {
      const g = pixelsToGrid(site.hx, site.hy);
      if (g.col < maxCols && g.row < maxRows && !taken.has(cellKey(g.col, g.row))) {
        taken.add(cellKey(g.col, g.row));
        const pt = gridToPixels(g.col, g.row); setPos(site, pt.x, pt.y);
      } else pending.push(site);
    } else {
      const x = clampNum(site.hx, PADDING_SIDE, baseW() - CELL_W - PADDING_SIDE);
      const y = clampNum(site.hy, PADDING_TOP, baseH() - CELL_H);
      const g = pixelsToGrid(x, y); taken.add(cellKey(g.col, g.row));
      setPos(site, x, y);
    }
  });

  pending.forEach((site) => {
    let spot = null;
    outer: for (let c = 0; c < maxCols; c++) for (let r = 0; r < maxRows; r++) {
      if (!taken.has(cellKey(c, r))) { spot = { c, r }; break outer; }
    }
    if (!spot) spot = { c: 0, r: 0 };
    taken.add(cellKey(spot.c, spot.r));
    const pt = gridToPixels(spot.c, spot.r); setPos(site, pt.x, pt.y);
    if (site.hx == null) { site.hx = pt.x; site.hy = pt.y; changed = true; }
  });
  return changed;
}

function autoArrangePositions() {
  const { maxRows } = getGridBounds();
  SITES.filter(isDesk).forEach((site, i) => {
    const pt = gridToPixels(Math.floor(i / maxRows), i % maxRows);
    site.x = pt.x; site.y = pt.y; site.hx = pt.x; site.hy = pt.y;
  });
  saveSites(); renderSites();
}

function resolveCollision(targetX, targetY, siteIndex) {
  const g = pixelsToGrid(targetX, targetY);
  const { maxRows, maxCols } = getGridBounds();
  const col = Math.min(maxCols - 1, g.col), row = Math.min(maxRows - 1, g.row);
  const aligned = gridToPixels(col, row);
  const occupierIndex = SITES.findIndex((s, i) => {
    if (i === siteIndex || s.parent || s.x == null || s.y == null) return false;
    const og = pixelsToGrid(s.x, s.y); return og.col === col && og.row === row;
  });
  if (occupierIndex !== -1) {
    const me = SITES[siteIndex], other = SITES[occupierIndex];
    if (me.x != null && me.y != null) { other.x = me.x; other.y = me.y; other.hx = me.x; other.hy = me.y; }
    else { other.hx = null; other.hy = null; other.x = null; other.y = null; }
  }
  return aligned;
}

// Keep a floating widget inside the visible desktop area.
function clampIntoDesktop(el) {
  if (!el || el.classList.contains("hidden")) return false;
  const nx = clampNum(el.offsetLeft, 10, window.innerWidth - el.offsetWidth * WS - 10);
  const ny = clampNum(el.offsetTop, 10, window.innerHeight - 50 - el.offsetHeight * WS - 10);
  if (nx === el.offsetLeft && ny === el.offsetTop) return false;
  el.style.left = nx + "px"; el.style.top = ny + "px";
  return true;
}
// Widgets keep a "home" place (S.*.x / S.*.y). Only a drag changes it.
// On resize we show the widget at its home place, pushed inside the window.
// So the widget goes back to its home place when the window gets bigger.
function placeWidget(el, x, y) {
  if (!el || el.classList.contains("hidden")) return;
  el.style.left = x + "px"; el.style.top = y + "px";
  clampIntoDesktop(el);
}
function widgetDrawer(name) { return { weather: wWeather, clock: wClock, calendar: wCalendar, progress: wProgress, timer: wTimer, stopwatch: wStopwatch, calc: wCalc, todo: wTodo, notes: wNotes, translate: wTranslate }[name]; }
const DESK_W = { weather: 300, clock: 280, calendar: 290, progress: 280, timer: 260, stopwatch: 260, calc: 260, todo: 300, notes: 280, translate: 330 };
let DESK_Z = 20;
const widgetTitle = (name) => t()["w" + name[0].toUpperCase() + name.slice(1)] || name;
const DESK_RESIZE = { translate: { minW: 300, minH: 300, maxW: 800, maxH: 760 } }; // widgets whose window can be resized
function applyDeskSize(el) {
  const name = el.dataset.name, lim = DESK_RESIZE[name], z = S.deskSize && S.deskSize[name]; if (!lim) return;
  if (!z) { el.style.width = (DESK_W[name] || 280) + "px"; el.style.height = ""; el.classList.remove("sized"); return; }
  el.style.width = clampNum(z.w, lim.minW, Math.min(lim.maxW, innerWidth / WS - 20)) + "px";
  el.style.height = clampNum(z.h, lim.minH, Math.min(lim.maxH, innerHeight / WS - 70)) + "px"; el.classList.add("sized");
}
function addDeskGrips(el, name) {
  const lim = DESK_RESIZE[name];
  ["r", "l", "b", "br", "bl"].forEach((k) => {
    const g = document.createElement("div"); g.className = "dw-grip dw-" + k; g.dataset.g = k; el.appendChild(g);
    g.addEventListener("dblclick", () => { if (S.deskSize) delete S.deskSize[name]; el.style.left = el.offsetLeft + "px"; applyDeskSize(el); saveSettings(); });
    g.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return; e.preventDefault(); e.stopPropagation();
      const sx = e.clientX, sy = e.clientY, w0 = el.offsetWidth, h0 = el.offsetHeight, l0 = el.offsetLeft; el.classList.add("is-dragging", "sized");
      const mv = (ev) => {
        const dx = (ev.clientX - sx) / WS, dy = (ev.clientY - sy) / WS; let w = w0, h = h0, l = l0;
        if (k.includes("r")) w = w0 + dx;
        if (k.includes("l")) { w = w0 - dx; }
        if (k.includes("b")) h = h0 + dy;
        w = clampNum(w, lim.minW, Math.min(lim.maxW, innerWidth / WS - 20)); h = clampNum(h, lim.minH, Math.min(lim.maxH, innerHeight / WS - 70));
        if (k.includes("l")) l = l0 + (w0 - w);
        if (k.includes("r") && l0 + w * WS > innerWidth - 10) w = (innerWidth - 10 - l0) / WS;
        el.style.width = w + "px"; el.style.height = h + "px"; el.style.left = Math.max(10, l) + "px";
      };
      const up = () => {
        el.classList.remove("is-dragging"); removeEventListener("pointermove", mv); removeEventListener("pointerup", up);
        S.deskSize = S.deskSize || {}; S.deskSize[name] = { w: Math.round(el.offsetWidth), h: Math.round(el.offsetHeight) };
        S.desk[name] = { x: el.offsetLeft, y: el.offsetTop }; saveSettings();
      };
      addEventListener("pointermove", mv); addEventListener("pointerup", up);
    });
  });
}
function buildDeskWidget(name, layer) {
  const el = document.createElement("div"); el.className = "floating-widget desk-widget"; el.dataset.name = name; el.style.width = (DESK_W[name] || 280) + "px"; el.style.zIndex = ++DESK_Z;
  const head = document.createElement("div"); head.className = "widget-window-header";
  const ttl = document.createElement("span"); ttl.className = "widget-win-title"; ttl.textContent = WIDGET_ICONS[name] + " " + widgetTitle(name);
  const ctl = document.createElement("div"); ctl.className = "widget-win-controls";
  const close = document.createElement("button"); close.type = "button"; close.className = "win-btn win-close"; close.title = t().removeFromDesktop; close.textContent = "✕";
  close.onclick = (e) => { e.stopPropagation(); toggleDeskWidget(name); };
  ctl.appendChild(close); head.append(ttl, ctl);
  const body = document.createElement("div"); body.className = "widget-window-body"; widgetDrawer(name)(body);
  el.append(head, body); layer.appendChild(el);
  if (DESK_RESIZE[name]) { applyDeskSize(el); addDeskGrips(el, name); }
  el.addEventListener("pointerdown", () => { el.style.zIndex = ++DESK_Z; }, true);
  head.addEventListener("pointerdown", (e) => { // move the widget
    if (e.button !== 0 || e.target.closest("button")) return; e.preventDefault();
    const sx = e.clientX, sy = e.clientY, ox = el.offsetLeft, oy = el.offsetTop; el.classList.add("is-dragging");
    const mv = (ev) => { el.style.left = clampNum(ox + ev.clientX - sx, 10, innerWidth - el.offsetWidth * WS - 10) + "px"; el.style.top = clampNum(oy + ev.clientY - sy, 10, innerHeight - 50 - el.offsetHeight * WS - 10) + "px"; };
    const up = () => { el.classList.remove("is-dragging"); removeEventListener("pointermove", mv); removeEventListener("pointerup", up); S.desk[name] = { x: el.offsetLeft, y: el.offsetTop }; saveSettings(); };
    addEventListener("pointermove", mv); addEventListener("pointerup", up);
  });
  return el;
}
function renderDeskWidgets(redraw) {
  const layer = $("deskWidgets"); if (!layer) return; S.desk = S.desk || {};
  [...layer.children].forEach((el) => { if (!S.desk[el.dataset.name]) el.remove(); });
  Object.keys(S.desk).forEach((name) => {
    if (!widgetDrawer(name)) { delete S.desk[name]; return; }
    let el = layer.querySelector(`[data-name="${name}"]`);
    if (el && redraw) { el.remove(); el = null; } // language changed: build it again
    if (!el) el = buildDeskWidget(name, layer);
    placeWidget(el, S.desk[name].x, S.desk[name].y);
  });
  document.querySelectorAll(".widget-pin").forEach((b) => { const on = !!S.desk[b.dataset.w]; b.classList.toggle("on", on); b.title = on ? t().removeFromDesktop : t().addToDesktop; });
}
function toggleDeskWidget(name) {
  S.desk = S.desk || {};
  if (S.desk[name]) delete S.desk[name];
  else { const n = Object.keys(S.desk).length; S.desk[name] = { x: 70 + (n % 6) * 34, y: 90 + (n % 6) * 34 }; }
  saveSettings(); renderDeskWidgets();
}
function toggleFloatingWidget(key) { toggleDeskWidget(key === "note" ? "notes" : key); }
function clampWidgets() {
  S.desk = S.desk || {};
  document.querySelectorAll("#deskWidgets .desk-widget").forEach((el) => { const p = S.desk[el.dataset.name]; if (p) placeWidget(el, p.x, p.y); });
  const hero = $("desktopHero");
  // Hero in default place is centered by CSS (transform). Only place it after the user moved it.
  if (hero && S.hero && S.hero.x != null && S.hero.y != null && hero.classList.contains("moved")) placeWidget(hero, S.hero.x, S.hero.y);
  return false; // nothing to save: home places did not change
}

let resizeTimer;
function handleWindowResize() {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    updateScale();
    if (reflowSites()) saveSites();
    renderSites();
    if (clampWidgets()) saveSettings();
  }, 60);
}

window.addEventListener("resize", handleWindowResize);

function icon(site) { return makeSiteIcon(site); }

function link(site, cls, index) {
  const a = document.createElement("a");
  a.className = cls; a.href = normUrl(site.url); a.dataset.index = index; a.target = "_blank"; a.rel = "noopener";
  a.appendChild(icon(site, cls === "shortcut" ? 44 : 32));
  a.appendChild(Object.assign(document.createElement("span"), { textContent: site.name }));
  return a;
}

// ---- drag an icon onto another icon ----
const isRealSite = (s) => s && !s.isFolder && !s.sys;
function dropTargetAt(e, el, dragIndex) {
  const me = SITES[dragIndex]; if (!isRealSite(me)) return null; // folders and the settings icon are only moved
  const under = document.elementsFromPoint(e.clientX, e.clientY).find((n) => n !== el && n.classList && n.classList.contains("desktop-icon") && n.dataset.index != null);
  if (!under) return null;
  const t = SITES[+under.dataset.index]; if (!t) return null;
  if (t.isFolder) return under; // a folder takes the icon wherever it is dropped on it
  if (!isRealSite(t) || S.dragFolder === false) return null;
  const r = under.getBoundingClientRect(); // for two sites the middle of the icon must be hit, so a normal move does not make a folder by mistake
  return Math.abs(e.clientX - (r.left + r.width / 2)) < r.width * 0.36 && Math.abs(e.clientY - (r.top + r.height / 2)) < r.height * 0.38 ? under : null;
}
function markDropTarget(target) {
  document.querySelectorAll(".desktop-icon.drop-target").forEach((n) => { if (n !== target) n.classList.remove("drop-target"); });
  if (target) target.classList.add("drop-target");
}
function mergeIntoFolder(a, b) {
  const A = SITES[a], B = SITES[b]; if (!isRealSite(A) || !isRealSite(B)) return;
  const f = { isFolder: true, id: newId(), name: t().newFolder, x: B.x, y: B.y, hx: B.hx != null ? B.hx : B.x, hy: B.hy != null ? B.hy : B.y }; // the folder takes the place of the icon below
  [A, B].forEach((s) => { s.parent = f.id; s.x = s.y = s.hx = s.hy = null; });
  SITES.push(f); saveSites(); renderSites(); openFolder(f.id, true);
}

function initIconDrag(el, siteIndex) {
  let isDragging = false, startX = 0, startY = 0, initialLeft = 0, initialTop = 0, hasMoved = false;
  const onPointerDown = (e) => {
    if (e.button !== 0) return;
    isDragging = true; hasMoved = false; startX = e.clientX; startY = e.clientY;
    initialLeft = el.offsetLeft; initialTop = el.offsetTop;
    el.style.right = "auto"; el.style.left = initialLeft + "px";
    el.classList.add("is-dragging");
    document.querySelectorAll(".desktop-icon").forEach(ic => ic.classList.remove("selected"));
    el.classList.add("selected");
    window.addEventListener("pointermove", onPointerMove); window.addEventListener("pointerup", onPointerUp);
    e.preventDefault();
  };
  const onPointerMove = (e) => {
    if (!isDragging) return;
    const dx = e.clientX - startX, dy = e.clientY - startY;
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) hasMoved = true;
    el.style.left = (initialLeft + dx) + "px"; el.style.top = (initialTop + dy) + "px";
    if (hasMoved) markDropTarget(dropTargetAt(e, el, siteIndex));
  };
  const onPointerUp = (e) => {
    if (!isDragging) return;
    isDragging = false; el.classList.remove("is-dragging");
    window.removeEventListener("pointermove", onPointerMove); window.removeEventListener("pointerup", onPointerUp);
    markDropTarget(null);
    if (!hasMoved) return; // a plain click: keep the element, so the click can open the link or the folder
    const hit = dropTargetAt(e, el, siteIndex);
    if (hit) { // dropped on a folder: go inside it. Dropped on another site: make a folder from both.
      const t = SITES[+hit.dataset.index];
      if (t.isFolder) moveToFolder(siteIndex, t.id); else mergeIntoFolder(siteIndex, +hit.dataset.index);
      return;
    }
    const rtl = S.lang === "fa";
    // Convert the dropped place to "distance from the start edge".
    let finalX = (rtl ? window.innerWidth - el.offsetLeft - el.offsetWidth : el.offsetLeft) / SCALE, finalY = el.offsetTop / SCALE;
    if (S.snapGrid) { const resolved = resolveCollision(finalX, finalY, siteIndex); finalX = resolved.x; finalY = resolved.y; }
    else { finalX = clampNum(finalX, PADDING_SIDE, baseW() - CELL_W - PADDING_SIDE); finalY = clampNum(finalY, PADDING_TOP, baseH() - CELL_H); }
    const site = SITES[siteIndex];
    site.x = finalX; site.y = finalY; site.hx = finalX; site.hy = finalY;
    saveSites(); renderSites();
  };
  el.addEventListener("pointerdown", onPointerDown);
  el.addEventListener("click", (e) => { if (hasMoved) e.preventDefault(); });
}

function renderSites() {
  const container = $("desktopIcons");
  if (!container) return;
  container.innerHTML = ""; container.style.display = S.short ? "" : "none";
  if (reflowSites()) saveSites();
  const side = S.lang === "fa" ? "right" : "left";
  SITES.forEach((site, i) => {
    if (site.parent) return; // sites inside a folder are not on the desktop
    const isBtn = site.isFolder || site.sys, a = document.createElement(isBtn ? "div" : "a");
    a.className = "desktop-icon" + (site.isFolder ? " folder-icon" : "") + (site.sys ? " sys-icon" : ""); a.dataset.index = i;
    if (isBtn) a.setAttribute("role", "button"); else { a.href = normUrl(site.url); a.target = "_blank"; a.rel = "noopener"; }
    a.style.left = "auto"; a.style.right = "auto";
    a.style[side] = (site.x * SCALE) + "px"; a.style.top = (site.y * SCALE) + "px";
    if (site.isFolder) a.appendChild(folderTile(site)); else if (site.sys) a.appendChild(sysTile()); else a.appendChild(icon(site, 44));
    const label = document.createElement("span"); label.className = "icon-label"; label.textContent = site.sys ? t().settings : site.name;
    a.appendChild(label); initIconDrag(a, i);
    if (site.isFolder) a.addEventListener("click", (e) => { if (e.defaultPrevented) return; e.stopPropagation(); openFolder(site.id); });
    else if (site.sys) a.addEventListener("click", (e) => { if (e.defaultPrevented) return; e.stopPropagation(); openSettings(); });
    container.appendChild(a);
  });
  if ($("folderPop") && !$("folderPop").classList.contains("hidden")) renderFolder();
  if (typeof renderStartMenu === "function") renderStartMenu();
  renderTaskbarPinned();
}

let pinSuppressClick = false;
function renderTaskbarPinned() {
  const pinContainer = $("taskbarPinned");
  if (!pinContainer) return;
  pinContainer.innerHTML = "";
  (S.taskbarPinned || []).forEach((siteIdx, pos) => {
    const site = SITES[siteIdx]; if (!site || site.isFolder || site.sys) return;
    const btn = document.createElement("button"); btn.className = "task-pin-btn"; btn.title = site.name; btn.dataset.pos = pos;
    btn.appendChild(icon(site, 24));
    btn.onclick = () => { if (pinSuppressClick) return; openSite(normUrl(site.url), site.name); };
    btn.oncontextmenu = (e) => {
      e.preventDefault(); e.stopPropagation();
      showCtx(e.clientX, e.clientY, [ { icon: "external", label: t().openNew, run: () => window.open(normUrl(site.url), "_blank") }, { icon: "pin", label: t().unpinTaskbar, run: () => togglePinToTaskbar(siteIdx) } ]);
    };
    pinContainer.appendChild(btn);
  });
  enableTaskbarReorder(pinContainer);
}

// Drag a pinned icon left or right to change its order. Other icons slide to show the new place.
function enableTaskbarReorder(container) {
  [...container.children].forEach((btn, from) => {
    btn.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      const items = [...container.children], slots = items.map((x) => x.getBoundingClientRect());
      const startX = e.clientX, cx0 = slots[from].left + slots[from].width / 2, rtl = getComputedStyle(container).direction === "rtl";
      let moving = false, to = from;
      const onMove = (ev) => {
        const dx = ev.clientX - startX;
        if (!moving && Math.abs(dx) < 6) return;
        if (!moving) { moving = true; btn.classList.add("dragging"); items.forEach((x) => { if (x !== btn) x.classList.add("sliding"); }); }
        btn.style.transform = `translateX(${dx}px)`;
        const cx = cx0 + dx;
        // new place = number of other icons that come before the dragged icon in reading order
        to = items.filter((x, k) => k !== from && (rtl ? slots[k].left + slots[k].width / 2 >= cx : slots[k].left + slots[k].width / 2 <= cx)).length;
        items.forEach((x, k) => {
          if (k === from) return; let shift = 0;
          if (from < to && k > from && k <= to) shift = slots[k - 1].left - slots[k].left;
          else if (from > to && k >= to && k < from) shift = slots[k + 1].left - slots[k].left;
          x.style.transform = shift ? `translateX(${shift}px)` : "";
        });
      };
      const onUp = () => {
        window.removeEventListener("pointermove", onMove); window.removeEventListener("pointerup", onUp);
        if (!moving) return;
        pinSuppressClick = true; setTimeout(() => { pinSuppressClick = false; }, 0);
        if (to !== from) {
          const arr = S.taskbarPinned, order = items.map((x) => +x.dataset.pos), moved = order.splice(from, 1)[0];
          order.splice(to, 0, moved);
          const used = new Set(order); // keep entries that are not shown (for example a removed site)
          S.taskbarPinned = [...order.map((p) => arr[p]), ...arr.filter((_, p) => !used.has(p))]; saveSettings();
        }
        renderTaskbarPinned();
      };
      window.addEventListener("pointermove", onMove); window.addEventListener("pointerup", onUp);
    });
  });
}

function togglePinToTaskbar(siteIdx) {
  if (!S.taskbarPinned) S.taskbarPinned = [];
  const pos = S.taskbarPinned.indexOf(siteIdx);
  if (pos > -1) S.taskbarPinned.splice(pos, 1); else S.taskbarPinned.push(siteIdx);
  saveSettings(); renderTaskbarPinned();
}


function renderTrayCalendarFlyout() {
  if ($("trayFlyoutCalBody")) wCalendar($("trayFlyoutCalBody"));
  if ($("trayWorldClocks")) wClock($("trayWorldClocks"));
}

if ($("trayClockBtn")) {
  $("trayClockBtn").addEventListener("click", (e) => {
    e.stopPropagation(); const flyout = $("trayCalendarPanel"); if (!flyout) return;
    const isOpen = !flyout.classList.contains("hidden"); closeAll("trayCalendarPanel");
    if (!isOpen) { flyout.classList.remove("hidden"); renderTrayCalendarFlyout(); } else flyout.classList.add("hidden");
  });
}

let weatherCache = null;
function renderWidgets() {
  const T = t(), toggles = $("widgetToggles");
  if (!S.collapsed) S.collapsed = {};
  if (toggles) {
    toggles.innerHTML = "";
    WIDGETS.forEach((w) => {
      const b = document.createElement("button"); b.className = "chip" + (S.widgets[w] ? " on" : "");
      b.textContent = WIDGET_ICONS[w] + " " + T["w" + w[0].toUpperCase() + w.slice(1)];
      b.onclick = () => { S.widgets[w] = !S.widgets[w]; saveSettings(); renderWidgets(); };
      toggles.appendChild(b);
    });
  }
  const list = $("widgetList");
  if (list) {
    list.innerHTML = "";
    const draw = { weather: wWeather, clock: wClock, calendar: wCalendar, progress: wProgress, timer: wTimer, stopwatch: wStopwatch, calc: wCalc, todo: wTodo, notes: wNotes, translate: wTranslate };
    WIDGETS.filter((w) => S.widgets[w]).forEach((w) => {
      const card = document.createElement("section"); card.className = "widget" + (S.collapsed[w] ? " collapsed" : "");
      card.innerHTML = `<header class="widget-head" role="button" tabindex="0"><span class="widget-ico"></span><h4></h4><button type="button" class="widget-pin" data-w="">📌</button><svg class="widget-chev" viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M3.5 6l4.5 4.5L12.5 6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></header><div class="body"></div>`;
      card.querySelector(".widget-ico").textContent = WIDGET_ICONS[w];
      card.querySelector("h4").textContent = T["w" + w[0].toUpperCase() + w.slice(1)];
      const pin = card.querySelector(".widget-pin"); pin.dataset.w = w; pin.onclick = (e) => { e.stopPropagation(); toggleDeskWidget(w); };
      pin.onkeydown = (e) => e.stopPropagation();
      const head = card.querySelector(".widget-head");
      head.setAttribute("aria-expanded", String(!S.collapsed[w]));
      const flip = () => { S.collapsed[w] = !S.collapsed[w]; card.classList.toggle("collapsed", !!S.collapsed[w]); head.setAttribute("aria-expanded", String(!S.collapsed[w])); saveSettings(); };
      head.onclick = flip;
      head.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); flip(); } };
      draw[w](card.querySelector(".body"));
      list.appendChild(card);
    });
  }
  renderDeskWidgets(); tick();
}

// ---- live ticker: one timer updates every visible live widget ----
const LIVE = new Set();
function addLive(el, fn) { fn.el = el; LIVE.add(fn); fn(); }
setInterval(() => { LIVE.forEach((fn) => { if (!fn.el.isConnected) LIVE.delete(fn); else { try { fn(); } catch (e) {} } }); }, 250);
const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
const num = (n, o) => Number(n).toLocaleString(locale(), o);

async function getWeatherData() {
  if (weatherCache && weatherCache.city === S.city && weatherCache.days && Date.now() - weatherCache.at < 15 * 60e3) return weatherCache;
  const g = await (await fetch(`https://geocoding-api.open-meteo.com/v1/search?count=1&name=${encodeURIComponent(S.city)}`)).json();
  const p = g.results && g.results[0]; if (!p) throw new Error("city");
  const w = await (await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${p.latitude}&longitude=${p.longitude}&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=4&timezone=auto`)).json();
  weatherCache = {
    city: S.city, name: p.name, temp: w.current.temperature_2m, feels: w.current.apparent_temperature, hum: w.current.relative_humidity_2m, wind: w.current.wind_speed_10m, code: w.current.weather_code, at: Date.now(),
    days: w.daily.time.map((date, i) => ({ date, code: w.daily.weather_code[i], max: w.daily.temperature_2m_max[i], min: w.daily.temperature_2m_min[i] }))
  };
  return weatherCache;
}
const WX = { 0: "☀️", 1: "🌤", 2: "⛅", 3: "☁️", 45: "🌫", 48: "🌫", 51: "🌦", 53: "🌦", 55: "🌧", 56: "🌧", 57: "🌧", 61: "🌧", 63: "🌧", 65: "🌧", 66: "🌧", 67: "🌧", 71: "🌨", 73: "🌨", 75: "❄️", 77: "🌨", 80: "🌦", 81: "🌧", 82: "⛈", 85: "🌨", 86: "❄️", 95: "⛈", 96: "⛈", 99: "⛈" };
function wWeather(body) {
  if (!body) return; body.textContent = t().loading;
  const draw = (d) => {
    const T = t(), loc = locale();
    body.innerHTML = "";
    const top = mk("div", "wx-top");
    top.append(mk("span", "wx-icon", WX[d.code] || "🌡"));
    const mid = mk("div", "wx-main"); mid.append(mk("b", "wx-temp", num(Math.round(d.temp)) + "°"), mk("span", "muted", d.name || d.city));
    top.append(mid);
    const hl = mk("div", "wx-hl", "↑ " + num(Math.round(d.days[0].max)) + "°  ↓ " + num(Math.round(d.days[0].min)) + "°"); top.append(hl);
    body.append(top);
    const stats = mk("div", "wx-stats");
    [[T.feels, num(Math.round(d.feels)) + "°"], [T.humidity, num(Math.round(d.hum)) + "%"], [T.wind, num(Math.round(d.wind)) + " km/h"]].forEach(([k, v]) => {
      const s = mk("div", "wx-stat"); s.append(mk("span", "muted", k), mk("b", "", v)); stats.append(s);
    });
    body.append(stats);
    const fc = mk("div", "wx-days");
    d.days.slice(1, 4).forEach((x) => {
      const c = mk("div", "wx-day");
      c.append(mk("span", "muted", new Date(x.date + "T12:00:00").toLocaleDateString(loc, { weekday: "short" })), mk("span", "wx-di", WX[x.code] || "🌡"), mk("b", "", num(Math.round(x.max)) + "° / " + num(Math.round(x.min)) + "°"));
      fc.append(c);
    });
    body.append(fc);
  };
  getWeatherData().then(draw).catch(() => { body.textContent = t().weatherErr; });
}

function wClock(body) {
  if (!body) return;
  const zones = [["Tehran", "Asia/Tehran"], ["London", "Europe/London"], ["New York", "America/New_York"], ["Tokyo", "Asia/Tokyo"]];
  body.innerHTML = zones.map(([n, z]) => `<div class="tz"><span>${n}</span><b data-tz="${z}" dir="ltr"></b></div>`).join("");
}

function wCalendar(body) {
  if (!body) return;
  const now = new Date(), loc = locale();
  const partNum = (d, type) => +new Intl.DateTimeFormat("en-US-u-ca-" + S.cal + "-nu-latn", { [type]: "numeric" }).formatToParts(d).find((p) => p.type === type).value;
  const today = partNum(now, "day"), first = new Date(now); first.setDate(now.getDate() - today + 1);
  const month = partNum(now, "month");
  let len = 28; while (len < 32) { const d = new Date(first); d.setDate(first.getDate() + len); if (partNum(d, "month") !== month) break; len++; }
  const weekStart = S.cal === "persian" ? 6 : 0, offset = (first.getDay() - weekStart + 7) % 7;
  const order = S.cal === "persian" ? [6, 0, 1, 2, 3, 4, 5] : [0, 1, 2, 3, 4, 5, 6];
  const names = S.lang === "fa" ? ["Sa", "Su", "Mo", "Tu", "We", "Th", "Fr"] : ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
  let html = `<div class="cal-title">${new Intl.DateTimeFormat(loc, { month: "long", year: "numeric" }).format(now)}</div><div class="cal">`;
  html += order.map((i) => `<span class="dn">${names[i]}</span>`).join("") + "<span></span>".repeat(offset);
  for (let d = 1; d <= len; d++) html += `<span class="${d === today ? "today" : ""}">${d}</span>`;
  body.innerHTML = html + "</div>";
}

function wTodo(body) {
  if (!body) return; body.innerHTML = "";
  const box = document.createElement("div"); box.className = "widget-todo-box";
  const input = Object.assign(document.createElement("input"), { className: "widget-todo-input", placeholder: t().todoPh });
  const ul = document.createElement("ul"); ul.className = "todo-list-glass";
  const draw = () => {
    ul.innerHTML = "";
    TODOS.forEach((item, i) => {
      const li = document.createElement("li");
      const cb = Object.assign(document.createElement("input"), { type: "checkbox", checked: item.done });
      cb.onchange = () => { item.done = cb.checked; store.set({ todos: TODOS }); draw(); };
      const span = Object.assign(document.createElement("span"), { textContent: item.text, className: item.done ? "done" : "" });
      const del = Object.assign(document.createElement("button"), { textContent: "✕", className: "todo-del-btn" });
      del.onclick = () => { TODOS.splice(i, 1); store.set({ todos: TODOS }); draw(); };
      li.append(cb, span, del); ul.appendChild(li);
    });
  };
  input.onkeydown = (e) => {
    if (e.key === "Enter" && input.value.trim()) { TODOS.push({ text: input.value.trim(), done: false }); input.value = ""; store.set({ todos: TODOS }); draw(); }
  };
  draw(); box.append(input, ul); body.appendChild(box);
}

function wNotes(body) {
  if (!body) return; body.innerHTML = "";
  const ta = Object.assign(document.createElement("textarea"), { className: "widget-notes-card", placeholder: t().notesPh, value: NOTES });
  let timer;
  ta.oninput = () => { NOTES = ta.value; clearTimeout(timer); timer = setTimeout(() => store.set({ notes: NOTES }), 300); };
  body.appendChild(ta);
}

// ---- Time progress: day, week, month, year (works for Persian and Gregorian calendar) ----
function wProgress(body) {
  if (!body) return;
  const T = t();
  const rows = [["pDay", T.pDay], ["pWeek", T.pWeek], ["pMonth", T.pMonth], ["pYear", T.pYear]].map(([k, label]) => {
    const row = mk("div", "pr-row"), top = mk("div", "pr-top"), val = mk("b", "", ""), bar = mk("div", "pr-bar"), fill = mk("i", "");
    top.append(mk("span", "", label), val); bar.append(fill); row.append(top, bar); body.append(row);
    return { k, val, fill };
  });
  const part = (d, type) => +new Intl.DateTimeFormat("en-US-u-ca-" + S.cal + "-nu-latn", { [type]: "numeric" }).formatToParts(d).find((p) => p.type === type).value;
  let cache = { day: -1 };
  const compute = (now) => {
    const midnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const dayNo = Math.floor(midnight / 864e5);
    if (cache.day === dayNo && cache.cal === S.cal) return cache;
    const dom = part(midnight, "day"), month = part(midnight, "month");
    let len = 28; while (len < 32) { const d = new Date(midnight); d.setDate(midnight.getDate() - dom + 1 + len); if (part(d, "month") !== month) break; len++; }
    let ys = new Date(midnight); for (let i = 0; i < 400; i++) { if (part(ys, "month") === 1 && part(ys, "day") === 1) break; ys.setDate(ys.getDate() - 1); }
    let ye = new Date(ys); ye.setDate(ye.getDate() + 300); for (let i = 0; i < 100; i++) { if (part(ye, "month") === 1 && part(ye, "day") === 1) break; ye.setDate(ye.getDate() + 1); }
    const weekStart = S.cal === "persian" ? 6 : 0, wd = (midnight.getDay() - weekStart + 7) % 7;
    cache = { day: dayNo, cal: S.cal, dom, len, wd, yDay: Math.round((midnight - ys) / 864e5), yLen: Math.round((ye - ys) / 864e5), midnight };
    return cache;
  };
  const update = () => {
    const now = new Date(), c = compute(now), dayFrac = (now - c.midnight) / 864e5;
    const v = { pDay: dayFrac, pWeek: (c.wd + dayFrac) / 7, pMonth: (c.dom - 1 + dayFrac) / c.len, pYear: (c.yDay + dayFrac) / c.yLen };
    rows.forEach((r) => { const p = Math.max(0, Math.min(1, v[r.k])); r.fill.style.width = (p * 100).toFixed(1) + "%"; r.val.textContent = num(Math.floor(p * 100)) + "%"; });
  };
  addLive(body, update);
}

// ---- Timer (countdown) ----
const TIMER = { dur: 25 * 60e3, left: 25 * 60e3, endAt: null, running: false };
function beep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    [0, 0.25, 0.5].forEach((t0) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.value = 880; g.gain.value = 0.15; o.connect(g); g.connect(ctx.destination); o.start(ctx.currentTime + t0); o.stop(ctx.currentTime + t0 + 0.15); });
    setTimeout(() => ctx.close(), 1500);
  } catch (e) {}
}
const mmss = (ms) => { const s = Math.max(0, Math.ceil(ms / 1000)); return String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0"); };
function wTimer(body) {
  if (!body) return; const T = t();
  const disp = mk("div", "tm-display", ""); disp.dir = "ltr";
  const bar = mk("div", "pr-bar"), fill = mk("i", ""); bar.append(fill);
  const presets = mk("div", "tm-presets");
  [5, 10, 25, 45].forEach((m) => { const b = mk("button", "mini ghost", num(m) + "'"); b.type = "button"; b.onclick = () => { TIMER.running = false; TIMER.dur = TIMER.left = m * 60e3; update(); }; presets.append(b); });
  const ctl = mk("div", "tm-ctl"), go = mk("button", "mini", ""), reset = mk("button", "mini ghost", T.bReset); go.type = reset.type = "button";
  go.onclick = () => {
    if (TIMER.running) { TIMER.left = TIMER.endAt - Date.now(); TIMER.running = false; }
    else { if (TIMER.left <= 0) TIMER.left = TIMER.dur; TIMER.endAt = Date.now() + TIMER.left; TIMER.running = true; }
    update();
  };
  reset.onclick = () => { TIMER.running = false; TIMER.left = TIMER.dur; update(); };
  ctl.append(go, reset); body.append(disp, bar, presets, ctl);
  function update() {
    if (TIMER.running) {
      TIMER.left = TIMER.endAt - Date.now();
      if (TIMER.left <= 0) { TIMER.left = 0; TIMER.running = false; beep(); disp.classList.add("flash"); setTimeout(() => disp.classList.remove("flash"), 3000); }
    }
    disp.textContent = TIMER.left <= 0 && !TIMER.running ? mmss(0) : mmss(TIMER.left);
    fill.style.width = (TIMER.dur ? (1 - TIMER.left / TIMER.dur) * 100 : 0) + "%";
    go.textContent = TIMER.running ? T.bPause : T.bStart;
  }
  addLive(body, update);
}

// ---- Stopwatch with laps ----
const SW = { base: 0, start: null, laps: [] };
function wStopwatch(body) {
  if (!body) return; const T = t();
  const swNow = () => SW.base + (SW.start ? Date.now() - SW.start : 0);
  const fmt = (ms) => { const cs = Math.floor(ms / 10) % 100, s = Math.floor(ms / 1000) % 60, m = Math.floor(ms / 60000); return String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0") + "." + String(cs).padStart(2, "0"); };
  const disp = mk("div", "tm-display", ""); disp.dir = "ltr";
  const ctl = mk("div", "tm-ctl"), go = mk("button", "mini", ""), lap = mk("button", "mini ghost", T.bLap), reset = mk("button", "mini ghost", T.bReset);
  go.type = lap.type = reset.type = "button";
  const laps = mk("ol", "sw-laps"); laps.dir = "ltr";
  const drawLaps = () => { laps.innerHTML = ""; SW.laps.slice().reverse().slice(0, 20).forEach((ms, i) => laps.append(mk("li", "", "#" + (SW.laps.length - i) + "  " + fmt(ms)))); };
  go.onclick = () => { if (SW.start) { SW.base = swNow(); SW.start = null; } else SW.start = Date.now(); update(); };
  lap.onclick = () => { if (swNow() > 0) { SW.laps.push(swNow()); drawLaps(); } };
  reset.onclick = () => { SW.base = 0; SW.start = null; SW.laps = []; drawLaps(); update(); };
  ctl.append(go, lap, reset); body.append(disp, ctl, laps); drawLaps();
  function update() { disp.textContent = fmt(swNow()); go.textContent = SW.start ? T.bPause : T.bStart; }
  addLive(body, update);
}

// ---- Calculator (no eval: simple state machine) ----
function wCalc(body) {
  if (!body) return;
  const disp = mk("div", "calc-display", "0"); disp.dir = "ltr";
  const grid = mk("div", "calc-grid");
  let cur = "0", acc = null, op = null, fresh = true;
  const apply = (a, b, o) => o === "+" ? a + b : o === "−" ? a - b : o === "×" ? a * b : o === "÷" ? (b === 0 ? NaN : a / b) : b;
  const show = () => { disp.textContent = cur.length > 14 ? String(+parseFloat(cur).toPrecision(10)) : cur; };
  const press = (k) => {
    if (/^\d$/.test(k)) { cur = fresh || cur === "0" ? k : cur + k; fresh = false; }
    else if (k === ".") { if (fresh) { cur = "0."; fresh = false; } else if (!cur.includes(".")) cur += "."; }
    else if (k === "C") { cur = "0"; acc = null; op = null; fresh = true; }
    else if (k === "⌫") { cur = cur.length > 1 && !fresh ? cur.slice(0, -1) : "0"; if (cur === "-") cur = "0"; }
    else if (k === "±") { if (cur !== "0") cur = cur.startsWith("-") ? cur.slice(1) : "-" + cur; }
    else if (k === "%") { cur = String(parseFloat(cur) / 100); fresh = true; }
    else if (["+", "−", "×", "÷"].includes(k)) {
      if (op && !fresh) acc = apply(acc, parseFloat(cur), op); else acc = parseFloat(cur);
      cur = isNaN(acc) ? "NaN" : String(+acc.toPrecision(12)); op = k; fresh = true;
    } else if (k === "=") {
      if (op) { const r = apply(acc, parseFloat(cur), op); cur = isNaN(r) ? "NaN" : String(+r.toPrecision(12)); acc = null; op = null; fresh = true; }
    }
    if (cur === "NaN") { cur = "0"; acc = null; op = null; fresh = true; disp.textContent = "—"; return; }
    show();
  };
  ["C", "⌫", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "±", "0", ".", "="].forEach((k) => {
    const b = mk("button", "calc-key" + (/[÷×−+]/.test(k) ? " op" : k === "=" ? " eq" : ""), k); b.type = "button"; b.onclick = () => press(k); grid.append(b);
  });
  body.append(disp, grid);
}

let wpShown = "";
const WP_DEFAULT = "wallpaper.jpg";
function applyWallpaper() {
  const w = $("wallpaper"); if (!w) return;
  const want = () => WALLPAPER || S.wpUrl || WP_DEFAULT, src = want();
  const show = (s) => { w.style.backgroundImage = `url("${s}")`; wpShown = s; w.classList.add("ready"); if (!S.wpLive) refreshAutoTheme(); };
  if (src !== wpShown) {
    if (src === WALLPAPER) show(src); // local file is already in memory
    else { // load first, then show with a fade. A broken link falls back to the default image.
      const img = new Image();
      img.onload = () => { if (want() === src) show(src); };
      img.onerror = () => { if (want() === src) show(WP_DEFAULT); };
      img.src = src;
    }
  }
  w.style.filter = S.blur ? `blur(${S.blur}px)` : "";
  w.style.transform = S.blur ? "scale(1.05)" : "";
  const v = $("wallpaperVideo"); if (v) { v.style.filter = w.style.filter; v.style.transform = w.style.transform; }
}

function pickWallpaper() { const el = $("wallpaperInput"); if (el) el.click(); }
if ($("wallpaperInput")) {
  $("wallpaperInput").addEventListener("change", (e) => {
    const file = e.target.files[0]; e.target.value = ""; if (!file) return;
    const img = new Image(), reader = new FileReader();
    reader.onload = () => {
      img.onload = async () => {
        const scale = Math.min(1, 2560 / Math.max(img.width, img.height)), c = document.createElement("canvas");
        c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        const data = c.toDataURL("image/jpeg", 0.88);
        try { await store.set({ wallpaper: data }); WALLPAPER = data; S.wpUrl = null; saveSettings(); clearLive(); applyWallpaper(); } catch(err) { showWinModal(t().wallpaper, t().tooBig); }
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}
async function resetWallpaper() { WALLPAPER = null; S.wpUrl = null; S.wpAuto = false; saveSettings(); clearLive(); await store.remove("wallpaper"); applyWallpaper(); }

let editingIndex = null;
function openSiteDialog(index = null, opts = {}) {
  closeAll(); editingIndex = index; siteLibOnly = !!opts.libOnly; siteLibOld = opts.libOld || null;
  const s = index == null ? (opts.prefill || { name: "", url: "" }) : SITES[index];
  $("siteTitle").textContent = siteLibOnly ? (siteLibOld ? t().editSite : t().scAddLib) : index == null ? t().addSite : t().editSite;
  $("siteName").value = s.name; $("siteUrl").value = s.url; $("siteIcon").value = s.icon || "";
  updatePreview(); refreshIconCandidates(); $("siteModal").classList.remove("hidden"); setTimeout(() => $("siteUrl").focus(), 30);
}

function updatePreview() {
  const url = $("siteUrl").value, name = $("siteName").value, ic = $("sitePreviewIcon"); if (!ic) return;
  ic.innerHTML = "";
  if (hostOf(url)) ic.appendChild(makeSiteIcon({ name: name || $("siteName").placeholder || hostOf(url), url, icon: $("siteIcon") ? $("siteIcon").value : "" }));
  $("sitePreviewName").textContent = name || hostOf(url) || "—";
}

let previewTimer;
if ($("siteUrl")) $("siteUrl").addEventListener("input", () => { clearTimeout(previewTimer); previewTimer = setTimeout(() => { if (!$("siteName").value && hostOf($("siteUrl").value)) { const h = hostOf($("siteUrl").value).replace(/^www\./, "").split(".")[0]; $("siteName").placeholder = h.charAt(0).toUpperCase() + h.slice(1); } updatePreview(); refreshIconCandidates(); }, 450); });
if ($("siteName")) $("siteName").addEventListener("input", updatePreview);
if ($("siteIcon")) $("siteIcon").addEventListener("input", updatePreview);
if ($("iconPickAuto")) $("iconPickAuto").addEventListener("click", () => { $("siteIcon").value = ""; document.querySelectorAll("#iconCands .icon-cand.on").forEach((x) => x.classList.remove("on")); updatePreview(); });
if ($("siteForm")) $("siteForm").addEventListener("submit", (e) => { e.preventDefault(); const url = normUrl($("siteUrl").value); if (!hostOf(url)) return; const name = $("siteName").value.trim() || $("siteName").placeholder || hostOf(url); const iconV = $("siteIcon").value.trim(), item = { ...(editingIndex == null ? {} : SITES[editingIndex]), name, url }; if (iconV) item.icon = iconV; else delete item.icon; const oldUrl = editingIndex == null ? null : SITES[editingIndex].url; if (siteLibOnly) { libSave(item, siteLibOld); toast(t().scLibSaved); $("siteModal").classList.add("hidden"); renderSitesCenter(true); return; } if (editingIndex == null) SITES.push(item); else SITES[editingIndex] = item; libSave(item, oldUrl); saveSites(); renderSites(); $("siteModal").classList.add("hidden"); });

function spliceSite(i) {
  SITES.splice(i, 1);
  S.taskbarPinned = (S.taskbarPinned || []).filter((x) => x !== i).map((x) => (x > i ? x - 1 : x)); saveSettings();
  saveSites(); renderSites();
}
function removeSite(i) {
  if (SITES[i] && SITES[i].sys) { S.settingsIcon = false; ensureSettingsIcon(); saveSettings(); render(); return; }
  if (SITES[i] && SITES[i].isFolder) return removeFolder(i);
  showWinModal(t().removeSite, t().confirmRemove, () => spliceSite(i));
}

const ctx = $("ctxMenu");
// Menu items: { icon, label, run } or { icon, label, sub: [...] }. Add checked:true/false to show a check mark.
let ctxTimer = null;
function ctxFill(box, items, isSub) {
  box.innerHTML = "";
  items.forEach((it) => {
    if (!it) return;
    if (it === "-") { box.appendChild(document.createElement("hr")); return; }
    const b = document.createElement("button"); b.type = "button";
    b.innerHTML = `<span class="ic">${uiIcon(it.icon, 16)}</span>`; b.appendChild(Object.assign(document.createElement("span"), { className: "lb", textContent: it.label }));
    if (it.checked != null) b.appendChild(Object.assign(document.createElement("span"), { className: "chk", textContent: it.checked ? "✓" : "" }));
    if (it.sub) {
      b.classList.add("has-sub"); b.appendChild(Object.assign(document.createElement("span"), { className: "chev", textContent: "›" }));
      const open = () => { clearTimeout(ctxTimer); ctxOpenSub(b, it.sub); };
      b.addEventListener("mouseenter", () => { clearTimeout(ctxTimer); ctxTimer = setTimeout(open, 120); });
      b.addEventListener("click", (e) => { e.stopPropagation(); open(); });
    } else {
      if (!isSub) b.addEventListener("mouseenter", () => { clearTimeout(ctxTimer); ctxTimer = setTimeout(ctxCloseSub, 160); });
      b.onclick = () => { ctx.classList.add("hidden"); ctxCloseSub(); it.run(); };
    }
    box.appendChild(b);
  });
}
function ctxCloseSub() { const s = $("ctxSub"); if (s) s.classList.add("hidden"); if (ctx) ctx.querySelectorAll("button.open").forEach((x) => x.classList.remove("open")); }
function ctxOpenSub(btn, items) {
  const s = $("ctxSub"); if (!s) return;
  ctx.querySelectorAll("button.open").forEach((x) => x.classList.remove("open")); btn.classList.add("open");
  ctxFill(s, items, true); s.classList.remove("hidden");
  const pr = ctx.getBoundingClientRect(), br = btn.getBoundingClientRect(), sr = s.getBoundingClientRect(), rtl = getComputedStyle(document.documentElement).direction === "rtl";
  let left = rtl ? pr.left - sr.width + 2 : pr.right - 2;                     // open on the reading side first
  if (left < 8) left = pr.right - 2; else if (left + sr.width > innerWidth - 8) left = pr.left - sr.width + 2;
  s.style.left = Math.max(8, Math.min(left, innerWidth - sr.width - 8)) + "px";
  s.style.top = Math.max(8, Math.min(br.top - 6, innerHeight - 58 - sr.height)) + "px"; // stay above the taskbar
}
function showCtx(x, y, items) {
  if (!ctx) return; clearTimeout(ctxTimer); ctxCloseSub(); ctxFill(ctx, items, false);
  ctx.classList.remove("hidden"); const r = ctx.getBoundingClientRect();
  ctx.style.left = Math.max(8, Math.min(x, innerWidth - r.width - 8)) + "px"; ctx.style.top = Math.max(8, Math.min(y, innerHeight - r.height - 8)) + "px";
}

// Desktop right-click menu: four groups, so the menu stays short.
function desktopMenu() {
  const T = t(), after = () => { saveSettings(); render(); };
  const size = (v, label) => ({ icon: { small: "sizeS", normal: "sizeM", large: "sizeL" }[v], label, checked: (S.iconSize || "normal") === v, run: () => { S.iconSize = v; after(); } });
  return [
    { icon: "plus", label: T.mNew, sub: [
      { icon: "plus", label: T.addSite, run: () => openSiteDialog() },
      { icon: "folder", label: T.newFolder, run: () => { const id = createFolder(); openFolder(id, true); } },
      { icon: "compass", label: T.scHub, run: () => openSitesCenter("hub") },
      { icon: "star", label: T.scMine, run: () => openSitesCenter("mine") },
      { icon: "note", label: T.openStickyNote, run: () => toggleFloatingWidget("note") } ] },
    { icon: "eye", label: T.mView, sub: [
      size("small", T.lblIconSize + ": " + T.sizeS), size("normal", T.lblIconSize + ": " + T.sizeM), size("large", T.lblIconSize + ": " + T.sizeL), "-",
      { icon: "tag", label: T.lblLabels, checked: S.labels !== false, run: () => { S.labels = S.labels === false; after(); } },
      { icon: "grid", label: T.snapGrid, checked: !!S.snapGrid, run: () => { S.snapGrid = !S.snapGrid; after(); } },
      { icon: "arrange", label: T.autoArrange, run: autoArrangePositions }, "-",
      { icon: "gear", label: T.lblSettingsIcon, checked: SITES.some((s) => s.sys), run: () => { S.settingsIcon = !SITES.some((s) => s.sys); ensureSettingsIcon(); after(); } } ] },
    { icon: "puzzle", label: T.mTools, sub: [
      ...WIDGETS.map((w) => ({ icon: WIDGET_UI[w], label: widgetTitle(w), checked: !!(S.desk && S.desk[w]), run: () => toggleDeskWidget(w) })), "-",
      { icon: "clock", label: T.heroWidgetToggle, checked: !!(S.hero && S.hero.show), run: () => { S.hero.show = !S.hero.show; saveSettings(); renderHeroState(); } },
      { icon: "windows", label: T.widgets, run: () => toggle("widgetsPanel") } ] },
    { icon: "palette", label: T.mPersonalize, sub: [
      { icon: "refresh", label: T.wpNext + " — " + wpSourceName(), run: nextWallpaper },
      { icon: "image", label: T.wpFromFile, run: pickWallpaper },
      { icon: "globe", label: T.wpOnline, run: () => openWpModal() },
      { icon: "film", label: T.wpLive, run: () => openWpModal("live") },
      { icon: "reset", label: T.resetWallpaper, run: resetWallpaper }, "-",
      { icon: "sparkles", label: T.lblAutoTheme, checked: S.autoTheme !== false, run: () => { S.autoTheme = S.autoTheme === false; saveSettings(); if (S.autoTheme) refreshAutoTheme(true); else applyThemeAndAccent(); render(); } } ] },
    "-",
    { icon: "refresh", label: T.refresh, run: () => location.reload() },
    { icon: "gear", label: T.settings, run: () => openSettings() }
  ];
}

// A right-click never opens the browser menu on our own panels. Text fields keep the native menu (cut, copy, paste).
function panelMenu(panel, x, y) {
  const T = t(), id = panel.id, shut = () => { if (id) panel.classList.add("hidden"); };
  if (panel.classList.contains("app-win")) {
    const w = APPWIN.list.find((v) => v.el === panel); if (!w) return null;
    return [ { icon: "refresh", label: T.winReload, run: () => { const f = w.el.querySelector(".aw-frame"); if (f) f.src = w.url; } }, { icon: "external", label: T.winOpenTab, run: () => window.open(w.url, "_blank") }, "-",
      { icon: "minimize", label: T.winMin, run: () => minimizeWin(w) }, { icon: "maximize", label: w.max ? T.winRestore : T.winMax, run: () => toggleMaxWin(w) }, { icon: "close", label: T.winClose, run: () => closeWin(w) } ];
  }
  if (panel.classList.contains("floating-widget")) return [ { icon: "close", label: T.winClose, run: () => { const c = panel.querySelector(".win-close"); if (c) c.click(); } } ];
  if (panel.classList.contains("taskbar")) return [ { icon: "gear", label: T.secStart, run: () => openSettings("start") }, { icon: "reset", label: T.btnResetPinned, run: () => { S.taskbarPinned = [...DEFAULTS.taskbarPinned]; saveSettings(); renderTaskbarPinned(); toast(T.pinReset); } } ];
  if (id === "startMenu") return [ { icon: "gear", label: T.settings, run: () => openSettings() }, { icon: "close", label: T.winClose, run: shut } ];
  if (id === "settingsPanel") return [ { icon: "search", label: T.setSearchPh.replace("...", ""), run: () => { const s = $("setSearch"); if (s) s.focus(); } }, { icon: "close", label: T.winClose, run: shut } ];
  if (id === "widgetsPanel") return [ { icon: "gear", label: T.settings, run: () => openSettings() }, { icon: "close", label: T.winClose, run: shut } ];
  if (id === "folderPop") return [ { icon: "edit", label: T.renameFolder, run: () => { const n = $("folderName"); if (n) { n.focus(); n.select(); } } }, { icon: "close", label: T.winClose, run: shut } ];
  if (id === "accountPanel") return [ { icon: "close", label: T.winClose, run: shut } ];
  if (id === "trayCalendarPanel") return [ { icon: "close", label: T.winClose, run: shut } ];
  return null;
}
document.addEventListener("contextmenu", (e) => {
  const tg = e.target;
  if (tg.closest("input, textarea, select, [contenteditable='true']")) { if (ctx) ctx.classList.add("hidden"); ctxCloseSub(); return; } // native menu for text fields
  if (tg.closest(".ctx")) { e.preventDefault(); return; }
  const onItem = tg.closest(".start-item, .start-row, .folder-item, .hero-q");
  const panel = tg.closest(".start-menu, .settings-panel, .account-panel, .widgets, .tray-flyout, .dialog, .modal, .folder-pop, .app-win, .floating-widget, .taskbar");
  if (panel && !onItem) {
    e.preventDefault();
    if (panel.matches(".dialog, .modal")) return; // dialogs: no menu at all
    const items = panelMenu(panel, e.clientX, e.clientY);
    closeAll(panel.id && PANELS.includes(panel.id) ? panel.id : undefined);
    if (items) showCtx(e.clientX, e.clientY, items);
    return;
  }
  const inStart = tg.closest(".start-menu"), inFolder = tg.closest(".folder-pop");
  e.preventDefault(); closeAll(inStart ? "startMenu" : inFolder ? "folderPop" : undefined);
  const el = e.target.closest(".desktop-icon[data-index], .start-item[data-index], .start-row[data-index], .folder-item[data-index], .hero-q[data-index]"), T = t();
  if (el) {
    const i = +el.dataset.index; if (!SITES[i]) return;
    showCtx(e.clientX, e.clientY, SITES[i].sys ? sysMenu() : SITES[i].isFolder ? folderMenu(i) : siteMenu(i, e.clientX, e.clientY));
  } else {
    showCtx(e.clientX, e.clientY, desktopMenu());
  }
});

// ================= SITE MENU, FOLDERS, QR =================
function toast(msg) {
  let el = $("toast"); if (!el) { el = document.createElement("div"); el.id = "toast"; el.className = "toast"; document.body.appendChild(el); }
  el.textContent = msg; el.classList.add("show"); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove("show"), 1800);
}
async function copyText(s) {
  try { await navigator.clipboard.writeText(s); }
  catch (e) { const ta = document.createElement("textarea"); ta.value = s; document.body.appendChild(ta); ta.select(); try { document.execCommand("copy"); } catch (x) {} ta.remove(); }
}
function openWindow(href) {
  try { if (typeof chrome !== "undefined" && chrome.windows && chrome.windows.create) { chrome.windows.create({ url: href }); return; } } catch (e) {}
  window.open(href, "_blank", "noopener,width=1200,height=800");
}
const newId = () => "f" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
function createFolder(name) {
  const f = { isFolder: true, id: newId(), name: name || t().newFolder }; SITES.push(f); saveSites(); renderSites(); return f.id;
}
function moveToFolder(i, fid) {
  const s = SITES[i]; if (!s) return;
  s.parent = fid; s.x = s.y = s.hx = s.hy = null; saveSites(); renderSites(); toast(t().movedToFolder);
}
function moveOut(i) {
  const s = SITES[i]; if (!s) return;
  delete s.parent; s.x = s.y = s.hx = s.hy = null; saveSites(); renderSites();
}
function duplicateSite(i) { const s = SITES[i]; SITES.push({ name: s.name, url: s.url, ...(s.icon ? { icon: s.icon } : {}), ...(s.parent ? { parent: s.parent } : {}) }); saveSites(); renderSites(); }
function removeFolder(i) {
  showWinModal(t().removeFolder, t().confirmRemoveFolder, () => {
    const id = SITES[i].id;
    SITES.forEach((s) => { if (s.parent === id) { delete s.parent; s.x = s.y = s.hx = s.hy = null; } });
    spliceSite(i); const p = $("folderPop"); if (p) p.classList.add("hidden");
  });
}
function siteMenu(i, x, y) {
  const s = SITES[i], T = t(), href = normUrl(s.url), pinned = (S.taskbarPinned || []).includes(i);
  const folders = () => SITES.map((f, idx) => [f, idx]).filter(([f]) => f.isFolder && f.id !== s.parent);
  return [
    { icon: "external", label: T.openNew, run: () => window.open(href, "_blank") },
    { icon: "tab", label: T.openThis, run: () => { window.location.href = href; } },
    { icon: "appwin", label: T.openInApp, run: () => openAppWindow(href, s.name) },
    { icon: "newwin", label: T.openWindow, run: () => openWindow(href) },
    "-",
    { icon: "link", label: T.copyLink, run: async () => { await copyText(href); toast(T.linkCopied); } },
    { icon: "qr", label: T.qrCode, run: () => showQr(href, s.name) },
    "-",
    { icon: "moveFolder", label: T.moveToFolder, run: () => showCtx(x, y, [ ...folders().map(([f]) => ({ icon: "folder", label: f.name, run: () => moveToFolder(i, f.id) })), ...(folders().length ? ["-"] : []), { icon: "plus", label: T.newFolder, run: () => moveToFolder(i, createFolder()) } ]) },
    ...(s.parent ? [{ icon: "moveOut", label: T.moveOut, run: () => moveOut(i) }] : []),
    { icon: "pin", label: pinned ? T.unpinTaskbar : T.pinTaskbar, run: () => togglePinToTaskbar(i) },
    { icon: "copy", label: T.duplicate, run: () => duplicateSite(i) },
    "-",
    { icon: "edit", label: T.editSite, run: () => openSiteDialog(i) },
    { icon: "trash", label: T.removeSite, run: () => removeSite(i) }
  ];
}
function folderMenu(i) {
  const T = t(), f = SITES[i];
  return [ { icon: "folder", label: T.openFolder, run: () => openFolder(f.id) }, { icon: "edit", label: T.renameFolder, run: () => openFolder(f.id, true) }, "-", { icon: "trash", label: T.removeFolder, run: () => removeFolder(i) } ];
}
function folderTile(f) {
  const d = document.createElement("div"); d.className = "tile folder-tile";
  SITES.filter((s) => s.parent === f.id).slice(0, 4).forEach((s) => d.appendChild(makeSiteIcon(s, "ft")));
  return d;
}
let openFolderId = null;
function openFolder(id, rename) {
  openFolderId = id; closeAll("folderPop"); const p = $("folderPop"); if (!p) return;
  p.classList.remove("hidden"); renderFolder();
  if (rename) setTimeout(() => { const n = $("folderName"); n.focus(); n.select(); }, 30);
}
function renderFolder() {
  const p = $("folderPop"), f = SITES.find((s) => s.isFolder && s.id === openFolderId);
  if (!p) return; if (!f) { p.classList.add("hidden"); return; }
  const n = $("folderName"); if (document.activeElement !== n) n.value = f.name; n.placeholder = t().folderName;
  const g = $("folderGrid"); g.innerHTML = "";
  SITES.forEach((s, i) => { if (s.parent === f.id) g.appendChild(link(s, "folder-item", i)); });
  if (!g.children.length) g.appendChild(Object.assign(document.createElement("div"), { className: "start-empty", textContent: t().folderEmpty }));
}
if ($("folderName")) {
  const n = $("folderName");
  n.addEventListener("change", () => { const f = SITES.find((s) => s.isFolder && s.id === openFolderId); if (!f) return; f.name = n.value.trim() || t().newFolder; n.value = f.name; saveSites(); renderSites(); });
  n.addEventListener("keydown", (e) => { if (e.key === "Enter") n.blur(); e.stopPropagation(); });
}
function showQr(url, name) {
  const m = $("qrModal"), cv = $("qrCanvas"); if (!m) return;
  if (!QR.draw(cv, url, 8, 3)) { toast(t().qrTooLong); return; }
  $("qrName").textContent = name || hostOf(url); $("qrLink").textContent = url; m.dataset.url = url; m.classList.remove("hidden");
}
if ($("qrCopy")) $("qrCopy").addEventListener("click", async () => { await copyText($("qrModal").dataset.url); toast(t().linkCopied); });
if ($("qrDownload")) $("qrDownload").addEventListener("click", () => { const a = document.createElement("a"); a.download = "qr.png"; a.href = $("qrCanvas").toDataURL("image/png"); a.click(); });
if ($("qrModal")) $("qrModal").addEventListener("click", (e) => { if (e.target.id === "qrModal") $("qrModal").classList.add("hidden"); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape") document.querySelectorAll(".modal").forEach((m) => m.classList.add("hidden")); });

if ($("desktop")) $("desktop").addEventListener("pointerdown", (e) => { if (!e.target.closest(".desktop-icon")) document.querySelectorAll(".desktop-icon").forEach(ic => ic.classList.remove("selected")); });

const PANELS = ["startMenu", "settingsPanel", "widgetsPanel", "trayCalendarPanel", "folderPop", "accountPanel", "ctxMenu", "ctxSub"];
const KEEP_OPEN = ["settingsPanel", "accountPanel"]; // floating windows: only their own close button (or Esc inside them) closes them
function closeAll(except) { PANELS.forEach((p) => p !== except && !KEEP_OPEN.includes(p) && $(p) && $(p).classList.add("hidden")); }
function bringPanel(id) { KEEP_OPEN.forEach((p) => { if ($(p)) $(p).style.zIndex = p === id ? 77 : 75; }); }
function toggle(id) { const el = $(id); if (!el) return; const open = el.classList.contains("hidden"); closeAll(id); el.classList.toggle("hidden", !open); if (id === "widgetsPanel" && open) renderWidgets(); if (id === "startMenu" && open && typeof openStartMenu === "function") openStartMenu(); }

if ($("startBtn")) $("startBtn").addEventListener("click", (e) => { e.stopPropagation(); toggle("startMenu"); });
if ($("widgetsBtn")) $("widgetsBtn").addEventListener("click", (e) => { e.stopPropagation(); toggle("widgetsPanel"); });
if ($("openSettings")) $("openSettings").addEventListener("click", (e) => { e.stopPropagation(); toggle("settingsPanel"); });
if ($("taskSearchBtn")) $("taskSearchBtn").addEventListener("click", () => { if (S.hero.show && $("searchInput")) $("searchInput").focus(); else { toggle("startMenu"); if ($("startSearch")) $("startSearch").focus(); } });
if ($("toggleHeroWidget")) $("toggleHeroWidget").addEventListener("click", () => { S.hero.show = !S.hero.show; saveSettings(); renderHeroState(); });
if ($("openFloatNoteQuick")) $("openFloatNoteQuick").addEventListener("click", () => toggleFloatingWidget("note"));
if ($("openFloatWeatherQuick")) $("openFloatWeatherQuick").addEventListener("click", () => toggleFloatingWidget("weather"));

document.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", () => { const el = $(b.dataset.close); if (el) el.classList.add("hidden"); }));
document.querySelectorAll("[data-action]").forEach((b) => b.addEventListener("click", () => { if (b.dataset.action === "pickWallpaper") pickWallpaper(); if (b.dataset.action === "resetWallpaper") resetWallpaper(); }));
document.addEventListener("click", (e) => { PANELS.forEach((p) => { const el = $(p); if (el && !KEEP_OPEN.includes(p) && !el.contains(e.target)) el.classList.add("hidden"); }); });
KEEP_OPEN.forEach((p) => { const el = $(p); if (el) el.addEventListener("pointerdown", () => bringPanel(p), true); });
if ($("siteModal")) $("siteModal").addEventListener("click", (e) => { if (e.target.id === "siteModal") $("siteModal").classList.add("hidden"); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape") { const ae = document.activeElement, win = ae && ae.closest ? KEEP_OPEN.map($).find((p) => p && !p.classList.contains("hidden") && p.contains(ae)) : null; if (win && !/^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)) win.classList.add("hidden"); closeAll(); if ($("siteModal")) $("siteModal").classList.add("hidden"); if ($("winDialogModal")) $("winDialogModal").classList.add("hidden"); } });
PANELS.concat(["siteModal", "winDialogModal"]).forEach((p) => { const node = $(p); if (node) node.addEventListener("click", (e) => { if (p !== "siteModal" && p !== "winDialogModal") e.stopPropagation(); }); });

function render() {
  updateScale();
  const T = t();
  if (typeof sitesCenterEntries === "function" && S.hub) sitesCenterEntries();
  document.documentElement.lang = S.lang; document.documentElement.dir = S.lang === "fa" ? "rtl" : "ltr"; document.title = T.title;
  if ($("searchInput")) $("searchInput").placeholder = T.search;
  if ($("startSearch")) $("startSearch").placeholder = T.startSearch;
  if ($("wpUrl")) $("wpUrl").placeholder = T.wpUrlPh;
  if ($("startBtn")) $("startBtn").title = T.start;
  if ($("taskSearchBtn")) $("taskSearchBtn").title = T.searchBtn;
  if ($("widgetsBtn")) $("widgetsBtn").title = T.widgets;
  document.querySelectorAll("[data-i18n]").forEach((el) => { if (T[el.dataset.i18n]) el.textContent = T[el.dataset.i18n]; });
  document.querySelectorAll("[data-ph]").forEach((el) => { if (T[el.dataset.ph]) el.placeholder = T[el.dataset.ph]; });
  document.querySelectorAll(".close-btn").forEach((b) => { b.title = T.winClose; b.setAttribute("aria-label", T.winClose); });
  if ($("setAutoTheme")) $("setAutoTheme").checked = S.autoTheme !== false;
  if ($("setGlass")) $("setGlass").value = S.glass == null ? 55 : S.glass;
  if ($("setTheme")) $("setTheme").disabled = S.autoTheme !== false;
  document.body.classList.toggle("auto-theme", S.autoTheme !== false);
  if ($("setDragFolder")) $("setDragFolder").checked = S.dragFolder !== false;
  if ($("setTraySec")) $("setTraySec").checked = !!S.traySeconds;
  if ($("setHeroStyle")) $("setHeroStyle").value = S.heroStyle || "card";
  if ($("setHeroInfo")) $("setHeroInfo").checked = S.heroInfo !== false;
  if ($("setHeroQuick")) $("setHeroQuick").checked = S.heroQuick !== false;
  if ($("setIconSize")) $("setIconSize").value = S.iconSize || "normal";
  if ($("setLabels")) $("setLabels").checked = S.labels !== false;
  if ($("setSettingsIcon")) $("setSettingsIcon").checked = !!S.settingsIcon;
  if ($("setStartRecent")) $("setStartRecent").checked = S.startRecent !== false;
  if ($("setOpenMode")) $("setOpenMode").value = S.openMode || "tab";
  document.body.classList.toggle("no-labels", S.labels === false);
  if ($("aboutVer")) { let v = "—"; try { v = chrome.runtime.getManifest().version; } catch (e) {} $("aboutVer").textContent = "v" + v; }
  document.querySelectorAll("#setContent .set-sec").forEach((s) => { s.dataset.label = T[s.dataset.title] || ""; });
  renderSettingsNav();
  
  if ($("setLang")) $("setLang").value = S.lang;
  if ($("setEngine")) $("setEngine").value = S.engine;
  if ($("setCal")) $("setCal").value = S.cal;
  if ($("setH24")) $("setH24").checked = S.h24;
  if ($("setSec")) $("setSec").checked = S.sec;
  if ($("setShort")) $("setShort").checked = S.short;
  if ($("setBlur")) $("setBlur").value = S.blur;
  if ($("setCity")) $("setCity").value = S.city;
  if ($("setSnapGrid")) $("setSnapGrid").checked = S.snapGrid;
  if ($("setTheme")) $("setTheme").value = S.theme || "dark";
  if ($("setShowHero")) $("setShowHero").checked = S.hero.show;
  if ($("setFont")) $("setFont").value = S.font || "puffy";
  if ($("setCustomFont")) $("setCustomFont").value = S.customFont || "";
  if ($("customFontGroup")) $("customFontGroup").classList.toggle("hidden", S.font !== "custom");

  applyThemeAndAccent(); initCenterHero(); renderHeroState(); renderSites(); applyWallpaper(); renderDeskWidgets(S.lang !== renderDeskWidgets.lang); renderDeskWidgets.lang = S.lang; renderHero(); renderStartUser();
  if ($("widgetsPanel") && !$("widgetsPanel").classList.contains("hidden")) renderWidgets();
  tick();
}

function bind(id, key, prop = "value", cast = (v) => v, ev = "input") {
  const el = $(id); if (!el) return; el.addEventListener(ev, (e) => { S[key] = cast(e.target[prop]); saveSettings(); render(); });
}
bind("setLang", "lang"); bind("setEngine", "engine"); bind("setCal", "cal"); bind("setH24", "h24", "checked"); bind("setSec", "sec", "checked"); bind("setShort", "short", "checked"); bind("setBlur", "blur", "value", Number); bind("setCity", "city", "value", (v) => v.trim() || "Tehran", "change"); bind("setSnapGrid", "snapGrid", "checked"); bind("setTheme", "theme");
if ($("setFont")) $("setFont").addEventListener("change", (e) => { S.font = e.target.value; saveSettings(); applyThemeAndAccent(); render(); });
if ($("setCustomFont")) $("setCustomFont").addEventListener("input", (e) => { S.customFont = e.target.value; saveSettings(); applyThemeAndAccent(); });
if ($("setShowHero")) $("setShowHero").addEventListener("change", (e) => { S.hero.show = e.target.checked; saveSettings(); renderHeroState(); });
if ($("autoArrangeBtn")) $("autoArrangeBtn").addEventListener("click", autoArrangePositions);
if ($("resetSettings")) $("resetSettings").addEventListener("click", () => showWinModal(t().reset, t().confirmResetAll, () => { S = structuredClone(DEFAULTS); ensureSettingsIcon(); saveSettings(); render(); }));

function addSearch(q) { S.searches = [q, ...(S.searches || []).filter((x) => x !== q)].slice(0, 8); saveSettings(); }
function go(q) { const isUrl = /^https?:\/\//.test(q) || (/^[\w-]+(\.[\w-]+)+/.test(q) && !q.includes(" ")); if (!isUrl) addSearch(q); location.href = isUrl ? normUrl(q) : ENGINES[S.engine] + encodeURIComponent(q); }
if ($("searchForm")) $("searchForm").addEventListener("submit", (e) => { e.preventDefault(); const q = $("searchInput").value.trim(); if (q) go(q); });

// ---- hero: greeting, info chips, engine switch, suggestions, shortcuts ----
const ENGINE_NAMES = { google: "Google", bing: "Bing", duck: "DuckDuckGo" };
let heroWx = null, sugSel = -1;
function tickHero(now, loc) {
  const hero = $("desktopHero"); if (!hero || hero.dataset.style !== "card") return;
  const T = t(), h = now.getHours();
  if ($("heroGreet")) $("heroGreet").textContent = h < 5 ? T.greetNight : h < 12 ? T.greetMorning : h < 17 ? T.greetNoon : h < 20 ? T.greetEvening : T.greetNight;
  try { // locale() already holds calendar extensions, so only the language part is used here
    if ($("heroAltDate")) $("heroAltDate").textContent = "📅 " + new Intl.DateTimeFormat(loc.split("-u-")[0] + "-u-ca-" + (S.cal === "persian" ? "gregory" : "persian"), { day: "numeric", month: "long", year: "numeric" }).format(now);
  } catch (e) {}
  if ($("heroDayPct")) { const m = new Date(now.getFullYear(), now.getMonth(), now.getDate()); $("heroDayPct").textContent = "◔ " + num(Math.floor(((now - m) / 864e5) * 100)) + "%"; }
}
function renderHero() {
  const hero = $("desktopHero"); if (!hero) return; const T = t();
  const card = S.heroStyle !== "minimal"; hero.dataset.style = card ? "card" : "minimal";
  $("heroGreet").classList.toggle("hidden", !card);
  $("heroChips").classList.toggle("hidden", !card || S.heroInfo === false);
  $("heroQuick").classList.toggle("hidden", !card || S.heroQuick === false);
  const eb = $("engineBtn"); eb.classList.toggle("hidden", !card); eb.innerHTML = "";
  eb.append(mk("span", "eng-badge", (ENGINE_NAMES[S.engine] || "G")[0]), mk("span", "eng-name", ENGINE_NAMES[S.engine] || S.engine), mk("span", "eng-chev", "▾"));
  eb.title = T.engine;
  eb.onclick = (e) => { e.stopPropagation(); const r = eb.getBoundingClientRect(); showCtx(r.left, r.bottom + 6, Object.keys(ENGINES).map((k) => ({ icon: "search", label: ENGINE_NAMES[k] || k, checked: S.engine === k, run: () => { S.engine = k; saveSettings(); render(); } }))); };
  // shortcuts: pinned sites first
  const q = $("heroQuick"); q.innerHTML = "";
  const real = (i) => SITES[i] && !SITES[i].isFolder && !SITES[i].sys, order = [...(S.taskbarPinned || []).filter(real), ...SITES.map((_, i) => i).filter(real)];
  [...new Set(order)].slice(0, 6).forEach((i) => q.appendChild(link(SITES[i], "hero-q", i)));
  // weather chip
  const wx = $("heroWx"); wx.classList.add("hidden");
  if (card && S.heroInfo !== false) {
    getWeatherData().then((d) => { heroWx = d; wx.textContent = (WX[d.code] || "🌡") + " " + num(Math.round(d.temp)) + "°  " + (d.name || d.city); wx.classList.remove("hidden"); }).catch(() => {});
    wx.onclick = (e) => { e.stopPropagation(); toggleDeskWidget("weather"); };
  }
  $("searchInput").placeholder = T.search; tickHero(new Date(), locale());
}
function renderSuggest() {
  const box = $("searchSuggest"), inp = $("searchInput"); if (!box || !inp) return;
  const T = t(), q = inp.value.trim(), ql = q.toLowerCase(), items = []; sugSel = -1; box.innerHTML = "";
  const val = q ? calcExpr(q) : null;
  if (val != null) items.push({ icon: "calc", text: q + " = " + val.toLocaleString("en-US", { maximumFractionDigits: 10 }), run: () => { inp.value = String(val); inp.focus(); renderSuggest(); } });
  (S.searches || []).filter((s) => !q || (s.toLowerCase().includes(ql) && s.toLowerCase() !== ql)).slice(0, 6).forEach((s) => items.push({ icon: "history", text: s, hist: true, run: () => go(s) }));
  if (!items.length || document.activeElement !== inp) { box.classList.add("hidden"); return; }
  if (!q && items.some((x) => x.hist)) box.appendChild(Object.assign(document.createElement("div"), { className: "sg-head", textContent: T.recentSearches }));
  items.forEach((it) => {
    const b = document.createElement("button"); b.type = "button"; b.className = "sg-row";
    const sgi = mk("span", "sg-ico", ""); sgi.innerHTML = svgI(it.icon, 16); b.append(sgi, mk("span", "sg-text", it.text));
    b.onmousedown = (e) => e.preventDefault(); b.onclick = it.run; box.appendChild(b);
  });
  if (!q && items.some((x) => x.hist)) { const c = mk("button", "sg-clear", T.clearHistory); c.type = "button"; c.onmousedown = (e) => e.preventDefault(); c.onclick = () => { S.searches = []; saveSettings(); renderSuggest(); }; box.appendChild(c); }
  box.classList.remove("hidden");
}
if ($("searchInput")) {
  const inp = $("searchInput");
  inp.addEventListener("input", renderSuggest); inp.addEventListener("focus", renderSuggest);
  inp.addEventListener("blur", () => setTimeout(() => $("searchSuggest").classList.add("hidden"), 160));
  inp.addEventListener("keydown", (e) => {
    const rows = [...document.querySelectorAll("#searchSuggest .sg-row")];
    if (e.key === "Escape") { $("searchSuggest").classList.add("hidden"); return; }
    if (!rows.length) return;
    if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); sugSel = (sugSel + (e.key === "ArrowDown" ? 1 : -1) + rows.length) % rows.length; rows.forEach((r, k) => r.classList.toggle("sel", k === sugSel)); }
    else if (e.key === "Enter" && sugSel >= 0) { e.preventDefault(); rows[sugSel].click(); }
  });
}
// ================= ONLINE WALLPAPER =================
const todayKey = () => new Date().toISOString().slice(0, 10);
const picsumFull = (seed) => `https://picsum.photos/seed/${seed}/1920/1080`;
const picsumThumb = (seed) => `https://picsum.photos/seed/${seed}/360/200`;
const WH_DEFAULT = { q: "", sort: "toplist", res: "1920x1080" };
const whOpts = () => (S.wh = { ...WH_DEFAULT, ...(S.wh || {}) });
const WP_SOURCES = [["wallhaven", "Wallhaven"], ["picsum", "wpPicsum"], ["custom", "wpCustomApi"], ["live", "wpLive"]];
let wpItems = [], wpPage = 1;

function randomPicsum() {
  return Array.from({ length: 8 }, () => { const s = Math.random().toString(36).slice(2, 9); return { thumb: picsumThumb(s), full: picsumFull(s) }; });
}
// Find wallpaper links inside any JSON. For each photo it takes the best size, not every size.
function pickImageUrls(json) {
  const BEST = ["fullHDURL", "largeImageURL", "hdurl", "large2x", "full", "original", "raw", "path", "regular", "file_url", "url", "src", "image", "img", "link"];
  const WEAK = new Set(["url", "src", "image", "img", "link"]); // these keys may hold a web page, so they must look like an image file
  const THUMB = ["previewURL", "thumb", "small", "thumbnail", "webformatURL", "medium"];
  const IMG = /^https?:\/\/[^\s"]+\.(jpe?g|png|webp)(\?[^\s"]*)?$/i, HTTP = /^https?:\/\//i;
  const out = [], seen = new Set();
  (function walk(v) {
    if (out.length >= 16) return;
    if (Array.isArray(v)) { v.forEach(walk); return; }
    if (!v || typeof v !== "object") return;
    for (const k of BEST) {
      const s = v[k];
      if (typeof s === "string" && HTTP.test(s) && (IMG.test(s) || !WEAK.has(k))) {
        if (!seen.has(s)) { seen.add(s); const tk = THUMB.find((x) => typeof v[x] === "string" && HTTP.test(v[x])); out.push({ full: s, thumb: tk ? v[tk] : s }); }
        return; // one image per object
      }
    }
    Object.values(v).forEach(walk);
  })(json);
  return out;
}
async function fetchWp(source, daily) {
  if (source === "picsum") return daily ? [{ thumb: picsumThumb("day-" + todayKey()), full: picsumFull("day-" + todayKey()) }] : randomPicsum();
  if (source === "wallhaven") {
    const o = whOpts(), sort = daily ? "random" : o.sort;
    const p = new URLSearchParams({ categories: "111", purity: "100", sorting: sort, order: "desc", atleast: o.res, page: String(daily ? 1 : wpPage) });
    if (o.q.trim()) p.set("q", o.q.trim());
    if (sort === "toplist") p.set("topRange", "1M");
    if (sort === "random") p.set("seed", daily ? todayKey().replace(/-/g, "").slice(2) : Math.random().toString(36).slice(2, 8).padEnd(6, "x"));
    const r = await fetch("https://wallhaven.cc/api/v1/search?" + p); if (!r.ok) throw new Error("HTTP " + r.status);
    const d = await r.json();
    return (d.data || []).slice(0, daily ? 1 : 12).map((x) => ({ thumb: (x.thumbs && (x.thumbs.large || x.thumbs.small)) || x.path, full: x.path }));
  }
  if (source === "custom") {
    const url = (S.wpCustom || "").trim(); if (!/^https?:\/\//i.test(url)) throw new Error("URL");
    const r = await fetch(url); if (!r.ok) throw new Error("HTTP " + r.status);
    if ((r.headers.get("content-type") || "").startsWith("image/")) return [{ thumb: url, full: url }];
    return pickImageUrls(await r.json());
  }
  return [];
}
async function setOnlineWallpaper(url) {
  S.wpUrl = url; WALLPAPER = null; await store.remove("wallpaper"); saveSettings(); await clearLive(); applyWallpaper(); drawWpGrid();
}
function wpStatus(msg) { const el = $("wpStatus"); if (!el) return; el.textContent = msg || ""; el.classList.toggle("hidden", !msg); }
function drawWpGrid() {
  const grid = $("wpGrid"); if (!grid) return; grid.innerHTML = "";
  wpItems.forEach((it) => {
    const b = document.createElement("button"); b.type = "button"; b.className = "wp-thumb" + (it.live ? " live" : "") + ((it.live ? S.wpLive && S.wpLive.url === it.full : S.wpUrl === it.full) ? " on" : "");
    const img = document.createElement("img"); img.referrerPolicy = "no-referrer"; img.src = it.thumb; img.alt = ""; img.loading = "lazy"; img.draggable = false;
    img.onerror = () => { // no preview picture: show the first frame of the video instead
      if (it.live) { const v = document.createElement("video"); v.muted = true; v.preload = "metadata"; v.playsInline = true; v.src = it.full + "#t=0.5"; img.replaceWith(v); }
      else b.classList.add("broken");
    };
    b.appendChild(img); b.onclick = () => { if (it.live) { setLiveUrl(it.full, it.thumb); drawWpGrid(); } else setOnlineWallpaper(it.full); }; grid.appendChild(b);
  });
}
function drawWpSources() {
  const T = t(), box = $("wpSources"); if (!box) return; box.innerHTML = "";
  if (!WP_SOURCES.some(([k]) => k === S.wpSource)) S.wpSource = "wallhaven";
  WP_SOURCES.forEach(([k, label]) => {
    const b = document.createElement("button"); b.type = "button"; b.className = "chip" + (S.wpSource === k ? " on" : ""); b.textContent = T[label] || label;
    b.onclick = () => { S.wpSource = k; wpPage = 1; saveSettings(); drawWpSources(); drawWpOpts(); if (k !== "live") loadWpItems(); else if ((S.liveProv || "pexels") !== "file") loadLiveItems(); else wpStatus(""); }; box.appendChild(b);
  });
}
function drawWpOpts() {
  const T = t(), box = $("wpOpts"); if (!box) return; box.innerHTML = "";
  const dlg = $("wpModal") && $("wpModal").querySelector(".wp-dialog"); if (dlg) dlg.classList.toggle("live-mode", S.wpSource === "live");
  const input = (ph, val, on, type = "text") => { const i = mk("input", "txt", ""); i.type = type; i.placeholder = ph; i.value = val || ""; i.dir = "ltr"; i.addEventListener("change", () => on(i.value)); i.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") { e.preventDefault(); i.blur(); go2(); } }); return i; };
  const go2 = () => { if (S.wpSource === "live") return; wpPage = 1; saveSettings(); loadWpItems(); };
  const searchBtn = () => { const b = mk("button", "mini", T.wpSearch); b.type = "button"; b.onclick = go2; return b; };
  if (S.wpSource === "wallhaven") {
    const o = whOpts(), r1 = mk("div", "wp-row");
    const sort = mk("select", "", ""); [["toplist", T.sTop], ["random", T.sRandom], ["date_added", T.sNew], ["views", T.sViews], ["favorites", T.sFav]].forEach(([v, l]) => { const op = mk("option", "", l); op.value = v; sort.append(op); }); sort.value = o.sort; sort.onchange = () => { o.sort = sort.value; go2(); };
    const res = mk("select", "", ""); [["1920x1080", "Full HD"], ["2560x1440", "2K"], ["3840x2160", "4K"]].forEach(([v, l]) => { const op = mk("option", "", l); op.value = v; res.append(op); }); res.value = o.res; res.onchange = () => { o.res = res.value; go2(); };
    r1.append(input(T.wpQuery, o.q, (v) => { o.q = v; }), sort, res, searchBtn());
    box.append(r1);
  } else if (S.wpSource === "live") {
    const prov = S.liveProv || "pexels";
    if (dlg) dlg.classList.toggle("live-online", prov !== "file");
    const chips = mk("div", "wp-sources");
    [["pexels", "Pexels"], ["pixabay", "Pixabay"], ["file", T.liveFile]].forEach(([k, label]) => {
      const c = mk("button", "chip" + (prov === k ? " on" : ""), label); c.type = "button";
      c.onclick = () => { S.liveProv = k; wpPage = 1; saveSettings(); drawWpOpts(); if (k === "file") wpStatus(""); else loadLiveItems(); }; chips.append(c);
    });
    box.append(chips);
    if (prov === "file") {
      const r1 = mk("div", "wp-row"), pick = mk("button", "mini", T.liveChoose); pick.type = "button"; pick.onclick = () => $("liveInput").click();
      const rm = mk("button", "mini ghost", T.liveRemove); rm.type = "button"; rm.onclick = clearLive; if (!S.wpLive) rm.disabled = true;
      r1.append(pick, rm);
      const r2 = mk("div", "wp-row"), urlIn = input(T.liveUrlPh, S.wpLive && S.wpLive.type === "url" ? S.wpLive.url : "", () => {});
      const ap = mk("button", "mini", T.wpApply); ap.type = "button"; ap.onclick = () => setLiveUrl(urlIn.value.trim());
      urlIn.addEventListener("keydown", (e) => { if (e.key === "Enter") ap.click(); });
      r2.append(urlIn, ap);
      const cur = mk("div", "wp-status", S.wpLive ? T.liveNow + " " + (S.wpLive.name || "") : T.liveNone); cur.dir = "auto";
      box.append(r1, r2, cur, mk("div", "muted wp-note", T.liveNote));
    } else {
      S.liveKeys = { pexels: "", pixabay: "", ...(S.liveKeys || {}) };
      const r1 = mk("div", "wp-row"), q = input(T.liveQueryPh, S.liveQuery, (v) => { S.liveQuery = v; });
      const more = mk("button", "mini ghost", T.liveMore); more.type = "button"; more.onclick = () => { wpPage++; loadLiveItems(); };
      const find = mk("button", "mini", T.wpSearch); find.type = "button"; find.onclick = () => { S.liveQuery = q.value; wpPage = 1; saveSettings(); loadLiveItems(); };
      q.addEventListener("keydown", (e) => { if (e.key === "Enter") find.click(); });
      r1.append(q, find, more);
      const r2 = mk("div", "wp-row"); r2.append(input(T.liveKeyPh + " (" + (prov === "pexels" ? "pexels.com/api" : "pixabay.com/api/docs") + ")", S.liveKeys[prov], (v) => { S.liveKeys[prov] = v.trim(); saveSettings(); loadLiveItems(); }, "password"));
      box.append(r1, r2, mk("div", "muted wp-note", T.liveNote));
    }
  } else if (S.wpSource === "custom") {
    const r = mk("div", "wp-row"); r.append(input(T.wpCustomPh, S.wpCustom, (v) => { S.wpCustom = v; }), searchBtn()); box.append(r, mk("div", "muted wp-note", T.wpCustomNote));
  }
}
function wpHost() { return S.wpSource === "custom" ? hostOf(S.wpCustom) : "wallhaven.cc"; }
async function fetchLive(prov) {
  const key = ((S.liveKeys || {})[prov] || "").trim(), q = (S.liveQuery || "").trim();
  if (prov === "pexels") {
    const u = q ? `https://api.pexels.com/videos/search?query=${encodeURIComponent(q)}&orientation=landscape&size=large&per_page=12&page=${wpPage}` : `https://api.pexels.com/videos/popular?per_page=12&page=${wpPage}`;
    const r = await fetch(u, { headers: { Authorization: key } }); if (!r.ok) throw new Error("HTTP " + r.status);
    const d = await r.json();
    return (d.videos || []).map((v) => {
      // best mp4 up to 1920 px wide: sharp, but not too heavy for a wallpaper
      const f = (v.video_files || []).filter((x) => x.file_type === "video/mp4" && x.link && x.width && x.width <= 1920).sort((a, b) => b.width - a.width)[0] || (v.video_files || []).find((x) => x.link);
      return f ? { thumb: v.image, full: f.link, live: true } : null;
    }).filter(Boolean);
  }
  const r = await fetch(`https://pixabay.com/api/videos/?key=${encodeURIComponent(key)}&q=${encodeURIComponent(q)}&per_page=12&page=${wpPage}&safesearch=true`); if (!r.ok) throw new Error("HTTP " + r.status);
  const d = await r.json();
  return (d.hits || []).map((h) => { const v = h.videos || {}, f = v.medium && v.medium.url ? v.medium : v.large && v.large.url ? v.large : v.small; return f && f.url ? { thumb: f.thumbnail || `https://i.vimeocdn.com/video/${h.picture_id}_640x360.jpg`, full: f.url, live: true } : null; }).filter(Boolean);
}
async function loadLiveItems() {
  const T = t(), prov = S.liveProv || "pexels";
  if (prov === "file") return;
  if (!((S.liveKeys || {})[prov] || "").trim()) { wpItems = []; drawWpGrid(); wpStatus(T.liveNeedKey); return; }
  wpStatus(T.wpLoading);
  try {
    let items = await fetchLive(prov);
    if (!items.length && wpPage > 1) { wpPage = 1; items = await fetchLive(prov); }
    wpItems = items; drawWpGrid(); wpStatus(items.length ? "" : T.wpEmpty);
  } catch (e) { wpItems = []; drawWpGrid(); wpStatus(T.liveErr.replace("{host}", prov === "pexels" ? "api.pexels.com" : "pixabay.com") + " (" + e.message + ")"); }
}
async function loadWpItems() {
  const T = t(); wpStatus(T.wpLoading);
  try {
    let items = await fetchWp(S.wpSource, false);
    if (!items.length && wpPage > 1) { wpPage = 1; items = await fetchWp(S.wpSource, false); }
    wpItems = items; drawWpGrid(); wpStatus(items.length ? "" : T.wpEmpty);
  } catch (e) { wpItems = []; drawWpGrid(); wpStatus(T.wpErr + " " + T.wpHint.replace("{host}", wpHost())); }
}
function openWpModal(source) {
  closeAll(); const m = $("wpModal"); if (!m) return;
  if (source) { S.wpSource = source; saveSettings(); }
  m.classList.remove("hidden"); $("wpAuto").checked = !!S.wpAuto; $("wpUrl").value = S.wpUrl || "";
  wpPage = 1; drawWpSources(); drawWpOpts(); if (S.wpSource !== "live") loadWpItems(); else if ((S.liveProv || "pexels") !== "file") loadLiveItems(); else wpStatus("");
}
async function autoWallpaper() { // once per day, if the user turned it on
  if (S.wpSource === "live") return;
  if (!WP_SOURCES.some(([k]) => k === S.wpSource)) S.wpSource = "wallhaven";
  if (!S.wpAuto || S.wpDay === todayKey()) return;
  try { const items = await fetchWp(S.wpSource, true); if (items[0]) { S.wpDay = todayKey(); await setOnlineWallpaper(items[0].full); } } catch (e) {}
}
// ---- "Next wallpaper": a new picture from the online source that is selected now ----
const wpSourceName = () => { const T = t(), s = S.wpSource || "wallhaven"; return s === "wallhaven" ? "Wallhaven" : s === "picsum" ? T.wpPicsum : s === "custom" ? T.wpCustomApi : T.wpLive; };
let nextBusy = false;
async function nextWallpaper() {
  if (nextBusy) return; nextBusy = true;
  const T = t(), src = S.wpSource || "wallhaven";
  try {
    toast(T.wpLoading + " (" + wpSourceName() + ")");
    if (src === "live") {
      const prov = S.liveProv || "pexels";
      if (prov === "file") { openWpModal("live"); return; }
      if (!((S.liveKeys || {})[prov] || "").trim()) { toast(T.liveNeedKey); openWpModal("live"); return; }
      wpPage = 1 + Math.floor(Math.random() * 4);
      let items = await fetchLive(prov); if (!items.length) { wpPage = 1; items = await fetchLive(prov); }
      const pool = items.filter((i) => !S.wpLive || S.wpLive.url !== i.full), pick = (pool.length ? pool : items)[Math.floor(Math.random() * (pool.length || items.length))];
      if (!pick) { toast(T.wpEmpty); return; }
      setLiveUrl(pick.full, pick.thumb); toast(T.wpNextDone); return;
    }
    wpPage = src === "wallhaven" ? 1 + Math.floor(Math.random() * 4) : 1; // a random page gives a different picture each time
    let items = await fetchWp(src, false); if (!items.length && wpPage > 1) { wpPage = 1; items = await fetchWp(src, false); }
    const pool = items.filter((i) => i.full !== S.wpUrl), pick = (pool.length ? pool : items)[Math.floor(Math.random() * (pool.length || items.length))];
    if (!pick) { toast(T.wpEmpty); return; }
    await setOnlineWallpaper(pick.full); toast(T.wpNextDone);
  } catch (e) { toast(T.wpErr + " " + T.wpHint.replace("{host}", wpHost())); }
  finally { nextBusy = false; wpPage = 1; }
}
if ($("wpNextBtn")) $("wpNextBtn").addEventListener("click", (e) => { e.stopPropagation(); nextWallpaper(); });
if ($("wpOnlineBtn")) $("wpOnlineBtn").addEventListener("click", (e) => { e.stopPropagation(); openWpModal(); });
if ($("wpRefresh")) $("wpRefresh").addEventListener("click", () => { wpPage++; if (S.wpSource === "live") loadLiveItems(); else loadWpItems(); });
if ($("wpAuto")) $("wpAuto").addEventListener("change", (e) => { S.wpAuto = e.target.checked; S.wpDay = ""; saveSettings(); if (S.wpAuto) autoWallpaper(); });
if ($("wpUrlApply")) $("wpUrlApply").addEventListener("click", () => {
  const v = $("wpUrl").value.trim(); if (!/^https?:\/\//i.test(v)) return; S.wpAuto = false; $("wpAuto").checked = false; setOnlineWallpaper(v);
});
if ($("wpUrl")) $("wpUrl").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); $("wpUrlApply").click(); } });
if ($("wpModal")) $("wpModal").addEventListener("click", (e) => { if (e.target.id === "wpModal") $("wpModal").classList.add("hidden"); });

// ================= LIVE (VIDEO) WALLPAPER =================
// A video file is kept in IndexedDB (it can be large). A video link is kept in the settings.
const idbOpen = () => new Promise((res, rej) => { const r = indexedDB.open("win11nt", 1); r.onupgradeneeded = () => r.result.createObjectStore("files"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const idbRun = async (mode, fn) => { const db = await idbOpen(); return new Promise((res, rej) => { const tx = db.transaction("files", mode), rq = fn(tx.objectStore("files")); tx.oncomplete = () => res(rq && rq.result); tx.onerror = () => rej(tx.error); }); };
let liveObjUrl = null;
function setLiveSrc(src) {
  const v = $("wallpaperVideo"); if (!v) return;
  if (liveObjUrl && liveObjUrl !== src) { URL.revokeObjectURL(liveObjUrl); liveObjUrl = null; }
  if (!src) { v.classList.remove("on"); v.pause(); v.removeAttribute("src"); v.load(); setTimeout(() => refreshAutoTheme(), 0); }
  else {
    if (src.startsWith("blob:")) liveObjUrl = src;
    v.onplaying = () => { v.classList.add("on"); setTimeout(() => refreshAutoTheme(), 500); }; v.onerror = () => v.classList.remove("on");
    v.src = src; v.play().catch(() => {});
  }
  applyWallpaper();
}
async function initLive() {
  const L = S.wpLive; if (!L) return setLiveSrc(null);
  try {
    if (L.type === "file") {
      const blob = await idbRun("readonly", (s) => s.get("live"));
      if (!blob) { S.wpLive = null; saveSettings(); return setLiveSrc(null); }
      setLiveSrc(URL.createObjectURL(blob));
    } else setLiveSrc(L.url);
  } catch (e) { setLiveSrc(null); }
}
async function clearLive() {
  if (!S.wpLive && !($("wallpaperVideo") && $("wallpaperVideo").getAttribute("src"))) return;
  const wasFile = S.wpLive && S.wpLive.type === "file"; S.wpLive = null; saveSettings(); setLiveSrc(null);
  if (wasFile) { try { await idbRun("readwrite", (s) => s.delete("live")); } catch (e) {} }
  if ($("wpModal") && !$("wpModal").classList.contains("hidden")) drawWpOpts();
}
async function setLiveFile(file) {
  if (!file || !/^video\//.test(file.type)) return;
  try { await idbRun("readwrite", (s) => s.put(file, "live")); } catch (e) { wpStatus(t().liveSaveErr); return; }
  S.wpLive = { type: "file", name: file.name }; saveSettings(); wpStatus(""); await initLive(); drawWpOpts();
}
function setLiveUrl(url, thumb) {
  if (!/^https?:\/\//i.test(url)) return;
  S.wpLive = { type: "url", url, name: url, ...(thumb ? { thumb } : {}) }; saveSettings(); initLive(); if ((S.liveProv || "file") === "file") drawWpOpts();
}
if ($("liveInput")) $("liveInput").addEventListener("change", (e) => { const f = e.target.files[0]; e.target.value = ""; setLiveFile(f); });
document.addEventListener("visibilitychange", () => { // save battery: pause while the tab is hidden
  const v = $("wallpaperVideo"); if (!v || !v.getAttribute("src")) return;
  if (document.hidden) v.pause(); else v.play().catch(() => {});
});

// ================= OPEN MODE + INSIDE (APP) WINDOWS =================
function openSite(url, name) {
  const m = S.openMode || "tab";
  if (m === "window") return openAppWindow(url, name);
  if (m === "same") { window.location.href = url; return; }
  window.open(url, "_blank");
}
// The browser blocks most sites inside frames. This rule removes the blocking headers, only for frames made by this page.
async function setupFrameRules() {
  try {
    if (typeof chrome === "undefined" || !chrome.declarativeNetRequest || !chrome.runtime) return;
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1],
      addRules: [{ id: 1, priority: 1,
        action: { type: "modifyHeaders", responseHeaders: [
          { header: "x-frame-options", operation: "remove" },
          { header: "content-security-policy", operation: "remove" },
          { header: "content-security-policy-report-only", operation: "remove" } ] },
        condition: { resourceTypes: ["sub_frame"], initiatorDomains: [chrome.runtime.id] } }]
    });
  } catch (e) { console.warn("frame rules", e); }
}

const APPWIN = { list: [], z: 100, n: 0, active: null };
const svgIco = (d) => `<svg viewBox="0 0 10 10" width="10" height="10" fill="none" stroke="currentColor" stroke-width="1">${d}</svg>`;
function openAppWindow(url, title) {
  const T = t(), layer = $("appWindows");
  if (!layer || !/^https?:\/\//i.test(url)) { window.open(url, "_blank"); return; }
  if (APPWIN.list.length >= 8) { toast(T.winLimit); return; }
  const id = ++APPWIN.n, el = document.createElement("div"); el.className = "app-win";
  const W = Math.min(980, Math.round(innerWidth * 0.72)), H = Math.min(660, Math.round(innerHeight * 0.72)), off = ((id - 1) % 6) * 30;
  el.style.width = W + "px"; el.style.height = H + "px";
  el.style.left = Math.max(8, Math.round((innerWidth - W) / 2) - 60 + off) + "px"; el.style.top = Math.max(8, 36 + off) + "px";
  const name = title || hostOf(url), w = { id, el, url, name, min: false, max: false };

  const head = mk("div", "aw-head"), ico = makeSiteIcon({ name: title || hostOf(url), url }, "aw-ico");
  const ttl = mk("span", "aw-title", name), btns = mk("div", "aw-btns");
  const mkBtn = (cls, title, html, fn) => { const b = mk("button", "aw-btn " + cls, ""); b.type = "button"; b.title = title; b.innerHTML = html; b.addEventListener("click", (e) => { e.stopPropagation(); fn(); }); return b; };
  const frame = document.createElement("iframe"); frame.className = "aw-frame"; frame.src = url; frame.referrerPolicy = "no-referrer-when-downgrade";
  // no allow-top-navigation: a site cannot jump out of its window
  frame.setAttribute("sandbox", "allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads allow-modals allow-presentation");
  frame.setAttribute("allow", "fullscreen; autoplay; clipboard-write; encrypted-media");
  btns.append(
    mkBtn("aw-reload", T.winReload, "⟳", () => { frame.src = w.url; load.classList.remove("done"); }),
    mkBtn("aw-tab", T.winOpenTab, "↗", () => window.open(w.url, "_blank")),
    mkBtn("aw-min", T.winMin, svgIco('<path d="M1 5h8"/>'), () => minimizeWin(w)),
    mkBtn("aw-max", T.winMax, svgIco('<rect x="1.5" y="1.5" width="7" height="7"/>'), () => toggleMaxWin(w)),
    mkBtn("aw-close", T.winClose, svgIco('<path d="M1 1l8 8M9 1L1 9"/>'), () => closeWin(w)));
  head.append(ico, ttl, btns);
  const body = mk("div", "aw-body"), shield = mk("div", "aw-shield"), load = mk("div", "aw-loading", ""), hint = mk("div", "aw-hint hidden", T.winHint);
  load.append(mk("span", "spin", ""));
  body.append(frame, shield, load, hint);
  const gR = mk("div", "aw-grip aw-grip-r"), gL = mk("div", "aw-grip aw-grip-l");
  el.append(head, body, gR, gL); layer.appendChild(el);
  const timer = setTimeout(() => { if (!load.classList.contains("done")) hint.classList.remove("hidden"); }, 8000);
  frame.addEventListener("load", () => { load.classList.add("done"); hint.classList.add("hidden"); clearTimeout(timer); });
  head.addEventListener("dblclick", (e) => { if (!e.target.closest("button")) toggleMaxWin(w); });
  el.addEventListener("pointerdown", () => focusWin(w), true);

  const lim = (v, a, b) => Math.max(a, Math.min(b, v));
  head.addEventListener("pointerdown", (e) => { // move the window
    if (e.button !== 0 || e.target.closest("button") || w.max) return;
    const sx = e.clientX, sy = e.clientY, ox = el.offsetLeft, oy = el.offsetTop; layer.classList.add("dragging");
    const mv = (ev) => { el.style.left = lim(ox + ev.clientX - sx, 120 - el.offsetWidth, innerWidth - 120) + "px"; el.style.top = lim(oy + ev.clientY - sy, 0, innerHeight - 50 - 40) + "px"; };
    const up = () => { layer.classList.remove("dragging"); removeEventListener("pointermove", mv); removeEventListener("pointerup", up); };
    addEventListener("pointermove", mv); addEventListener("pointerup", up);
  });
  const grip = (g, left) => g.addEventListener("pointerdown", (e) => { // resize the window
    if (e.button !== 0 || w.max) return; e.preventDefault();
    const sx = e.clientX, sy = e.clientY, ow = el.offsetWidth, oh = el.offsetHeight, ol = el.offsetLeft, ot = el.offsetTop; layer.classList.add("dragging");
    const mv = (ev) => {
      const dx = ev.clientX - sx, dy = ev.clientY - sy;
      el.style.height = lim(oh + dy, 220, innerHeight - 50 - ot) + "px";
      if (left) { const nw = lim(ow - dx, 320, ol + ow); el.style.width = nw + "px"; el.style.left = ol + ow - nw + "px"; }
      else el.style.width = lim(ow + dx, 320, innerWidth - ol) + "px";
    };
    const up = () => { layer.classList.remove("dragging"); removeEventListener("pointermove", mv); removeEventListener("pointerup", up); };
    addEventListener("pointermove", mv); addEventListener("pointerup", up);
  });
  grip(gR, false); grip(gL, true);

  APPWIN.list.push(w); closeAll(); focusWin(w); renderRunning();
}
function focusWin(w) {
  if (w.min) { w.min = false; w.el.classList.remove("min"); }
  w.el.style.zIndex = ++APPWIN.z; APPWIN.active = w.id;
  APPWIN.list.forEach((x) => x.el.classList.toggle("active", x === w)); renderRunning();
}
function minimizeWin(w) {
  w.min = true; w.el.classList.add("min"); if (APPWIN.active === w.id) APPWIN.active = null;
  APPWIN.list.forEach((x) => x.el.classList.remove("active")); renderRunning();
}
function toggleMaxWin(w) {
  w.max = !w.max; w.el.classList.toggle("max", w.max);
  const b = w.el.querySelector(".aw-max"); if (b) b.title = w.max ? t().winRestore : t().winMax;
}
function closeWin(w) {
  w.el.remove(); APPWIN.list = APPWIN.list.filter((x) => x !== w);
  if (APPWIN.active === w.id) { APPWIN.active = null; const top = [...APPWIN.list].filter((x) => !x.min).sort((a, b) => b.el.style.zIndex - a.el.style.zIndex)[0]; if (top) return focusWin(top); }
  renderRunning();
}
function renderRunning() {
  const box = $("taskbarRunning"); if (!box) return; box.innerHTML = "";
  APPWIN.list.forEach((w) => {
    const b = document.createElement("button"); b.className = "task-pin-btn running" + (APPWIN.active === w.id && !w.min ? " active" : "") + (w.min ? " is-min" : ""); b.title = w.name;
    b.appendChild(makeSiteIcon({ name: w.name, url: w.url }));
    b.onclick = () => { if (w.min || APPWIN.active !== w.id) focusWin(w); else minimizeWin(w); };
    b.oncontextmenu = (e) => { e.preventDefault(); e.stopPropagation(); showCtx(e.clientX, e.clientY, [ { icon: "external", label: t().winOpenTab, run: () => window.open(w.url, "_blank") }, { icon: "close", label: t().winClose, run: () => closeWin(w) } ]); };
    box.appendChild(b);
  });
}
// A click inside a frame does not reach this page, so the page "blur" event tells which window got the focus.
window.addEventListener("blur", () => setTimeout(() => {
  const f = document.activeElement; if (!f || !f.classList || !f.classList.contains("aw-frame")) return;
  const w = APPWIN.list.find((x) => x.el.contains(f)); if (w && APPWIN.active !== w.id) focusWin(w);
}, 0));

// ================= SETTINGS WINDOW (sections + search) =================
let setSec = "general";
function openSettings(sec) {
  closeAll("settingsPanel"); const p = $("settingsPanel"); if (!p) return;
  p.classList.remove("hidden"); bringPanel("settingsPanel"); if (sec) showSettingsSection(sec);
}
function renderSettingsNav() {
  const T = t(), nav = $("setNav"); if (!nav) return; nav.innerHTML = "";
  document.querySelectorAll("#setContent .set-sec").forEach((sec) => {
    const b = mk("button", "set-nav-btn" + (sec.dataset.sec === setSec ? " on" : ""), ""); b.type = "button";
    const ni = mk("span", "set-nav-ico", ""); ni.innerHTML = svgI(sec.dataset.icon, 18); b.append(ni, mk("span", "", T[sec.dataset.title] || ""));
    b.onclick = () => { const s = $("setSearch"); if (s) s.value = ""; filterSettings(""); showSettingsSection(sec.dataset.sec); };
    nav.appendChild(b);
  });
}
function showSettingsSection(id) {
  setSec = id;
  document.querySelectorAll("#setContent .set-sec").forEach((s) => s.classList.toggle("on", s.dataset.sec === id));
  const s = document.querySelector(`#setContent .set-sec[data-sec="${id}"]`);
  if ($("setSecTitle")) $("setSecTitle").textContent = s ? t()[s.dataset.title] || "" : "";
  const c = $("setContent"); if (c) c.scrollTop = 0; renderSettingsNav();
}
function filterSettings(q) {
  q = q.trim().toLowerCase(); const panel = $("settingsPanel"); if (!panel) return;
  panel.classList.toggle("searching", !!q);
  const rows = document.querySelectorAll("#setContent .row");
  if (!q) { rows.forEach((r) => r.classList.remove("nomatch")); document.querySelectorAll("#setContent .set-sec").forEach((s) => s.classList.remove("has-match")); showSettingsSection(setSec); return; }
  document.querySelectorAll("#setContent .set-sec").forEach((sec) => {
    let n = 0; sec.querySelectorAll(".row").forEach((r) => { const ok = r.textContent.toLowerCase().includes(q); r.classList.toggle("nomatch", !ok); if (ok) n++; });
    sec.classList.toggle("has-match", n > 0);
  });
  $("setSecTitle").textContent = t().setResults;
}
if ($("setSearch")) $("setSearch").addEventListener("input", (e) => filterSettings(e.target.value));

const setCb = (id, key, after) => { const el = $(id); if (!el) return; el.addEventListener("change", (e) => { S[key] = e.target.type === "checkbox" ? e.target.checked : e.target.value; saveSettings(); if (after) after(); render(); }); };
if ($("setAutoTheme")) $("setAutoTheme").addEventListener("change", (e) => { S.autoTheme = e.target.checked; saveSettings(); if (S.autoTheme) refreshAutoTheme(true); else applyThemeAndAccent(); render(); });
if ($("setGlass")) $("setGlass").addEventListener("input", (e) => { S.glass = +e.target.value; applyThemeAndAccent(); saveSettings(); });
setCb("setDragFolder", "dragFolder"); setCb("setTraySec", "traySeconds");
setCb("setHeroStyle", "heroStyle"); setCb("setHeroInfo", "heroInfo"); setCb("setHeroQuick", "heroQuick");
setCb("setIconSize", "iconSize"); setCb("setLabels", "labels"); setCb("setStartRecent", "startRecent"); setCb("setOpenMode", "openMode");
setCb("setSettingsIcon", "settingsIcon", () => ensureSettingsIcon());
if ($("wpLiveBtn")) $("wpLiveBtn").addEventListener("click", (e) => { e.stopPropagation(); openWpModal("live"); });
if ($("clearRecentBtn")) $("clearRecentBtn").addEventListener("click", () => { S.recent = []; saveSettings(); renderStartMenu(); toast(t().cleared); });
if ($("resetPinnedBtn")) $("resetPinnedBtn").addEventListener("click", () => { S.taskbarPinned = [...DEFAULTS.taskbarPinned]; saveSettings(); renderTaskbarPinned(); toast(t().pinReset); });

// ================= SETTINGS ICON ON THE DESKTOP =================
function sysTile() {
  const d = document.createElement("div"); d.className = "tile sys-tile";
  d.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>';
  return d;
}
function ensureSettingsIcon() {
  const i = SITES.findIndex((s) => s.sys === "settings");
  if (S.settingsIcon && i < 0) { SITES.push({ sys: "settings", name: "Settings" }); saveSites(); }
  else if (!S.settingsIcon && i >= 0) {
    SITES.splice(i, 1); S.taskbarPinned = (S.taskbarPinned || []).filter((x) => x !== i).map((x) => (x > i ? x - 1 : x)); saveSites(); saveSettings();
  }
}
function sysMenu() {
  const T = t();
  return [ { icon: "gear", label: T.settings, run: () => openSettings() }, "-", { icon: "trash", label: T.settingsRemove, run: () => { S.settingsIcon = false; ensureSettingsIcon(); saveSettings(); render(); } } ];
}

// ================= ACCOUNT, BACKUP, GOOGLE =================
const APP_ID = "win11-newtab";
const manifestVersion = () => { try { return chrome.runtime.getManifest().version; } catch (e) { return "1"; } };
const blobToDataUrl = (b) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(b); });
const dataUrlToBlob = async (u) => (await fetch(u)).blob();
function u8ToB64(u8) { let s = ""; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); }
function b64ToU8(b) { const s = atob(b), u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; }
async function gzipText(txt) { const cs = new CompressionStream("gzip"), w = cs.writable.getWriter(); w.write(new TextEncoder().encode(txt)); w.close(); return u8ToB64(new Uint8Array(await new Response(cs.readable).arrayBuffer())); }
async function gunzipText(b64) { const ds = new DecompressionStream("gzip"), w = ds.writable.getWriter(); w.write(b64ToU8(b64)); w.close(); return new TextDecoder().decode(await new Response(ds.readable).arrayBuffer()); }

// One backup object holds everything. level: "file" (all), "drive" (no video file), "chrome" (small data only).
async function collectBackup(level) {
  const s = structuredClone(S); delete s.sync; // sign-in state belongs to this device
  if (!S.backupKeys) { s.liveKeys = { pexels: "", pixabay: "" }; s.wpCustom = ""; }
  const b = { app: APP_ID, format: 1, version: manifestVersion(), createdAt: new Date().toISOString(), settings: s, sites: structuredClone(SITES), notes: NOTES, todos: structuredClone(TODOS), mysites: structuredClone(MYSITES).map((m) => (level === "chrome" && /^data:/i.test(m.icon || "") ? { name: m.name, url: m.url, added: m.added } : m)), media: {} };
  const withMedia = level === "file" ? S.backupMedia !== false : level === "drive";
  if (withMedia) b.media.wallpaper = WALLPAPER || null;
  if (level === "file" && S.backupMedia !== false && S.wpLive && S.wpLive.type === "file") {
    try { const blob = await idbRun("readonly", (st) => st.get("live")); if (blob) b.media.live = { name: S.wpLive.name, dataUrl: await blobToDataUrl(blob) }; } catch (e) {}
  }
  return b;
}
async function applyBackup(b) {
  if (!b || b.app !== APP_ID || !b.settings) throw new Error("format");
  const ns = { ...structuredClone(DEFAULTS), ...b.settings, sync: S.sync }, media = b.media || {};
  // a backup made without API keys must not erase the keys that are on this device
  ns.liveKeys = { pexels: "", pixabay: "", ...(ns.liveKeys || {}) };
  ["pexels", "pixabay"].forEach((k) => { if (!ns.liveKeys[k] && S.liveKeys && S.liveKeys[k]) ns.liveKeys[k] = S.liveKeys[k]; });
  if (!ns.wpCustom && S.wpCustom) ns.wpCustom = S.wpCustom;
  if (media.live && media.live.dataUrl) { await idbRun("readwrite", (st) => st.put(dataUrlToBlobSync(media.live.dataUrl), "live")); ns.wpLive = { type: "file", name: media.live.name || "video" }; }
  else if (ns.wpLive && ns.wpLive.type === "file") { let have = null; try { have = await idbRun("readonly", (st) => st.get("live")); } catch (e) {} if (!have) ns.wpLive = null; }
  const upd = { settings: ns, sites: Array.isArray(b.sites) ? b.sites : SITES, notes: b.notes || "", todos: Array.isArray(b.todos) ? b.todos : [], mysites: Array.isArray(b.mysites) ? b.mysites : MYSITES };
  if (media.wallpaper) upd.wallpaper = media.wallpaper;
  await store.set(upd);
  if ("wallpaper" in media && !media.wallpaper) await store.remove("wallpaper");
  try { sessionStorage.setItem("w11restored", "1"); } catch (e) {}
  location.reload();
}
function dataUrlToBlobSync(u) { const [h, d] = u.split(","), mime = (h.match(/:(.*?);/) || [])[1] || "application/octet-stream", bin = atob(d), a = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return new Blob([a], { type: mime }); }
const persistSyncState = () => store.set({ settings: S }); // writes only; it must not start a new sync

// ---- Chrome Sync: the Google account of the browser, no setup needed (about 90 KB in total) ----
const CH_PREFIX = "bk_", CH_CHUNK = 7000, chSync = (fn) => new Promise((res, rej) => fn((r) => (chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res(r))));
async function chromeSyncSave() {
  if (!(typeof chrome !== "undefined" && chrome.storage && chrome.storage.sync)) throw new Error("unsupported");
  const gz = await gzipText(JSON.stringify(await collectBackup("chrome"))), n = Math.ceil(gz.length / CH_CHUNK);
  if (n > 13) throw new Error("toobig");
  const old = await chSync((cb) => chrome.storage.sync.get(null, cb)), rm = Object.keys(old).filter((k) => k.startsWith(CH_PREFIX));
  if (rm.length) await chSync((cb) => chrome.storage.sync.remove(rm, cb));
  const o = {}; for (let i = 0; i < n; i++) o[CH_PREFIX + i] = gz.slice(i * CH_CHUNK, (i + 1) * CH_CHUNK); o[CH_PREFIX + "meta"] = { n, ts: Date.now(), v: 1 };
  await chSync((cb) => chrome.storage.sync.set(o, cb));
  S.sync.lastChrome = Date.now(); persistSyncState();
}
async function chromeSyncLoad() {
  if (!(typeof chrome !== "undefined" && chrome.storage && chrome.storage.sync)) throw new Error("unsupported");
  const m = (await chSync((cb) => chrome.storage.sync.get(CH_PREFIX + "meta", cb)))[CH_PREFIX + "meta"]; if (!m) throw new Error("empty");
  const keys = Array.from({ length: m.n }, (_, i) => CH_PREFIX + i), r = await chSync((cb) => chrome.storage.sync.get(keys, cb));
  return JSON.parse(await gunzipText(keys.map((k) => r[k] || "").join("")));
}
const chromeProfileEmail = () => new Promise((res) => { try { chrome.identity.getProfileUserInfo({ accountStatus: "ANY" }, (i) => res((i && i.email) || "")); } catch (e) { res(""); } });

// ---- Google Drive: a private "app data" file, only this extension can see it ----
const DRIVE_FILE = "win11-newtab-backup.json";
// Chrome signs in with chrome.identity.getAuthToken. Edge does not support it, so Edge uses the web flow (launchWebAuthFlow).
// For Edge: make an OAuth client of type "Web application" in Google Cloud, add the redirect URL shown in the Account window,
// and put its Client ID here.
const GOOGLE_WEB_CLIENT_ID = "57370798468-16hbfuu5v3mq0qpd0gvnhjq4hs26b464.apps.googleusercontent.com";
const GOOGLE_SCOPES = ["https://www.googleapis.com/auth/drive.appdata", "https://www.googleapis.com/auth/userinfo.email", "https://www.googleapis.com/auth/userinfo.profile"];
const IS_EDGE = /\bEdg\//.test(navigator.userAgent);
// Only real Google Chrome supports chrome.identity.getAuthToken. Brave, Opera, Vivaldi, Yandex, Edge... have the function but it fails,
// so every browser that is not Google Chrome uses the web flow (launchWebAuthFlow).
const IS_REAL_CHROME = (() => {
  try {
    const b = navigator.userAgentData && navigator.userAgentData.brands;
    if (b && b.length) return b.some((x) => x.brand === "Google Chrome") && !b.some((x) => /Edge|Brave|Opera|Vivaldi|Yandex/i.test(x.brand));
  } catch (e) {}
  return /Chrome\//.test(navigator.userAgent) && !/Edg\/|OPR\/|Vivaldi|YaBrowser|SamsungBrowser|Whale/.test(navigator.userAgent) && !navigator.brave;
})();
function useWebFlow() {
  return IS_EDGE || !IS_REAL_CHROME || !(typeof chrome !== "undefined" && chrome.identity && chrome.identity.getAuthToken) || !!(S && S.sync && S.sync.authMode === "web");
}
function launchAuthFlow(url, interactive) {
  return new Promise((res, rej) => chrome.identity.launchWebAuthFlow({ url, interactive: !!interactive }, (r) => (chrome.runtime.lastError || !r ? rej(new Error((chrome.runtime.lastError && chrome.runtime.lastError.message) || "no response")) : res(r))));
}
async function webAuthToken(interactive) {
  const c = S.sync && S.sync.webToken; if (c && c.exp > Date.now() + 60000) return c.token;
  if (typeof chrome === "undefined" || !chrome.identity || !chrome.identity.launchWebAuthFlow) throw new Error("unsupported");
  const redirect = chrome.identity.getRedirectURL();
  if (!GOOGLE_WEB_CLIENT_ID) throw new Error("webclient:" + redirect);
  const url = "https://accounts.google.com/o/oauth2/v2/auth?" + new URLSearchParams({ client_id: GOOGLE_WEB_CLIENT_ID, response_type: "token", redirect_uri: redirect, scope: GOOGLE_SCOPES.join(" "), prompt: interactive ? "select_account" : "none" });
  let resp; try { resp = await launchAuthFlow(url, interactive); } catch (e) { throw new Error(interactive ? e.message : "expired"); }
  const p = new URLSearchParams(new URL(resp).hash.slice(1)), tok = p.get("access_token"); if (!tok) throw new Error(p.get("error") || "no token");
  S.sync.webToken = { token: tok, exp: Date.now() + (Number(p.get("expires_in")) || 3600) * 1000 }; persistSyncState();
  return tok;
}
async function getGoogleToken(interactive) {
  if (useWebFlow()) return webAuthToken(interactive);
  try { return await chromeAuthToken(interactive); }
  catch (e) {
    // Chrome without a signed-in profile, or any other getAuthToken failure: fall back to the web flow
    if (/did not approve|cancel|closed/i.test(String((e && e.message) || e))) throw e;
    if (!(typeof chrome !== "undefined" && chrome.identity && chrome.identity.launchWebAuthFlow)) throw e;
    const tok = await webAuthToken(interactive); S.sync.authMode = "web"; persistSyncState(); return tok;
  }
}
function chromeAuthToken(interactive) {
  return new Promise((res, rej) => {
    if (!(typeof chrome !== "undefined" && chrome.identity && chrome.identity.getAuthToken)) return rej(new Error("unsupported"));
    chrome.identity.getAuthToken({ interactive: !!interactive }, (tok) => {
      if (chrome.runtime.lastError || !tok) return rej(new Error((chrome.runtime.lastError && chrome.runtime.lastError.message) || "no token"));
      res(typeof tok === "string" ? tok : tok.token);
    });
  });
}
async function gfetch(url, opt = {}, retry = true) {
  const tok = await getGoogleToken(false), r = await fetch(url, { ...opt, headers: { ...(opt.headers || {}), Authorization: "Bearer " + tok } });
  if (r.status === 401 && retry) {
    if (useWebFlow()) { if (S.sync) S.sync.webToken = null; } else await new Promise((res) => chrome.identity.removeCachedAuthToken({ token: tok }, res));
    return gfetch(url, opt, false);
  }
  if (!r.ok) throw new Error("HTTP " + r.status);
  return r;
}
async function driveFindFile() {
  const q = encodeURIComponent(`name='${DRIVE_FILE}' and trashed=false`);
  const d = await (await gfetch(`https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=${q}&fields=files(id,modifiedTime)&pageSize=1`)).json();
  return (d.files && d.files[0]) || null;
}
async function driveSave() {
  const body = JSON.stringify(await collectBackup("drive")), f = await driveFindFile();
  if (f) await gfetch(`https://www.googleapis.com/upload/drive/v3/files/${f.id}?uploadType=media`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body });
  else {
    const bd = "w11nt" + Date.now(), meta = JSON.stringify({ name: DRIVE_FILE, parents: ["appDataFolder"] });
    await gfetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart", { method: "POST", headers: { "Content-Type": `multipart/related; boundary=${bd}` }, body: `--${bd}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${meta}\r\n--${bd}\r\nContent-Type: application/json\r\n\r\n${body}\r\n--${bd}--` });
  }
  S.sync.lastDrive = Date.now(); persistSyncState();
}
async function driveLoad() { const f = await driveFindFile(); if (!f) throw new Error("empty"); return (await gfetch(`https://www.googleapis.com/drive/v3/files/${f.id}?alt=media`)).json(); }
async function connectGoogle() {
  await getGoogleToken(true);
  const p = await (await gfetch("https://www.googleapis.com/oauth2/v2/userinfo")).json();
  S.sync.google = { email: p.email || "", name: p.name || "", picture: p.picture || "" };
  if (!S.profile.name && p.name) S.profile.name = p.name;
  persistSyncState(); renderStartUser();
  return !!(await driveFindFile()); // true = a backup is waiting in the cloud
}
async function disconnectGoogle() {
  try { const tok = await getGoogleToken(false); if (!useWebFlow()) await new Promise((r) => chrome.identity.removeCachedAuthToken({ token: tok }, r)); fetch("https://oauth2.googleapis.com/revoke?token=" + tok, { method: "POST" }).catch(() => {}); } catch (e) {}
  S.sync.webToken = null; S.sync.authMode = null; S.sync.google = null; S.sync.driveAuto = false; persistSyncState(); renderStartUser();
}

// ---- automatic saving (after changes, with a pause so many changes make one upload) ----
let syncTimer = null, syncing = false;
function scheduleSync() {
  if (syncing || !S || !S.sync || !((S.sync.driveAuto && S.sync.google) || S.sync.chromeAuto)) return;
  clearTimeout(syncTimer); syncTimer = setTimeout(runAutoSync, 20000);
}
async function runAutoSync() {
  syncing = true;
  try { if (S.sync.driveAuto && S.sync.google) await driveSave(); } catch (e) { console.warn("drive sync", e); }
  try { if (S.sync.chromeAuto) await chromeSyncSave(); } catch (e) { console.warn("chrome sync", e); }
  syncing = false;
}

// ---- account window ----
function fillAvatar(el) {
  el.innerHTML = ""; const g = S.sync && S.sync.google, pic = (S.profile && S.profile.avatar) || (g && g.picture), name = (S.profile && S.profile.name) || (g && g.name) || "";
  const letter = () => { el.textContent = name ? name.trim()[0].toUpperCase() : "👤"; };
  if (!pic) return letter();
  const im = document.createElement("img"); im.alt = ""; im.referrerPolicy = "no-referrer"; im.src = pic; im.onerror = () => { im.remove(); letter(); }; el.appendChild(im);
}
function renderStartUser() {
  const a = $("startAvatar"), n = $("startUserName"); if (!a || !n) return;
  const g = S.sync && S.sync.google; n.textContent = (S.profile && S.profile.name) || (g && g.name) || t().user; fillAvatar(a);
}
function openAccount() { closeAll("accountPanel"); const p = $("accountPanel"); if (!p) return; p.classList.remove("hidden"); bringPanel("accountPanel"); renderAccount(); }
function accError(e) {
  const T = t(), m = String((e && e.message) || e);
  if (/^webclient:/.test(m)) return T.accNeedWebClient + "\n" + m.slice(10);
  if (/^expired$/.test(m)) return T.accSessionExpired;
  if (/toobig/.test(m)) return T.accTooBig;
  if (/empty/.test(m)) return T.accNoCloud;
  if (/unsupported/.test(m)) return T.accNoSupport;
  if (/client|OAuth2|invalid_client|bad client/i.test(m)) return T.accNeedClient;
  if (/sign.?in|signed in/i.test(m)) return T.accNoChromeAcc;
  if (/did not approve|cancel|closed/i.test(m)) return T.accCancelled;
  return m;
}
const fmtTime = (ts) => (ts ? new Date(ts).toLocaleString(locale()) : "");
function renderAccount() {
  const T = t(), body = $("accBody"); if (!body) return; body.innerHTML = "";
  S.sync = { ...DEFAULTS.sync, ...(S.sync || {}) }; S.profile = { ...DEFAULTS.profile, ...(S.profile || {}) };
  const g = S.sync.google;
  const card = (title, desc) => { const c = mk("section", "acc-card"); c.append(mk("h3", "", title)); if (desc) c.append(mk("p", "muted acc-desc", desc)); body.appendChild(c); return c; };
  const btn = (label, cls, fn) => { const b = mk("button", "mini " + (cls || ""), label); b.type = "button"; b.onclick = fn; return b; };
  const sw = (label, checked, on) => { const r = mk("label", "acc-row"), i = document.createElement("input"); i.type = "checkbox"; i.checked = !!checked; i.onchange = () => on(i.checked); r.append(mk("span", "", label), i); return r; };
  const status = () => mk("div", "acc-status", "");
  const run = (statusEl, fn, ok) => async () => { statusEl.className = "acc-status"; statusEl.textContent = T.accBusy; try { const r = await fn(); statusEl.textContent = ok === false ? "" : ok || T.accSaved; if (typeof r === "string") statusEl.textContent = r; renderAccountLast(); } catch (e) { statusEl.className = "acc-status err"; statusEl.textContent = accError(e); } };
  const confirmRestore = (data) => showWinModal(T.accRestoreCloud, T.accRestoreConfirm, () => applyBackup(data));

  // profile
  const pc = card(T.accProfile), pr = mk("div", "acc-profile"), av = mk("button", "acc-avatar lg", ""); av.type = "button"; av.title = T.accAvatarChange; av.onclick = () => $("avatarInput").click(); fillAvatar(av);
  const info = mk("div", "acc-profile-info"), name = document.createElement("input"); name.className = "txt full"; name.placeholder = T.accNamePh; name.value = S.profile.name || "";
  name.onchange = () => { S.profile.name = name.value.trim(); saveSettings(); renderStartUser(); fillAvatar(av); };
  name.onkeydown = (e) => { e.stopPropagation(); if (e.key === "Enter") name.blur(); };
  const small = mk("div", "acc-profile-btns"); small.append(btn(T.accAvatarChange, "ghost", () => $("avatarInput").click()));
  if (S.profile.avatar) small.append(btn(T.accAvatarRemove, "ghost", () => { S.profile.avatar = null; saveSettings(); renderAccount(); renderStartUser(); }));
  info.append(name, small); if (g) info.append(mk("div", "muted", T.accSignedIn + " " + g.email));
  pr.append(av, info); pc.append(pr);

  // Google Drive
  const gc = card(T.accGoogle, T.accGoogleDesc), gs = status();
  if (!g) gc.append(btn(T.accConnect, "", run(gs, async () => { const found = await connectGoogle(); renderAccount(); return found ? T.accFound : T.accSaved; }, false)), gs);
  else {
    const who = mk("div", "acc-who"), pic = mk("span", "acc-avatar sm", ""); fillAvatar(pic); who.append(pic, mk("span", "", g.email || g.name)); gc.append(who);
    gc.append(sw(T.accAuto, S.sync.driveAuto, (v) => { S.sync.driveAuto = v; persistSyncState(); if (v) scheduleSync(); }));
    const row = mk("div", "acc-btns"); row.append(
      btn(T.accSaveNow, "", run(gs, driveSave)),
      btn(T.accRestoreCloud, "ghost", run(gs, async () => { confirmRestore(await driveLoad()); }, false)),
      btn(T.accDisconnect, "ghost danger-text", run(gs, async () => { await disconnectGoogle(); renderAccount(); }, false)));
    gc.append(row, mk("div", "muted acc-last", ""), gs); gc.querySelector(".acc-last").dataset.k = "drive";
  }

  // Chrome Sync
  const cc = card(IS_EDGE ? T.accEdge : T.accChrome, IS_EDGE ? T.accEdgeDesc : T.accChromeDesc), cs = status(), cwho = mk("div", "muted", "");
  chromeProfileEmail().then((em) => { cwho.textContent = em ? T.accChromeAs + " " + em : T.accNoChromeAcc; });
  cc.append(cwho, sw(T.accAuto, S.sync.chromeAuto, (v) => { S.sync.chromeAuto = v; persistSyncState(); if (v) scheduleSync(); }));
  const crow = mk("div", "acc-btns"); crow.append(btn(T.accSaveNow, "", run(cs, chromeSyncSave)), btn(T.accRestoreCloud, "ghost", run(cs, async () => { confirmRestore(await chromeSyncLoad()); }, false)));
  const clast = mk("div", "muted acc-last", ""); clast.dataset.k = "chrome"; cc.append(crow, clast, cs);

  // manual backup
  const lc = card(T.accLocal, T.accLocalDesc), ls = status();
  lc.append(sw(T.accMedia, S.backupMedia !== false, (v) => { S.backupMedia = v; saveSettings(); }), sw(T.accKeys, S.backupKeys, (v) => { S.backupKeys = v; saveSettings(); }), mk("div", "muted acc-desc", T.accKeysNote));
  const lrow = mk("div", "acc-btns"); lrow.append(
    btn(T.accDownload, "", run(ls, async () => {
      const b = await collectBackup("file"), url = URL.createObjectURL(new Blob([JSON.stringify(b)], { type: "application/json" })), a = document.createElement("a");
      a.href = url; a.download = `win11-newtab-backup-${new Date().toISOString().slice(0, 10)}.json`; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 2000);
    }, T.accSaved)),
    btn(T.accRestoreFile, "ghost", () => $("restoreInput").click()));
  lc.append(lrow, ls); ls.id = "accFileStatus";
  renderAccountLast();
}
function renderAccountLast() {
  document.querySelectorAll("#accBody .acc-last").forEach((el) => { const ts = el.dataset.k === "drive" ? S.sync.lastDrive : S.sync.lastChrome; el.textContent = T_last(ts); });
}
const T_last = (ts) => t().accLast + " " + (ts ? fmtTime(ts) : t().accNever);

if ($("startUser")) $("startUser").addEventListener("click", (e) => { e.stopPropagation(); openAccount(); });
if ($("openAccountBtn")) $("openAccountBtn").addEventListener("click", (e) => { e.stopPropagation(); openAccount(); });
if ($("avatarInput")) $("avatarInput").addEventListener("change", async (e) => {
  const f = e.target.files[0]; e.target.value = ""; if (!f) return;
  try {
    const bmp = await createImageBitmap(f), s = Math.min(bmp.width, bmp.height), cv = document.createElement("canvas"); cv.width = cv.height = 128;
    cv.getContext("2d").drawImage(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s, 0, 0, 128, 128);
    S.profile.avatar = cv.toDataURL("image/jpeg", 0.85); saveSettings(); renderAccount(); renderStartUser();
  } catch (err) {}
});
if ($("restoreInput")) $("restoreInput").addEventListener("change", async (e) => {
  const f = e.target.files[0]; e.target.value = ""; if (!f) return; const T = t(), st = $("accFileStatus");
  try {
    const b = JSON.parse(await f.text()); if (!b || b.app !== APP_ID || !b.settings) throw new Error("format");
    showWinModal(T.accRestoreFile, T.accRestoreConfirm, () => applyBackup(b));
  } catch (err) { if (st) { st.className = "acc-status err"; st.textContent = T.accBadFile; } }
});
try { if (sessionStorage.getItem("w11restored")) { sessionStorage.removeItem("w11restored"); setTimeout(() => toast(t().accRestoreDone), 600); } } catch (e) {}

// ================= MOVABLE WINDOWS (settings, account) =================
// Drag the top part of the window. The place is saved. Double-click the top part to put it back in the centre.
function clampPanel(el) {
  if (!el.style.left) return;
  const w = el.offsetWidth, x = Math.max(0, Math.min(parseFloat(el.style.left), Math.max(0, innerWidth - w))), y = Math.max(0, Math.min(parseFloat(el.style.top), innerHeight - 60)); // the whole window stays on screen, so its buttons stay reachable
  el.style.left = x + "px"; el.style.top = y + "px";
}
function applyPanelPos(el, key) {
  const p = S.panelPos && S.panelPos[key];
  if (p) { el.style.left = p.x + "px"; el.style.top = p.y + "px"; el.style.transform = "none"; clampPanel(el); }
  else { el.style.left = ""; el.style.top = ""; el.style.transform = ""; }
}
function makePanelDraggable(id, key, handleSel) {
  const el = $(id); if (!el) return; applyPanelPos(el, key);
  const grab = (e) => {
    if (e.button !== 0 || e.target.closest("button, input, select, textarea, a")) return;
    const r = el.getBoundingClientRect(), sx = e.clientX, sy = e.clientY;
    el.style.left = r.left + "px"; el.style.top = r.top + "px"; el.style.transform = "none"; el.classList.add("is-moving"); e.preventDefault();
    const mv = (ev) => { el.style.left = Math.max(0, Math.min(r.left + ev.clientX - sx, Math.max(0, innerWidth - r.width))) + "px"; el.style.top = Math.max(0, Math.min(r.top + ev.clientY - sy, innerHeight - 60)) + "px"; };
    const up = () => { el.classList.remove("is-moving"); removeEventListener("pointermove", mv); removeEventListener("pointerup", up); S.panelPos = { ...(S.panelPos || {}), [key]: { x: parseFloat(el.style.left), y: parseFloat(el.style.top) } }; saveSettings(); };
    addEventListener("pointermove", mv); addEventListener("pointerup", up);
  };
  el.querySelectorAll(handleSel).forEach((h) => {
    h.classList.add("drag-handle"); h.addEventListener("pointerdown", grab);
    h.addEventListener("dblclick", (e) => { if (e.target.closest("button, input, select, textarea")) return; S.panelPos = { ...(S.panelPos || {}) }; delete S.panelPos[key]; saveSettings(); applyPanelPos(el, key); });
  });
  addEventListener("resize", () => clampPanel(el));
}

// ================= RESIZABLE START MENU =================
// Drag the top edge, the sides or the top corners. The menu stays centred, so a side moves both ways. Double-click an edge to reset.
function applyStartSize() {
  const m = $("startMenu"); if (!m) return; const z = S.startSize;
  if (!z) { m.style.width = ""; m.style.height = ""; m.classList.remove("sized"); return; }
  const L = startLimits(); m.style.width = Math.max(L.minW, Math.min(z.w, L.maxW)) + "px"; m.style.height = Math.max(L.minH, Math.min(z.h, L.maxH)) + "px"; m.classList.add("sized");
}
// Standard limits for the Start menu (like the Windows 11 one): not smaller than 480x420, not bigger than 900x820 or the screen.
function startLimits() {
  const maxW = Math.max(300, Math.min(900, innerWidth - 24)), maxH = Math.max(300, Math.min(820, innerHeight - 72));
  return { minW: Math.min(480, maxW), minH: Math.min(420, maxH), maxW, maxH };
}
function initStartResize() {
  const m = $("startMenu"); if (!m) return; applyStartSize(); addEventListener("resize", applyStartSize);
  m.querySelectorAll(".start-grip").forEach((g) => {
    g.addEventListener("dblclick", () => { S.startSize = null; saveSettings(); applyStartSize(); });
    g.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return; e.preventDefault(); e.stopPropagation();
      const k = g.dataset.g, r = m.getBoundingClientRect(), sx = e.clientX, sy = e.clientY; m.classList.add("resizing");
      const mv = (ev) => {
        let w = r.width, h = r.height; const dx = ev.clientX - sx, dy = ev.clientY - sy;
        if (k.includes("r")) w = r.width + 2 * dx; if (k.includes("l")) w = r.width - 2 * dx; if (k.includes("t")) h = r.height - dy;
        const L = startLimits(); S.startSize = { w: Math.round(Math.max(L.minW, Math.min(w, L.maxW))), h: Math.round(Math.max(L.minH, Math.min(h, L.maxH))) }; applyStartSize();
      };
      const up = () => { m.classList.remove("resizing"); removeEventListener("pointermove", mv); removeEventListener("pointerup", up); saveSettings(); };
      addEventListener("pointermove", mv); addEventListener("pointerup", up);
    });
  });
}
if ($("resetStartSizeBtn")) $("resetStartSizeBtn").addEventListener("click", () => { S.startSize = null; saveSettings(); applyStartSize(); toast(t().cleared); });

// ================= START MENU =================
const BROWSER_SCHEME = IS_EDGE ? "edge" : "chrome";
const CHROME_PAGES = [["download", "pgDownloads", BROWSER_SCHEME + "://downloads"], ["history", "pgHistory", BROWSER_SCHEME + "://history"], ["star", "pgBookmarks", BROWSER_SCHEME + (IS_EDGE ? "://favorites" : "://bookmarks")], ["puzzle", "pgExtensions", BROWSER_SCHEME + "://extensions"], ["gear", "pgSettings", BROWSER_SCHEME + "://settings"]];
function openChromePage(u) {
  try { if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.create) { chrome.tabs.create({ url: u }); return; } } catch (e) {}
  window.open(u, "_blank");
}
const siteHref = (s) => { try { return new URL(normUrl(s.url)).href; } catch (e) { return ""; } };

// Small safe math parser. No eval.
function calcExpr(src) {
  const s = src.replace(/[۰-۹]/g, (d) => "۰۱۲۳۴۵۶۷۸۹".indexOf(d)).replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d)).replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-").replace(/٫/g, ".");
  if (!/^[\d\s+\-*/^().%]+$/.test(s) || !/[+\-*/^%]/.test(s.replace(/^\s*-/, "")) || !/\d/.test(s)) return null;
  const re = /\s*(\d+\.?\d*|\.\d+|[-+*/^()%])/y; const tok = []; let m;
  while (re.lastIndex < s.length && (m = re.exec(s))) tok.push(m[1]);
  if (re.lastIndex < s.trimEnd().length) return null;
  let p = 0;
  const peek = () => tok[p], next = () => tok[p++];
  const expr = () => { let v = term(); while (peek() === "+" || peek() === "-") { const o = next(), r = term(); v = o === "+" ? v + r : v - r; } return v; };
  const term = () => { let v = pow(); while (peek() === "*" || peek() === "/") { const o = next(), r = pow(); v = o === "*" ? v * r : v / r; } return v; };
  const pow = () => { const b = unary(); if (peek() === "^") { next(); return Math.pow(b, pow()); } return b; };
  const unary = () => { if (peek() === "-") { next(); return -unary(); } if (peek() === "+") { next(); return unary(); } return post(); };
  const post = () => { let v = prim(); while (peek() === "%") { next(); v = v / 100; } return v; };
  const prim = () => { const x = next(); if (x === "(") { const v = expr(); if (next() !== ")") throw 0; return v; } if (x == null || isNaN(+x)) throw 0; return +x; };
  try { const v = expr(); if (p !== tok.length || !isFinite(v)) return null; return +v.toPrecision(12); } catch (e) { return null; }
}

function trackRecent(href) {
  if (!href) return;
  S.recent = [href, ...(S.recent || []).filter((x) => x !== href)].slice(0, 8);
  saveSettings();
}

function startIcon(site) { return makeSiteIcon(site); }
function siteRow(site, i, sub) {
  const a = document.createElement("a"); a.className = "start-row"; a.href = normUrl(site.url); a.dataset.index = i; a.target = "_blank"; a.rel = "noopener"; a.setAttribute("role", "option");
  const ico = document.createElement("span"); ico.className = "sr-ico"; ico.appendChild(startIcon(site));
  const tx = document.createElement("span"); tx.className = "sr-text"; tx.append(Object.assign(document.createElement("b"), { textContent: site.name }), Object.assign(document.createElement("small"), { textContent: sub || hostOf(site.url) }));
  a.append(ico, tx); return a;
}
function actionRow(emoji, title, sub, run) {
  const b = document.createElement("button"); b.type = "button"; b.className = "start-row"; b.setAttribute("role", "option");
  const ico = document.createElement("span"); ico.className = "sr-ico emoji"; ico.innerHTML = uiIcon(emoji, 18);
  const tx = document.createElement("span"); tx.className = "sr-text"; tx.append(Object.assign(document.createElement("b"), { textContent: title }));
  if (sub) tx.append(Object.assign(document.createElement("small"), { textContent: sub }));
  b.append(ico, tx); b.onclick = (e) => { e.stopPropagation(); run(); }; return b;
}

let startAllOpen = false;
function setAllApps(on) {
  startAllOpen = on; const T = t();
  $("startGrid").classList.toggle("hidden", on); $("startAllList").classList.toggle("hidden", !on);
  $("startRecentWrap").classList.toggle("hidden", on || S.startRecent === false);
  $("startAllBtn").textContent = on ? "‹ " + T.back : T.allApps + " ›";
}

function renderStartMenu() {
  const T = t(), grid = $("startGrid"); if (!grid) return;
  grid.innerHTML = ""; SITES.forEach((s, i) => { if (!s.isFolder && !s.sys) grid.appendChild(link(s, "start-item", i)); });
  // all apps, A-Z
  const all = $("startAllList"); all.innerHTML = "";
  const order = SITES.map((s, i) => [s, i]).filter(([s]) => !s.isFolder && !s.sys).sort((x, y) => (x[0].name || "").localeCompare(y[0].name || "", locale()));
  let letter = "";
  order.forEach(([s, i]) => {
    const L = ((s.name || "?")[0] || "?").toUpperCase();
    if (L !== letter) { letter = L; all.appendChild(Object.assign(document.createElement("div"), { className: "start-letter", textContent: L })); }
    all.appendChild(siteRow(s, i));
  });
  // recent
  const rec = $("startRecent"); rec.innerHTML = "";
  const items = (S.recent || []).map((h) => { const i = SITES.findIndex((s) => siteHref(s) === h); return i > -1 ? [SITES[i], i] : null; }).filter(Boolean).slice(0, 6);
  if (!items.length) { const e = mk("div", "start-empty-card", ""); e.append(mk("span", "se-ico", "🕘"), mk("span", "", T.noRecent)); rec.appendChild(e); }
  items.forEach(([s, i]) => rec.appendChild(siteRow(s, i)));
  setAllApps(startAllOpen);
}

function openStartMenu() {
  const inp = $("startSearch"); if (inp) inp.value = "";
  startAllOpen = false; renderStartMenu(); showStartResults("");
  setTimeout(() => inp && inp.focus(), 30);
}

let startSel = 0;
function selectStart(n) {
  const rows = [...document.querySelectorAll("#startResults .start-row")]; if (!rows.length) return;
  startSel = (n + rows.length) % rows.length;
  rows.forEach((r, k) => r.classList.toggle("sel", k === startSel));
  rows[startSel].scrollIntoView({ block: "nearest" });
}
function showStartResults(q) {
  const box = $("startResults"), home = $("startHome"); if (!box) return;
  q = q.trim();
  if (!q) { box.classList.add("hidden"); home.classList.remove("hidden"); box.innerHTML = ""; return; }
  home.classList.add("hidden"); box.classList.remove("hidden"); box.innerHTML = "";
  const T = t(), ql = q.toLowerCase();
  const head = (txt) => box.appendChild(Object.assign(document.createElement("div"), { className: "start-letter", textContent: txt }));

  const val = calcExpr(q);
  if (val != null) {
    head(T.secCalc);
    box.appendChild(actionRow("calc", q + " = " + val.toLocaleString("en-US", { maximumFractionDigits: 10 }), T.clickCopy, () => { try { navigator.clipboard.writeText(String(val)); } catch (e) {} $("startSearch").value = String(val); showStartResults(String(val)); }));
  }
  const isUrl = /^https?:\/\//i.test(q) || (/^[\w-]+(\.[\w-]+)+/.test(q) && !q.includes(" "));
  if (isUrl) box.appendChild(Object.assign(actionRow("globe", T.openUrl + " " + q, "", () => go(q))));

  const score = (s) => { const n = (s.name || "").toLowerCase(), h = hostOf(s.url).toLowerCase(); return n.startsWith(ql) ? 3 : n.includes(ql) ? 2 : h.includes(ql) ? 1 : 0; };
  const sites = SITES.map((s, i) => [s, i, s.isFolder || s.sys ? 0 : score(s)]).filter((x) => x[2] > 0).sort((a, b) => b[2] - a[2]).slice(0, 6);
  if (sites.length) { head(T.secSites); sites.forEach(([s, i]) => box.appendChild(siteRow(s, i))); }

  const acts = [
    ["theme", T.actTheme, () => { S.theme = S.theme === "dark" ? "light" : "dark"; saveSettings(); applyThemeAndAccent(); render(); }],
    ["gear", T.settings, () => { closeAll("settingsPanel"); $("settingsPanel").classList.remove("hidden"); }],
    ["windows", T.widgets, () => { closeAll("widgetsPanel"); $("widgetsPanel").classList.remove("hidden"); renderWidgets(); }],
    ["note", T.openStickyNote, () => { closeAll(); toggleFloatingWidget("note"); }],
    ["cloud", T.openWeatherGadget, () => { closeAll(); toggleFloatingWidget("weather"); }],
    ["plus", T.addSite, () => { closeAll(); openSiteDialog(); }],
    ["compass", T.scHub, () => { closeAll(); openSitesCenter("hub"); }],
    ["star", T.scMine, () => { closeAll(); openSitesCenter("mine"); }],
    ["translate", T.wTranslate, () => { closeAll(); toggleDeskWidget("translate"); }],
    ...CHROME_PAGES.map(([ic, key, url]) => [ic, T[key], () => { closeAll(); openChromePage(url); }])
  ].filter(([, title]) => title && title.toLowerCase().includes(ql)).slice(0, 5);
  if (acts.length) { head(T.secActions); acts.forEach(([ic, title, run]) => box.appendChild(actionRow(ic, title, "", run))); }

  head(T.searchWeb);
  box.appendChild(actionRow("search", T.searchWeb + " “" + q + "”", "", () => go(q)));
  selectStart(0);
}

if ($("startSearch")) {
  const inp = $("startSearch");
  inp.addEventListener("input", () => showStartResults(inp.value));
  inp.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown") { e.preventDefault(); selectStart(startSel + 1); }
    else if (e.key === "ArrowUp") { e.preventDefault(); selectStart(startSel - 1); }
    else if (e.key === "Enter") {
      const rows = document.querySelectorAll("#startResults .start-row");
      if (inp.value.trim() && rows[startSel]) { e.preventDefault(); rows[startSel].click(); }
    }
  });
}
if ($("startAllBtn")) $("startAllBtn").addEventListener("click", (e) => { e.stopPropagation(); setAllApps(!startAllOpen); });
["startMenu", "desktopIcons", "taskbarPinned", "folderPop", "heroQuick"].forEach((id) => {
  const el = $(id); if (!el) return;
  el.addEventListener("click", (e) => {
    const a = e.target.closest("a[href]"); if (!a || e.defaultPrevented) return;
    trackRecent(a.href);
    if ((S.openMode || "tab") !== "tab" && !(e.ctrlKey || e.metaKey || e.shiftKey)) { e.preventDefault(); const s = SITES[+a.dataset.index]; openSite(a.href, s && s.name); }
  });
});


// ================= SITES CENTER: site hub (ready-made, categorised, auto-updating) + my websites (library) =================
// My websites keeps every site the user added, apart from the desktop: removing an icon from the desktop does not remove it here.
// Set this ONCE to the https address of your hub.json (for example a GitHub raw link). Every copy of the extension then updates itself.
const HUB_DEFAULT_URL = "https://raw.githubusercontent.com/hadi-Bluray/Win-11-extension-chrome/refs/heads/main/hub.json";
const hubUrl = () => ((S.hub && S.hub.url) || HUB_DEFAULT_URL || "").trim();
const HUB_BUILTIN = {"version":1,"updated":"2026-10-20","categories":[{"id":"ai","fa":"هوش مصنوعی","en":"AI","icon":"✨","sites":[{"n":"ChatGPT","u":"https://chatgpt.com","fa":"دستیار گفتگوی OpenAI","en":"OpenAI chat assistant"},{"n":"Claude","u":"https://claude.ai","fa":"دستیار هوش مصنوعی Anthropic","en":"Anthropic AI assistant"},{"n":"Gemini","u":"https://gemini.google.com","fa":"هوش مصنوعی گوگل","en":"Google AI assistant"},{"n":"Perplexity","u":"https://www.perplexity.ai","fa":"جستجوی هوشمند همراه با منبع","en":"AI search with sources"},{"n":"Copilot","u":"https://copilot.microsoft.com","fa":"دستیار مایکروسافت","en":"Microsoft assistant"},{"n":"DeepSeek","u":"https://chat.deepseek.com","fa":"چت‌بات DeepSeek","en":"DeepSeek chat"},{"n":"Hugging Face","u":"https://huggingface.co","fa":"مدل‌ها و ابزارهای هوش مصنوعی","en":"Models and AI tools"}]},{"id":"google","fa":"سرویس‌های گوگل","en":"Google","icon":"🔎","sites":[{"n":"Gmail","u":"https://mail.google.com","fa":"ایمیل","en":"Email"},{"n":"Google Maps","u":"https://maps.google.com","fa":"نقشه و مسیریابی","en":"Maps and directions"},{"n":"Google Translate","u":"https://translate.google.com","fa":"ترجمهٔ متن و وب‌سایت","en":"Translate text and sites"},{"n":"Google Drive","u":"https://drive.google.com","fa":"فضای ابری","en":"Cloud storage"},{"n":"Google Docs","u":"https://docs.google.com/document/","fa":"ویرایشگر متن آنلاین","en":"Online documents"},{"n":"Google Sheets","u":"https://docs.google.com/spreadsheets/","fa":"صفحه‌گسترده آنلاین","en":"Online spreadsheets"},{"n":"Google Calendar","u":"https://calendar.google.com","fa":"تقویم","en":"Calendar"},{"n":"Google Photos","u":"https://photos.google.com","fa":"عکس‌ها","en":"Photos"},{"n":"Google Meet","u":"https://meet.google.com","fa":"تماس تصویری","en":"Video calls"},{"n":"Google Keep","u":"https://keep.google.com","fa":"یادداشت","en":"Notes"},{"n":"Google Scholar","u":"https://scholar.google.com","fa":"جستجوی مقالات علمی","en":"Scholarly articles"}]},{"id":"lang","fa":"ترجمه و زبان","en":"Translate & language","icon":"🌐","sites":[{"n":"DeepL","u":"https://www.deepl.com/translator","fa":"ترجمهٔ دقیق","en":"Accurate translation"},{"n":"Reverso Context","u":"https://context.reverso.net","fa":"ترجمه با مثال و بافت","en":"Translation in context"},{"n":"Cambridge Dictionary","u":"https://dictionary.cambridge.org","fa":"دیکشنری انگلیسی","en":"English dictionary"},{"n":"واژه‌یاب","u":"https://vajehyab.com","fa":"دیکشنری فارسی","en":"Persian dictionary"},{"n":"لغت‌نامه دهخدا","u":"https://dehkhoda.ut.ac.ir","fa":"فرهنگ لغت دهخدا","en":"Dehkhoda dictionary"},{"n":"Duolingo","u":"https://www.duolingo.com","fa":"یادگیری زبان","en":"Learn languages"}]},{"id":"media","fa":"ویدیو و موسیقی","en":"Video & music","icon":"🎬","sites":[{"n":"YouTube","u":"https://www.youtube.com","fa":"ویدیو","en":"Video"},{"n":"YouTube Music","u":"https://music.youtube.com","fa":"موسیقی","en":"Music"},{"n":"آپارات","u":"https://www.aparat.com","fa":"ویدیوی فارسی","en":"Persian video"},{"n":"Spotify","u":"https://open.spotify.com","fa":"موسیقی و پادکست","en":"Music and podcasts"},{"n":"SoundCloud","u":"https://soundcloud.com","fa":"موسیقی مستقل","en":"Independent music"},{"n":"Netflix","u":"https://www.netflix.com","fa":"فیلم و سریال","en":"Movies and series"},{"n":"Twitch","u":"https://www.twitch.tv","fa":"پخش زنده","en":"Live streaming"}]},{"id":"social","fa":"شبکه‌های اجتماعی","en":"Social","icon":"💬","sites":[{"n":"Instagram","u":"https://www.instagram.com","fa":"","en":""},{"n":"X","u":"https://x.com","fa":"","en":"Twitter"},{"n":"Telegram","u":"https://web.telegram.org/a/","fa":"تلگرام وب","en":"Telegram Web"},{"n":"WhatsApp","u":"https://web.whatsapp.com","fa":"واتس‌اپ وب","en":"WhatsApp Web"},{"n":"LinkedIn","u":"https://www.linkedin.com","fa":"شبکهٔ حرفه‌ای","en":"Professional network"},{"n":"Reddit","u":"https://www.reddit.com","fa":"انجمن‌ها","en":"Communities"},{"n":"Discord","u":"https://discord.com/app","fa":"گفتگو و گروه","en":"Chat and communities"},{"n":"Pinterest","u":"https://www.pinterest.com","fa":"ایده و تصویر","en":"Ideas and images"}]},{"id":"dev","fa":"برنامه‌نویسی","en":"Development","icon":"💻","sites":[{"n":"GitHub","u":"https://github.com","fa":"کد و پروژه‌ها","en":"Code and projects"},{"n":"Stack Overflow","u":"https://stackoverflow.com","fa":"پرسش و پاسخ برنامه‌نویسی","en":"Programming Q&A"},{"n":"MDN Web Docs","u":"https://developer.mozilla.org","fa":"مرجع وب","en":"Web reference"},{"n":"CodePen","u":"https://codepen.io","fa":"آزمایش کد فرانت‌اند","en":"Front-end playground"},{"n":"npm","u":"https://www.npmjs.com","fa":"پکیج‌های جاوااسکریپت","en":"JavaScript packages"},{"n":"Can I use","u":"https://caniuse.com","fa":"پشتیبانی مرورگرها","en":"Browser support"},{"n":"regex101","u":"https://regex101.com","fa":"تست عبارت منظم","en":"Regex tester"}]},{"id":"design","fa":"طراحی و تصویر","en":"Design & images","icon":"🎨","sites":[{"n":"Figma","u":"https://www.figma.com","fa":"طراحی رابط کاربری","en":"UI design"},{"n":"Canva","u":"https://www.canva.com","fa":"طراحی گرافیکی ساده","en":"Easy graphic design"},{"n":"Unsplash","u":"https://unsplash.com","fa":"عکس رایگان","en":"Free photos"},{"n":"Pexels","u":"https://www.pexels.com","fa":"عکس و ویدیوی رایگان","en":"Free photos and videos"},{"n":"Coolors","u":"https://coolors.co","fa":"ساخت پالت رنگ","en":"Color palettes"},{"n":"Flaticon","u":"https://www.flaticon.com","fa":"آیکون","en":"Icons"},{"n":"remove.bg","u":"https://www.remove.bg","fa":"حذف پس‌زمینهٔ عکس","en":"Remove image background"},{"n":"Photopea","u":"https://www.photopea.com","fa":"ویرایشگر عکس آنلاین","en":"Online photo editor"}]},{"id":"tools","fa":"ابزارهای آنلاین","en":"Online tools","icon":"🧰","sites":[{"n":"iLovePDF","u":"https://www.ilovepdf.com","fa":"ابزارهای PDF","en":"PDF tools"},{"n":"TinyPNG","u":"https://tinypng.com","fa":"کم‌حجم کردن عکس","en":"Compress images"},{"n":"Speedtest","u":"https://www.speedtest.net","fa":"تست سرعت اینترنت","en":"Internet speed test"},{"n":"Wayback Machine","u":"https://web.archive.org","fa":"آرشیو وب‌سایت‌ها","en":"Website archive"},{"n":"Wolfram Alpha","u":"https://www.wolframalpha.com","fa":"محاسبات و دانش","en":"Computation and knowledge"},{"n":"Time and Date","u":"https://www.timeanddate.com","fa":"ساعت و تقویم جهانی","en":"World time and calendars"},{"n":"Convertio","u":"https://convertio.co","fa":"تبدیل فرمت فایل","en":"File converter"}]},{"id":"learn","fa":"آموزش و دانش","en":"Learning","icon":"📚","sites":[{"n":"Wikipedia","u":"https://www.wikipedia.org","fa":"دانشنامه","en":"Encyclopedia"},{"n":"Khan Academy","u":"https://www.khanacademy.org","fa":"آموزش رایگان","en":"Free lessons"},{"n":"Coursera","u":"https://www.coursera.org","fa":"دوره‌های دانشگاهی","en":"University courses"},{"n":"edX","u":"https://www.edx.org","fa":"دوره‌های آنلاین","en":"Online courses"},{"n":"Udemy","u":"https://www.udemy.com","fa":"دوره‌های مهارتی","en":"Skill courses"},{"n":"Internet Archive","u":"https://archive.org","fa":"کتاب و رسانهٔ آزاد","en":"Free books and media"}]},{"id":"shop","fa":"خرید","en":"Shopping","icon":"🛒","sites":[{"n":"دیجی‌کالا","u":"https://www.digikala.com","fa":"فروشگاه آنلاین","en":"Online store"},{"n":"دیوار","u":"https://divar.ir","fa":"آگهی","en":"Classifieds"},{"n":"ترب","u":"https://torob.com","fa":"مقایسهٔ قیمت","en":"Price comparison"},{"n":"اسنپ","u":"https://snapp.ir","fa":"سفر و سفارش","en":"Rides and orders"},{"n":"Amazon","u":"https://www.amazon.com","fa":"","en":"Online store"},{"n":"AliExpress","u":"https://www.aliexpress.com","fa":"","en":"Online store"}]},{"id":"news","fa":"اخبار","en":"News","icon":"📰","sites":[{"n":"BBC","u":"https://www.bbc.com","fa":"","en":"World news"},{"n":"BBC فارسی","u":"https://www.bbc.com/persian","fa":"اخبار فارسی","en":"Persian news"},{"n":"Reuters","u":"https://www.reuters.com","fa":"","en":"World news"},{"n":"Hacker News","u":"https://news.ycombinator.com","fa":"اخبار فناوری","en":"Tech news"},{"n":"زومیت","u":"https://www.zoomit.ir","fa":"اخبار فناوری فارسی","en":"Persian tech news"}]}]};
let MYSITES = [], HUB = null, sitesTab = "hub", hubCat = "all", siteLibOnly = false, siteLibOld = null;
const libKey = (u) => normUrl(u).toLowerCase().replace(/^(https?:\/\/)www\./, "$1").replace(/[\/#?]+$/, "");
const saveLib = () => { scheduleSync(); return store.set({ mysites: MYSITES }); };
function libSave(item, oldUrl) {
  if (!item || !item.url) return;
  const rec = { name: item.name, url: normUrl(item.url), ...(item.icon ? { icon: item.icon } : {}) };
  const i = MYSITES.findIndex((m) => libKey(m.url) === libKey(oldUrl || item.url));
  if (i >= 0) MYSITES[i] = { ...rec, added: MYSITES[i].added || Date.now() };
  else if (!MYSITES.some((m) => libKey(m.url) === libKey(rec.url))) MYSITES.push({ ...rec, added: Date.now() });
  saveLib();
}
const onDesktop = (url) => SITES.some((s) => isRealSite(s) && s.url && libKey(s.url) === libKey(url));
function addToDesktop(rec) {
  if (onDesktop(rec.url)) { toast(t().scOnDesk); return false; }
  SITES.push({ name: rec.name, url: normUrl(rec.url), ...(rec.icon ? { icon: rec.icon } : {}) });
  libSave(rec); saveSites(); renderSites(); toast(t().scAddedDesk); return true;
}

// ---- catalog: built-in, replaced by the online one when a catalog address is set ----
function hubSanitize(raw) {
  if (!raw || !Array.isArray(raw.categories)) return null;
  const str = (v, n) => (typeof v === "string" ? v.trim().slice(0, n) : "");
  const cats = raw.categories.slice(0, 40).map((c, ci) => {
    c = c || {};
    const sites = (Array.isArray(c.sites) ? c.sites : []).slice(0, 200).map((s) => ({ n: str(s && s.n, 60), u: str(s && s.u, 300), fa: str(s && s.fa, 120), en: str(s && s.en, 120) })).filter((s) => s.n && /^https?:\/\/[^\s]+$/i.test(s.u));
    return { id: str(c.id, 30) || "c" + ci, fa: str(c.fa, 40) || str(c.en, 40), en: str(c.en, 40) || str(c.fa, 40), icon: str(c.icon, 4), sites };
  }).filter((c) => c.sites.length && (c.fa || c.en));
  return cats.length ? { version: Number(raw.version) || 0, updated: str(raw.updated, 20), categories: cats } : null;
}
const hubData = () => (HUB && HUB.data) || HUB_BUILTIN;
async function hubUpdate(manual) {
  const h = S.hub, src = hubUrl();
  if (!/^https:\/\//i.test(src)) { if (manual) toast(t().scNoUrl); return false; }
  const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 12000);
  try {
    const r = await fetch(src, { cache: "no-store", credentials: "omit", signal: ctl.signal });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const data = hubSanitize(await r.json()); if (!data) throw new Error("format");
    HUB = { data, ts: Date.now(), src: h.url }; await store.set({ hubcache: HUB });
    h.last = Date.now(); persistSyncState();
    if (manual) toast(t().scUpdated);
    if ($("sitesModal") && !$("sitesModal").classList.contains("hidden")) renderSitesCenter();
    return true;
  } catch (err) { if (manual) toast(t().scFail); return false; } finally { clearTimeout(to); }
}
function hubAutoUpdate() { const h = S.hub; if (h && hubUrl() && h.auto !== false && Date.now() - (h.last || 0) > 12 * 3600e3) hubUpdate(false); }

// ---- window ----
function ensureSitesModal() {
  let m = $("sitesModal"); if (m) return m;
  m = document.createElement("div"); m.className = "modal hidden"; m.id = "sitesModal";
  m.innerHTML = `<div class="dialog sites-win" role="dialog" aria-modal="true">
    <header class="sw-head"><nav class="sw-tabs"><button type="button" data-tab="hub"></button><button type="button" data-tab="mine"></button></nav><button type="button" class="close-btn" id="swClose">✕</button></header>
    <div class="sw-tools"><input type="search" class="txt sw-search" id="swSearch" autocomplete="off" /><span class="sw-tools-btns"></span></div>
    <div class="sw-cats" id="swCats"></div>
    <div class="sw-body" id="swBody"></div>
    <footer class="sw-foot" id="swFoot"></footer></div>`;
  document.body.insertBefore(m, $("siteModal") || null);
  m.addEventListener("click", (e) => { if (e.target === m) m.classList.add("hidden"); });
  $("swClose").onclick = () => m.classList.add("hidden");
  m.querySelectorAll(".sw-tabs button").forEach((b) => { b.onclick = () => { sitesTab = b.dataset.tab; $("swSearch").value = ""; renderSitesCenter(); }; });
  $("swSearch").addEventListener("input", () => renderSitesCenter(true));
  return m;
}
function openSitesCenter(tab) {
  closeAll(); const m = ensureSitesModal(); if (tab) sitesTab = tab;
  $("swSearch").value = ""; renderSitesCenter(); m.classList.remove("hidden"); hubAutoUpdate();
  setTimeout(() => $("swSearch").focus(), 30);
}
const scIconBtn = (icon, title, fn, cls) => { const b = mk("button", "sc-btn" + (cls ? " " + cls : "")); b.type = "button"; b.title = title; b.setAttribute("aria-label", title); b.innerHTML = uiIcon(icon, 16); b.onclick = (e) => { e.preventDefault(); e.stopPropagation(); fn(); }; return b; };
function renderSitesCenter(keepScroll) {
  const m = ensureSitesModal(), T = t(), q = ($("swSearch").value || "").trim().toLowerCase(), body = $("swBody"), prev = keepScroll ? body.scrollTop : 0;
  m.querySelectorAll(".sw-tabs button").forEach((b) => { b.textContent = b.dataset.tab === "hub" ? T.scHub : T.scMine; b.classList.toggle("on", b.dataset.tab === sitesTab); });
  $("swSearch").placeholder = T.scSearch;
  body.innerHTML = ""; $("swCats").innerHTML = ""; $("swFoot").innerHTML = "";
  m.querySelector(".sw-tools-btns").innerHTML = "";
  if (sitesTab === "hub") renderHub(q, body, T); else renderMine(q, body, T);
  body.scrollTop = prev;
}
function renderHub(q, body, T) {
  const d = hubData(), lang = S.lang === "fa" ? "fa" : "en", cats = $("swCats");
  const chip = (id, label) => { const b = mk("button", "chip" + (hubCat === id ? " on" : ""), label); b.type = "button"; b.onclick = () => { hubCat = id; renderSitesCenter(); }; cats.appendChild(b); };
  if (hubCat !== "all" && !d.categories.some((c) => c.id === hubCat)) hubCat = "all";
  chip("all", T.scAll); d.categories.forEach((c) => chip(c.id, (c.icon ? c.icon + " " : "") + (c[lang] || c.fa)));
  let shown = 0;
  d.categories.filter((c) => hubCat === "all" || c.id === hubCat).forEach((c) => {
    const list = c.sites.filter((s) => !q || (s.n + " " + s.u + " " + s.fa + " " + s.en).toLowerCase().includes(q)); if (!list.length) return;
    shown += list.length;
    const sec = mk("section", "sc-sec"); sec.appendChild(mk("h4", "", (c.icon ? c.icon + " " : "") + (c[lang] || c.fa)));
    const grid = mk("div", "sc-grid");
    list.forEach((s) => {
      const rec = { name: s.n, url: s.u }, card = mk("div", "sc-card"), a = mk("a", "sc-main"); a.href = s.u; a.target = "_blank"; a.rel = "noopener";
      const ico = mk("span", "sc-ico"); ico.appendChild(makeSiteIcon(rec, "tile"));
      const txt = mk("span", "sc-txt"); txt.append(mk("b", "", s.n), mk("small", "", s[lang] || s.fa || s.en || hostOf(s.u))); a.append(ico, txt);
      const acts = mk("span", "sc-acts"), inLib = MYSITES.some((x) => libKey(x.url) === libKey(s.u));
      acts.append(
        scIconBtn(inLib ? "check" : "star", inLib ? T.scSaved : T.scSave, () => { if (!inLib) { libSave(rec); toast(T.scLibSaved); } renderSitesCenter(true); }, inLib ? "on" : ""),
        scIconBtn(onDesktop(s.u) ? "check" : "plus", onDesktop(s.u) ? T.scOnDesk : T.scAddDesk, () => { addToDesktop(rec); renderSitesCenter(true); }, onDesktop(s.u) ? "on" : ""));
      card.append(a, acts); grid.appendChild(card);
    });
    sec.appendChild(grid); body.appendChild(sec);
  });
  if (!shown) body.appendChild(mk("p", "sc-empty", T.scNone));
  // footer: catalog source + auto update
  const h = S.hub, foot = $("swFoot"), info = mk("span", "sc-meta");
  const when = (ts) => { try { return new Date(ts).toLocaleString(locale()); } catch (err) { return ""; } };
  info.textContent = (HUB && HUB.data ? T.scOnline + (HUB.ts ? " · " + when(HUB.ts) : "") : T.scBuiltin + (HUB_BUILTIN.updated ? " · " + HUB_BUILTIN.updated : ""));
  const det = mk("details", "sc-set"), sum = mk("summary", "", T.scUpdSet);
  const url = mk("input", "txt"); url.type = "url"; url.dir = "ltr"; url.placeholder = "https://…/hub.json"; url.value = h.url || ""; if (HUB_DEFAULT_URL) url.placeholder = HUB_DEFAULT_URL;
  const auto = mk("label", "sc-auto"), chk = document.createElement("input"); chk.type = "checkbox"; chk.checked = h.auto !== false; auto.append(chk, mk("span", "", T.scAuto));
  const go = mk("button", "mini", T.scUpdNow); go.type = "button";
  go.onclick = async () => { h.url = url.value.trim(); h.auto = chk.checked; saveSettings(); if (!hubUrl()) { HUB = null; store.remove("hubcache"); renderSitesCenter(); return; } go.disabled = true; await hubUpdate(true); go.disabled = false; };
  det.append(sum, url, auto, mk("small", "muted", T.scUpdHint), go);
  foot.append(info, det);
}
function renderMine(q, body, T) {
  const tb = document.querySelector("#sitesModal .sw-tools-btns"), add = mk("button", "mini", "＋ " + T.scAddLib); add.type = "button";
  add.onclick = () => openSiteDialog(null, { libOnly: true }); tb.appendChild(add);
  const list = MYSITES.filter((s) => !q || (s.name + " " + s.url).toLowerCase().includes(q));
  if (!list.length) { body.appendChild(mk("p", "sc-empty", MYSITES.length ? T.scNone : T.scMineEmpty)); return; }
  const grid = mk("div", "sc-list");
  list.forEach((s) => {
    const row = mk("div", "sc-card sc-row"), a = mk("a", "sc-main"); a.href = normUrl(s.url); a.target = "_blank"; a.rel = "noopener";
    const ico = mk("span", "sc-ico"); ico.appendChild(makeSiteIcon(s, "tile"));
    const txt = mk("span", "sc-txt"); txt.append(mk("b", "", s.name), mk("small", "", hostOf(s.url))); a.append(ico, txt);
    const acts = mk("span", "sc-acts"), on = onDesktop(s.url);
    acts.append(
      scIconBtn(on ? "check" : "plus", on ? T.scOnDesk : T.scAddDesk, () => { addToDesktop(s); renderSitesCenter(true); }, on ? "on" : ""),
      scIconBtn("edit", T.editSite, () => openSiteDialog(null, { libOnly: true, prefill: { name: s.name, url: s.url, icon: s.icon }, libOld: s.url })),
      scIconBtn("trash", T.scRemoveLib, () => showWinModal(T.scRemoveLib, T.scRemoveLibConfirm, () => { MYSITES = MYSITES.filter((x) => x !== s); saveLib(); renderSitesCenter(true); }), "danger"));
    row.append(a, acts); grid.appendChild(row);
  });
  body.appendChild(grid);
  $("swFoot").appendChild(mk("span", "sc-meta", T.scMineNote + " · " + MYSITES.length));
}
// Entry buttons in the Start menu (icon only) and the desktop menu are built here so they follow the language.
function sitesCenterEntries() {
  const box = document.querySelector(".start-footer-btns"), T = t();
  if (box) {
    box.querySelectorAll(".sc-start-btn").forEach((b) => b.remove());
    [["compass", "hub", T.scHub], ["star", "mine", T.scMine]].reverse().forEach(([ic, tab, title]) => {
      const b = mk("button", "start-settings icon-only sc-start-btn"); b.type = "button"; b.title = title; b.setAttribute("aria-label", title); b.innerHTML = uiIcon(ic, 18);
      b.onclick = (e) => { e.stopPropagation(); openSitesCenter(tab); }; box.insertBefore(b, box.firstChild);
    });
  }
  if ($("sitesModal") && !$("sitesModal").classList.contains("hidden")) renderSitesCenter(true);
}

// ================= FLOATING TRANSLATOR WIDGET =================
const TR_LANGS = [["fa", "فارسی"], ["en", "English"], ["ar", "العربية"], ["tr", "Türkçe"], ["de", "Deutsch"], ["fr", "Français"], ["es", "Español"], ["it", "Italiano"], ["ru", "Русский"], ["pt", "Português"], ["nl", "Nederlands"], ["sv", "Svenska"], ["pl", "Polski"], ["uk", "Українська"], ["zh-CN", "中文"], ["ja", "日本語"], ["ko", "한국어"], ["hi", "हिन्दी"], ["ur", "اردو"], ["he", "עברית"]];
const TR = { text: "", out: "", det: "", seq: 0 };
const trIsRtlText = (s) => /[\u0590-\u08FF]/.test(s);
async function trGoogle(text, sl, tl) {
  const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 10000);
  try {
    const r = await fetch("https://translate.googleapis.com/translate_a/single?client=gtx&dt=t&sl=" + encodeURIComponent(sl) + "&tl=" + encodeURIComponent(tl) + "&q=" + encodeURIComponent(text), { credentials: "omit", signal: ctl.signal });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const d = await r.json(); return { text: (d[0] || []).map((x) => (x && x[0]) || "").join(""), det: d[2] || (sl === "auto" ? "" : sl) };
  } finally { clearTimeout(to); }
}
async function trMyMemory(text, sl, tl) { // backup service, short texts only
  if (text.length > 450) throw new Error("long");
  if (sl === "auto") sl = trIsRtlText(text) ? "fa" : "en";
  const r = await fetch("https://api.mymemory.translated.net/get?q=" + encodeURIComponent(text) + "&langpair=" + encodeURIComponent(sl + "|" + tl), { credentials: "omit" });
  const d = await r.json(); if (!d || !d.responseData || !d.responseData.translatedText) throw new Error("empty");
  return { text: d.responseData.translatedText, det: sl };
}
function wTranslate(body) {
  if (!body) return; body.innerHTML = ""; body.classList.add("tr-body"); const T = t();
  S.tr = { from: "auto", to: S.lang === "fa" ? "fa" : "en", ...(S.tr || {}) }; if (!TR_LANGS.some((l) => l[0] === S.tr.from)) S.tr.from = "auto";
  const mkSel = (withAuto, val) => { const s = document.createElement("select"); s.className = "txt tr-sel"; if (withAuto) s.appendChild(new Option(T.trAuto, "auto")); TR_LANGS.forEach(([c, n]) => s.appendChild(new Option(n, c))); s.value = val; return s; };
  const from = mkSel(true, S.tr.from), to = mkSel(false, S.tr.to), swap = mk("button", "mini ghost tr-swap", "⇄"); swap.type = "button"; swap.title = T.trSwap;
  const top = mk("div", "tr-top"); top.append(from, swap, to);
  const src = document.createElement("textarea"); src.className = "txt tr-src"; src.placeholder = T.trPh; src.maxLength = 2500; src.dir = "auto"; src.value = TR.text; src.rows = 4;
  const out = mk("div", "tr-out", TR.out); out.dir = "auto"; out.tabIndex = 0;
  const bar = mk("div", "tr-bar"), go = mk("button", "mini", T.trGo), copy = mk("button", "mini ghost", T.trCopy), say = mk("button", "mini ghost", "🔊"), clr = mk("button", "mini ghost", T.trClear), info = mk("span", "tr-info", "");
  [go, copy, say, clr].forEach((b) => (b.type = "button")); say.title = T.trSpeak;
  bar.append(go, copy, say, clr); body.append(top, src, out, bar, info);
  const langName = (c) => (TR_LANGS.find((l) => l[0] === c) || [c, c])[1];
  const save = () => { S.tr = { from: from.value, to: to.value }; saveSettings(); };
  let target = to.value, timer;
  async function run() {
    const text = src.value.trim(); TR.text = src.value; const my = ++TR.seq;
    if (!text) { TR.out = out.textContent = ""; info.textContent = ""; return; }
    // a Persian text sent to "Persian" goes to English instead, so the button always does something useful
    target = to.value;
    out.classList.add("busy"); info.textContent = T.trWorking;
    let res = null;
    try { res = await trGoogle(text, from.value, target); } catch (err) { try { res = await trMyMemory(text, from.value, target); } catch (err2) { res = null; } }
    if (my !== TR.seq) return; out.classList.remove("busy");
    if (!res) { out.textContent = ""; info.textContent = T.trErr; return; }
    TR.out = out.textContent = res.text; TR.det = res.det || "";
    from.options[0].textContent = from.value === "auto" && TR.det ? T.trAuto + " · " + langName(TR.det) : T.trAuto;
    info.textContent = (from.value === "auto" && TR.det ? langName(TR.det) + " → " : "") + langName(target) + (TR.det && TR.det.split("-")[0] === target.split("-")[0] ? " · " + T.trSame : "");
  }
  const later = () => { clearTimeout(timer); timer = setTimeout(run, 650); };
  src.addEventListener("input", later);
  src.addEventListener("keydown", (e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); clearTimeout(timer); run(); } });
  go.onclick = () => { clearTimeout(timer); run(); };
  from.onchange = () => { save(); run(); }; to.onchange = () => { save(); run(); };
  swap.onclick = () => {
    const a = from.value === "auto" ? (TR.det || (trIsRtlText(src.value) ? "fa" : "en")) : from.value, b = target || to.value;
    from.value = b; to.value = a; if (!to.value) to.value = "en"; src.value = TR.out || src.value; TR.text = src.value; save(); run();
  };
  copy.onclick = async () => { if (TR.out) { await copyText(TR.out); toast(T.trCopied); } };
  clr.onclick = () => { src.value = ""; TR.text = TR.out = ""; out.textContent = info.textContent = ""; TR.seq++; src.focus(); };
  say.onclick = () => { try { if (!TR.out) return; speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(TR.out); u.lang = target; speechSynthesis.speak(u); } catch (err) {} };
  if (TR.text && !TR.out) run();
}

store.get(["settings", "sites", "wallpaper", "notes", "todos", "mysites", "hubcache"]).then((r) => {
  S = { ...structuredClone(DEFAULTS), ...(r.settings || {}) };
  S.widgets = { ...DEFAULTS.widgets, ...(S.widgets || {}) }; S.floating = { ...DEFAULTS.floating, ...(S.floating || {}) }; S.desk = S.desk || {};
  S.sync = { ...DEFAULTS.sync, ...(S.sync || {}) }; S.profile = { ...DEFAULTS.profile, ...(S.profile || {}) };
  if (!S.deskMigrated) { // old floating note / weather become desktop widgets
    if (S.floating.note && S.floating.note.open) S.desk.notes = { x: S.floating.note.x || 60, y: S.floating.note.y || 120 };
    if (S.floating.weather && S.floating.weather.open) S.desk.weather = { x: S.floating.weather.x || 300, y: S.floating.weather.y || 100 };
    S.deskMigrated = true;
  } S.hero = { ...DEFAULTS.hero, ...(S.hero || {}) };
  if (Array.isArray(r.sites)) SITES = r.sites;
  S.hub = { ...DEFAULTS.hub, ...(S.hub || {}) };
  if (r.hubcache && r.hubcache.data && hubSanitize(r.hubcache.data)) HUB = r.hubcache;
  if (Array.isArray(r.mysites)) MYSITES = r.mysites;
  else { // first run of this version: every site already on the desktop is kept in My websites too
    MYSITES = SITES.filter((s) => isRealSite(s) && s.url).map((s) => ({ name: s.name, url: normUrl(s.url), ...(s.icon ? { icon: s.icon } : {}), added: Date.now() }));
    store.set({ mysites: MYSITES });
  }
  WALLPAPER = r.wallpaper || null; NOTES = r.notes || ""; TODOS = r.todos || [];
  if (S.layoutV !== 2) {
    // Old versions saved Persian icon places from the LEFT edge. New version saves from the START edge.
    if (S.lang === "fa") SITES.forEach((site) => { if (site.x != null) { site.x = window.innerWidth - site.x - CELL_W; site.hx = site.x; site.hy = site.y; } });
    S.layoutV = 2; saveSettings(); saveSites();
  }
  AUTO = S.autoTheme !== false && S.autoColors ? S.autoColors : null;
  ensureSettingsIcon(); setupFrameRules();
  updateScale();
  render();
  decorateSettings(); showSettingsSection("general");
  initStartResize(); makePanelDraggable("settingsPanel", "settings", ".set-head, .set-brand"); makePanelDraggable("accountPanel", "account", ".acc-head");
  autoWallpaper(); initLive();
  sitesCenterEntries(); setTimeout(hubAutoUpdate, 2500); setInterval(hubAutoUpdate, 6 * 3600e3);
  requestAnimationFrame(() => { if (clampWidgets()) saveSettings(); });
});
setInterval(tick, 1000);